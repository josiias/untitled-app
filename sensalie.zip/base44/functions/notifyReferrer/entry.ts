import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const payload = await req.json();

    // Called from entity automation on ReferralPayout create
    const payout = payload.data;
    if (!payout) return Response.json({ ok: true });

    // Get the referrer customer
    const referrers = await base44.asServiceRole.entities.Customer.filter({ id: payout.referrer_customer_id }, "-created_date", 1);
    if (!referrers.length) return Response.json({ ok: true });

    const referrer = referrers[0];
    const amount = Number(payout.amount || 0).toFixed(2);

    // Get business name
    const businesses = await base44.asServiceRole.entities.Business.filter({ id: payout.business_id }, "-created_date", 1);
    const bizName = businesses[0]?.name || "einem Partner";

    // Only send email if we have a valid email (from created_by or user lookup)
    // Since Customer uses phone, we update provision_earned on the referrer
    const newEarned = (referrer.provision_earned || 0) + Number(payout.amount || 0);
    await base44.asServiceRole.entities.Customer.update(referrer.id, { provision_earned: newEarned });

    return Response.json({ ok: true, updated: referrer.id, newEarned });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});