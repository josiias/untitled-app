import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();

    const entry = body.data;

    if (!entry) {
      return Response.json({ error: 'No data received' }, { status: 400 });
    }

    await base44.asServiceRole.integrations.Core.SendEmail({
      to: 'mgognon99@gmail.com',
      subject: `🆕 Neue Waitlist-Anmeldung: ${entry.business_name}`,
      body: `
Neue Anmeldung auf der Sensalie Waitlist!

🏪 Unternehmen: ${entry.business_name}
👤 Name: ${entry.contact_name || '—'}
📧 E-Mail: ${entry.email}
🏷️ Branche: ${entry.industry || '—'}
📍 Google Maps: ${entry.google_maps_link || '—'}
      `.trim()
    });

    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});