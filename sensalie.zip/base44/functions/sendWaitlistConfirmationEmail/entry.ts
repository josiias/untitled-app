import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { email, businessName, contactName } = await req.json();
    
    if (!email || !businessName || !contactName) {
      return Response.json({ error: 'Erforderliche Felder fehlen' }, { status: 400 });
    }

    const htmlContent = `
<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue', sans-serif; line-height: 1.6; color: #374151; background: #f3f4f6; }
    .container { max-width: 600px; margin: 0 auto; background: #ffffff; }
    .header { background: linear-gradient(135deg, rgba(16,185,129,0.08), rgba(16,185,129,0.02)); padding: 40px 24px; text-align: center; border-bottom: 1px solid rgba(16,185,129,0.1); }
    .logo { font-size: 28px; font-weight: 800; color: #000; margin-bottom: 8px; letter-spacing: -0.5px; }
    .logo span { color: #10B981; }
    .content { padding: 40px 24px; }
    .headline { font-size: 24px; font-weight: 700; color: #1f2937; margin: 0 0 24px; }
    .text { color: #6b7280; font-size: 15px; line-height: 1.6; margin: 16px 0; }
    .steps { background: rgba(16,185,129,0.05); border-left: 4px solid #10B981; padding: 20px; border-radius: 8px; margin: 24px 0; }
    .step { margin: 12px 0; color: #374151; font-size: 14px; }
    .step strong { color: #1f2937; }
    .footer { background: #f9fafb; border-top: 1px solid #e5e7eb; padding: 24px; text-align: center; color: #6b7280; font-size: 12px; }
    .footer a { color: #10B981; text-decoration: none; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="logo">Sensalie<span>.</span></div>
    </div>

    <div class="content">
      <div class="headline">🎉 Du bist auf der Warteliste!</div>
      
      <div class="text">Hallo <strong>${contactName}</strong>,</div>
      
      <div class="text">vielen Dank für deine Registrierung! <strong>${businessName}</strong> ist jetzt auf der Sensalie Early-Access Warteliste und du gehörst zu den ersten 50 Unternehmern, die unser System nutzen können.</div>
      
      <div class="text">Du erhältst sehr bald eine E-Mail mit deinem Zugang und einer detaillierten Anleitung zum Start.</div>
      
      <div class="steps">
        <strong style="color: #1f2937;"><strong>${businessName}</strong></strong>
        <div class="step">Mindestbetrag pro Kauf für einen Stempel</div>
        <div class="step">Stempel erforderlich für Prämienerreichung</div>
      </div>
      
      <div class="text">Fragen? Schreib uns einfach eine Nachricht — wir helfen dir gerne weiter.</div>
      
      <div class="text">Bis bald!<br><strong>Das Sensalie Team</strong></div>
    </div>

    <div class="footer">
      <p>© 2026 Sensalie. Alle Rechte vorbehalten.</p>
    </div>
  </div>
</body>
</html>
    `;

    await base44.integrations.Core.SendEmail({
      to: email,
      subject: `🎉 ${businessName} ist jetzt auf der Sensalie Waitlist`,
      body: htmlContent
    });

    return Response.json({ success: true });
  } catch (error) {
    console.error("E-Mail Fehler:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});