import React, { useState, useEffect } from "react";
import { QrCode, Users, Stamp, Euro, Share2, ChevronRight, Settings, Check, Info, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";

function Tooltip({ text }) {
  const [show, setShow] = useState(false);
  return (
    <span style={{ position: "relative", display: "inline-flex", alignItems: "center", marginLeft: 6 }}>
      <span onMouseEnter={() => setShow(true)} onMouseLeave={() => setShow(false)}
        style={{ cursor: "pointer", color: "rgba(255,255,255,0.35)", display: "inline-flex" }}>
        <Info size={13} />
      </span>
      {show && (
        <span style={{ position: "absolute", bottom: "calc(100% + 8px)", left: "50%", transform: "translateX(-50%)", background: "#0A1612", color: "#F9FAFB", fontSize: 12, lineHeight: 1.5, padding: "8px 12px", borderRadius: 8, whiteSpace: "normal", maxWidth: 220, zIndex: 50, boxShadow: "0 4px 16px rgba(0,0,0,0.4)", border: "1px solid rgba(16,185,129,0.2)", pointerEvents: "none" }}>
          {text}
          <span style={{ position: "absolute", top: "100%", left: "50%", transform: "translateX(-50%)", width: 0, height: 0, borderLeft: "6px solid transparent", borderRight: "6px solid transparent", borderTop: "6px solid #0A1612" }} />
        </span>
      )}
    </span>
  );
}

export default function Business() {
  const { user } = useAuth();
  const [business, setBusiness] = useState(null);
  const [customers, setCustomers] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [payouts, setPayouts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeSection, setActiveSection] = useState(null);
  const [settings, setSettings] = useState({
    minAmountForStamp: "20", stampsForReward: "8", rewardDescription: "10€ Gutschein",
    provisionAfterVisits: "3", provisionType: "percentage", provisionValue: "10",
  });
  const [saved, setSaved] = useState(false);
  const [commissionSaved, setCommissionSaved] = useState(false);
  const [qrCopied, setQrCopied] = useState(false);

  useEffect(() => {
    const load = async () => {
      try {
        // Find the business owned by this user
        const bizList = await base44.entities.Business.list("-created_date", 100);
        const myBiz = bizList.find(b => b.created_by === user?.email) || bizList[0];
        if (!myBiz) { setLoading(false); return; }
        setBusiness(myBiz);
        // Pre-fill settings from DB
        setSettings({
          minAmountForStamp: String(myBiz.min_purchase_amount || "20"),
          stampsForReward: String(myBiz.stamps_required || "8"),
          rewardDescription: myBiz.reward_description || "10€ Gutschein",
          provisionAfterVisits: String(myBiz.payout_threshold_visits || "3"),
          provisionType: myBiz.provision_type || "percentage",
          provisionValue: String(myBiz.provision_value || "10"),
        });
        // Load customers, transactions, payouts
        const [custs, trans, pays] = await Promise.all([
          base44.entities.Customer.filter({ business_id: myBiz.id }, "-created_date", 200),
          base44.entities.StampTransaction.filter({ business_id: myBiz.id }, "-created_date", 200),
          base44.entities.ReferralPayout.filter({ business_id: myBiz.id }, "-created_date", 100),
        ]);
        setCustomers(custs);
        setTransactions(trans);
        setPayouts(pays);
      } catch (e) { console.error(e); }
      finally { setLoading(false); }
    };
    if (user) load();
  }, [user]);

  const today = new Date().toISOString().slice(0, 10);
  const stampsToday = transactions.filter(t => t.created_date?.slice(0, 10) === today).length;
  const openPayouts = payouts.filter(p => p.status === "offen").reduce((s, p) => s + p.amount, 0);
  const totalReferrals = payouts.length;

  // Calculations
  const minAmount = parseFloat(settings.minAmountForStamp) || 0;
  const visits = parseInt(settings.provisionAfterVisits) || 1;
  const minRevenue = (minAmount * visits).toFixed(2);
  const provisionValue = parseFloat(settings.provisionValue) || 0;
  const calculatedCommission = settings.provisionType === "percentage"
    ? (minRevenue * provisionValue / 100).toFixed(2)
    : provisionValue.toFixed(2);

  const handleSaveStamp = async () => {
    if (!business) return;
    await base44.entities.Business.update(business.id, {
      min_purchase_amount: parseFloat(settings.minAmountForStamp),
      stamps_required: parseInt(settings.stampsForReward),
      reward_description: settings.rewardDescription,
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleSaveCommission = async () => {
    if (!business) return;
    await base44.entities.Business.update(business.id, {
      payout_threshold_visits: parseInt(settings.provisionAfterVisits),
      provision_type: settings.provisionType,
      provision_value: parseFloat(settings.provisionValue),
    });
    setCommissionSaved(true);
    setTimeout(() => setCommissionSaved(false), 2000);
  };

  const scanUrl = business ? `${window.location.origin}/scan-landing/${business.id}` : "";

  const handleCopyQr = () => {
    navigator.clipboard.writeText(scanUrl);
    setQrCopied(true);
    setTimeout(() => setQrCopied(false), 2000);
  };

  // Recent activity from real transactions
  const recentActivity = transactions.slice(0, 6).map(t => {
    const cust = customers.find(c => c.id === t.customer_id);
    const name = cust?.name || cust?.phone || "Unbekannt";
    const initials = name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2) || "??";
    return { name, initials, action: "Stempel erhalten", time: new Date(t.created_date).toLocaleDateString("de-DE") };
  });

  if (loading) {
    return (
      <div style={{ minHeight: "100vh", background: "#0A1612", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <Loader2 size={32} color="#10B981" style={{ animation: "spin 1s linear infinite" }} />
        <style>{`@keyframes spin { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }`}</style>
      </div>
    );
  }

  // Auth guard — nur eingeloggte User mit Business-Rolle
  if (!loading && !user) {
    return (
      <div style={{ minHeight: "100vh", background: "#0A1612", display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", gap: 16, color: "#fff", fontFamily: "'Inter', sans-serif", padding: 24 }}>
        <div style={{ fontSize: 40 }}>🔒</div>
        <div style={{ fontSize: 18, fontWeight: 700 }}>Anmeldung erforderlich</div>
        <div style={{ fontSize: 13, color: "rgba(255,255,255,0.4)", textAlign: "center" }}>Bitte melde dich an, um das Business-Dashboard zu sehen.</div>
        <a href="/" style={{ marginTop: 8, padding: "12px 28px", background: "#10B981", color: "#fff", fontWeight: 700, borderRadius: 14, textDecoration: "none", fontSize: 14 }}>Zur Startseite →</a>
      </div>
    );
  }

  if (!business) {
    return (
      <div style={{ minHeight: "100vh", background: "#0A1612", display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", gap: 16, color: "#fff", fontFamily: "'Inter', sans-serif" }}>
        <div style={{ fontSize: 32 }}>🏪</div>
        <div style={{ fontSize: 16, fontWeight: 700 }}>Kein Unternehmen gefunden</div>
        <div style={{ fontSize: 13, color: "rgba(255,255,255,0.4)" }}>Bitte wende dich an den Administrator.</div>
        <a href="/" style={{ color: "#10B981", fontSize: 13, textDecoration: "none" }}>← Zurück zur Startseite</a>
      </div>
    );
  }

  return (
    <div style={{ minHeight: "100vh", background: "#0A1612", fontFamily: "'Inter', sans-serif", position: "relative", overflow: "hidden" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
        * { box-sizing: border-box; }
        .bg-glow { position: fixed; top: -120px; left: -80px; width: 480px; height: 480px; background: radial-gradient(circle, rgba(16,185,129,0.22) 0%, transparent 70%); pointer-events: none; z-index: 0; }
        .page-content { position: relative; z-index: 1; }
        .hero-card { background: linear-gradient(135deg, rgba(16,185,129,0.10) 0%, rgba(10,22,18,0.0) 60%); border: 1px solid rgba(255,255,255,0.08); border-radius: 20px; padding: 36px; margin-bottom: 16px; }
        .stat-divider { width: 1px; background: rgba(255,255,255,0.12); align-self: stretch; }
        .ghost-btn { background: transparent; border: 1.5px solid rgba(255,255,255,0.6); color: #fff; font-weight: 600; font-size: 14px; padding: 12px 22px; border-radius: 10px; cursor: pointer; font-family: inherit; transition: background 0.2s, border-color 0.2s; white-space: nowrap; }
        .ghost-btn:hover { background: rgba(255,255,255,0.1); border-color: #fff; }
        .dark-card { background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.08); border-radius: 20px; padding: 28px; margin-bottom: 16px; }
        .settings-input { width: 100%; border: 1.5px solid rgba(255,255,255,0.12); border-radius: 10px; padding: 10px 14px; font-size: 15px; outline: none; font-family: inherit; color: #fff; background: rgba(255,255,255,0.05); transition: border-color 0.2s; }
        .settings-input:focus { border-color: #10B981; background: rgba(16,185,129,0.06); }
        .activity-item { display: flex; align-items: center; gap: 12px; padding: 13px 0; border-bottom: 1px solid rgba(255,255,255,0.06); }
        .activity-item:last-child { border-bottom: none; }
        .avatar { width: 38px; height: 38px; border-radius: 50%; background: linear-gradient(135deg, #10B981, #059669); display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: 700; color: #fff; flex-shrink: 0; }
        @keyframes spin { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }
        @media(max-width: 640px) {
          .stats-row { flex-direction: column !important; gap: 16px !important; }
          .stat-divider { display: none !important; }
          .action-btns { flex-direction: column !important; }
          .hero-card { padding: 24px !important; }
          .dark-card { padding: 20px !important; }
          .main-content { padding: 16px 16px 60px !important; }
          .two-col { grid-template-columns: 1fr !important; }
        }
      `}</style>

      <div className="bg-glow" />

      {/* Header */}
      <div style={{ background: "rgba(10,22,18,0.9)", backdropFilter: "blur(16px)", borderBottom: "1px solid rgba(255,255,255,0.07)", padding: "0 24px", position: "sticky", top: 0, zIndex: 10 }}>
        <div style={{ maxWidth: 960, margin: "0 auto", height: 64, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 36, height: 36, background: "#10B981", borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <span style={{ fontSize: 16 }}>🏪</span>
            </div>
            <div>
              <div style={{ fontSize: 16, fontWeight: 700, color: "#fff", lineHeight: 1.2 }}>{business.name}</div>
              <div style={{ fontSize: 11, color: "rgba(255,255,255,0.35)", fontWeight: 500 }}>Business Dashboard</div>
            </div>
          </div>
          <a href="/" style={{ fontSize: 13, color: "rgba(255,255,255,0.4)", textDecoration: "none", fontWeight: 500 }}
            onMouseEnter={e => e.currentTarget.style.color = "#fff"}
            onMouseLeave={e => e.currentTarget.style.color = "rgba(255,255,255,0.4)"}>
            ← Abmelden
          </a>
        </div>
      </div>

      <div className="page-content main-content" style={{ maxWidth: 960, margin: "0 auto", padding: "32px 24px 60px" }}>

        {/* Onboarding Banner — zeigt sich wenn noch keine Kunden */}
        {customers.length === 0 && !loading && (
          <div style={{ background: "linear-gradient(135deg, rgba(16,185,129,0.15), rgba(16,185,129,0.05))", border: "1px solid rgba(16,185,129,0.3)", borderRadius: 20, padding: "20px 24px", marginBottom: 16, display: "flex", alignItems: "flex-start", gap: 16 }}>
            <div style={{ fontSize: 28, flexShrink: 0 }}>🚀</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 15, fontWeight: 800, color: "#fff", marginBottom: 6 }}>Dein Business ist live — jetzt starten!</div>
              <div style={{ fontSize: 12, color: "rgba(255,255,255,0.5)", lineHeight: 1.6, marginBottom: 14 }}>
                Noch keine Kunden? Teile deinen QR-Code mit deinen Kunden, damit sie sofort Stempel sammeln können.
              </div>
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                <div style={{ fontSize: 11, color: "#10B981", background: "rgba(16,185,129,0.12)", border: "1px solid rgba(16,185,129,0.25)", borderRadius: 8, padding: "5px 12px", fontWeight: 600 }}>① QR-Code teilen</div>
                <div style={{ fontSize: 11, color: "rgba(255,255,255,0.5)", background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, padding: "5px 12px", fontWeight: 600 }}>② Stempel konfigurieren</div>
                <div style={{ fontSize: 11, color: "rgba(255,255,255,0.5)", background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, padding: "5px 12px", fontWeight: 600 }}>③ Kunden sammeln Stempel</div>
              </div>
            </div>
          </div>
        )}

        {/* Hero card */}
        <div className="hero-card">
          <h1 style={{ fontSize: "clamp(22px, 4vw, 30px)", fontWeight: 800, color: "#fff", margin: "0 0 4px" }}>
            {`Guten ${new Date().getHours() < 12 ? "Morgen" : new Date().getHours() < 18 ? "Tag" : "Abend"}`} 👋
          </h1>
          <p style={{ color: "rgba(255,255,255,0.5)", fontSize: 15, margin: "0 0 32px" }}>Hier ist dein Überblick für heute.</p>

          {/* Stats */}
          <div className="stats-row" style={{ display: "flex", alignItems: "stretch", gap: 0, marginBottom: 32 }}>
            {[
              { label: "Aktive Kunden", value: customers.length, tip: "Anzahl registrierter Kunden." },
              { label: "Stempel heute", value: stampsToday, tip: "Stempel die heute vergeben wurden." },
              { label: "Offene Provisionen", value: `${openPayouts.toFixed(2)}€`, tip: "Noch nicht ausgezahlte Provisionen." },
              { label: "Empfehlungen", value: totalReferrals, tip: "Gesamte Empfehlungen aller Kunden." },
            ].map((s, i, arr) => (
              <React.Fragment key={s.label}>
                <div style={{ flex: 1, paddingLeft: i === 0 ? 0 : 28, paddingRight: 28 }}>
                  <div style={{ fontSize: 28, fontWeight: 800, color: "#fff", lineHeight: 1 }}>{s.value}</div>
                  <div style={{ fontSize: 13, color: "rgba(255,255,255,0.45)", marginTop: 6, display: "flex", alignItems: "center" }}>
                    {s.label}<Tooltip text={s.tip} />
                  </div>
                </div>
                {i < arr.length - 1 && <div className="stat-divider" />}
              </React.Fragment>
            ))}
          </div>

          {/* Actions */}
          <div className="action-btns" style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
            <button className="ghost-btn" onClick={() => setActiveSection(activeSection === "stamp" ? null : "stamp")}>
              Stempelkarte konfigurieren
            </button>
            <button className="ghost-btn" onClick={() => setActiveSection(activeSection === "commission" ? null : "commission")}>
              Provisionsmodell anpassen
            </button>
            <button className="ghost-btn" onClick={() => setActiveSection(activeSection === "qr" ? null : "qr")}>
              <QrCode size={14} style={{ marginRight: 6, display: "inline" }} />QR-Code
            </button>
          </div>
        </div>

        {/* QR Code Section */}
        {activeSection === "qr" && (
          <div className="dark-card">
            <div style={{ fontWeight: 700, color: "#fff", fontSize: 16, marginBottom: 6 }}>Dein Scan-Link</div>
            <div style={{ fontSize: 12, color: "rgba(255,255,255,0.4)", marginBottom: 20 }}>Teile diesen Link oder QR-Code mit deinen Kunden — direkt beim Kauf scannen.</div>
            <div style={{ background: "#fff", borderRadius: 12, padding: 16, display: "inline-block", marginBottom: 16 }}>
              <img src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(scanUrl)}`} alt="QR" style={{ display: "block", width: 180, height: 180 }} />
            </div>
            <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
              <div style={{ flex: 1, background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 10, padding: "10px 14px", fontSize: 12, color: "rgba(255,255,255,0.5)", wordBreak: "break-all", fontFamily: "monospace" }}>{scanUrl}</div>
              <button onClick={handleCopyQr} style={{ padding: "10px 18px", background: qrCopied ? "#059669" : "#10B981", color: "#fff", fontWeight: 700, fontSize: 13, borderRadius: 10, border: "none", cursor: "pointer", fontFamily: "inherit", whiteSpace: "nowrap" }}>
                {qrCopied ? "✓ Kopiert" : "Link kopieren"}
              </button>
            </div>
          </div>
        )}

        {/* Stamp Settings */}
        {activeSection === "stamp" && (
          <div className="dark-card">
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}>
              <div style={{ width: 34, height: 34, background: "rgba(255,255,255,0.07)", borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center" }}>
                <Settings size={16} color="rgba(255,255,255,0.5)" />
              </div>
              <div>
                <div style={{ fontWeight: 700, color: "#fff", fontSize: 16 }}>Stempelkarte konfigurieren</div>
                <div style={{ fontSize: 12, color: "rgba(255,255,255,0.35)" }}>Passe dein Belohnungssystem an</div>
              </div>
            </div>

            <div className="two-col" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24, marginBottom: 20 }}>
              <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                <div>
                  <label style={{ display: "flex", alignItems: "center", fontSize: 13, fontWeight: 600, color: "rgba(255,255,255,0.6)", marginBottom: 7 }}>
                    Ab welchem Betrag gibt es einen Stempel? (€)<Tooltip text="Mindestbetrag pro Einkauf." />
                  </label>
                  <input type="number" min="5" className="settings-input" value={settings.minAmountForStamp}
                    onChange={e => setSettings({ ...settings, minAmountForStamp: e.target.value })} placeholder="z.B. 15" />
                </div>
                <div>
                  <label style={{ display: "flex", alignItems: "center", fontSize: 13, fontWeight: 600, color: "rgba(255,255,255,0.6)", marginBottom: 7 }}>
                    Stempel bis zur Prämie<Tooltip text="Wie viele Stempel für eine Belohnung." />
                  </label>
                  <select className="settings-input" value={settings.stampsForReward}
                    onChange={e => setSettings({ ...settings, stampsForReward: e.target.value })} style={{ cursor: "pointer" }}>
                    {[5, 6, 7, 8, 9, 10].map(v => <option key={v} value={v}>{v} Stempel</option>)}
                  </select>
                </div>
                <div>
                  <label style={{ display: "flex", alignItems: "center", fontSize: 13, fontWeight: 600, color: "rgba(255,255,255,0.6)", marginBottom: 7 }}>
                    Was ist die Belohnung?
                  </label>
                  <input type="text" className="settings-input" value={settings.rewardDescription}
                    onChange={e => setSettings({ ...settings, rewardDescription: e.target.value })} placeholder="z.B. 10€ Gutschein" />
                </div>
              </div>

              {/* Preview */}
              <div style={{ display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center" }}>
                <div style={{ fontSize: 12, color: "rgba(255,255,255,0.45)", marginBottom: 16, textAlign: "center" }}>Vorschau</div>
                <div style={{ background: "linear-gradient(135deg, rgba(16,185,129,0.12), rgba(16,185,129,0.04))", border: "2px solid rgba(16,185,129,0.3)", borderRadius: 16, padding: 20, width: "100%", maxWidth: 240 }}>
                  <div style={{ textAlign: "center", marginBottom: 14 }}>
                    <div style={{ fontSize: 11, color: "rgba(255,255,255,0.45)", fontWeight: 600, letterSpacing: 1 }}>STEMPELKARTE</div>
                    <div style={{ fontSize: 13, color: "#fff", fontWeight: 700, marginTop: 4 }}>{business.name}</div>
                  </div>
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 6, marginBottom: 14 }}>
                    {Array.from({ length: parseInt(settings.stampsForReward) }).map((_, i) => (
                      <div key={i} style={{ aspectRatio: "1/1", background: i < 2 ? "#10B981" : "rgba(16,185,129,0.15)", borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 700, color: i < 2 ? "#fff" : "rgba(0,0,0,0.2)" }}>
                        {i < 2 ? "✓" : ""}
                      </div>
                    ))}
                  </div>
                  <div style={{ borderTop: "1px solid rgba(16,185,129,0.2)", paddingTop: 10, textAlign: "center" }}>
                    <div style={{ fontSize: 12, fontWeight: 700, color: "#10B981", padding: "6px 10px", background: "rgba(16,185,129,0.15)", borderRadius: 6, display: "inline-block" }}>
                      🎁 {settings.rewardDescription}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <button onClick={handleSaveStamp} style={{ background: saved ? "#059669" : "#10B981", color: "#fff", fontWeight: 700, fontSize: 14, padding: "11px 24px", borderRadius: 10, border: "none", cursor: "pointer", display: "flex", alignItems: "center", gap: 8, fontFamily: "inherit" }}>
              {saved ? <><Check size={15} /> Gespeichert!</> : "Einstellungen speichern"}
            </button>
          </div>
        )}

        {/* Commission Settings */}
        {activeSection === "commission" && (
          <div className="dark-card">
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}>
              <div style={{ width: 34, height: 34, background: "rgba(255,255,255,0.07)", borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center" }}>
                <Euro size={16} color="rgba(255,255,255,0.5)" />
              </div>
              <div>
                <div style={{ fontWeight: 700, color: "#fff", fontSize: 16 }}>Provisionsmodell</div>
                <div style={{ fontSize: 12, color: "rgba(255,255,255,0.35)" }}>Mindestumsatz und Provision für Empfehlungen</div>
              </div>
            </div>

            <div className="two-col" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24, marginBottom: 20 }}>
              <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                <div>
                  <label style={{ display: "flex", alignItems: "center", fontSize: 13, fontWeight: 600, color: "rgba(255,255,255,0.6)", marginBottom: 7 }}>
                    Mindestumsatz für Provision<Tooltip text="Nach wie vielen Besuchen wird Provision ausgelöst?" />
                  </label>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
                    <div>
                      <label style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", marginBottom: 4, display: "block" }}>Betrag pro Stempel (€)</label>
                      <input type="number" min="5" className="settings-input" value={settings.minAmountForStamp}
                        onChange={e => setSettings({ ...settings, minAmountForStamp: e.target.value })} placeholder="z.B. 20" />
                    </div>
                    <div>
                      <label style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", marginBottom: 4, display: "block" }}>Nach X Besuchen</label>
                      <select className="settings-input" value={settings.provisionAfterVisits}
                        onChange={e => setSettings({ ...settings, provisionAfterVisits: e.target.value })} style={{ cursor: "pointer" }}>
                        {[2, 3, 4, 5].map(v => <option key={v} value={v}>{v}</option>)}
                      </select>
                    </div>
                  </div>
                </div>

                <div>
                  <label style={{ display: "flex", alignItems: "center", fontSize: 13, fontWeight: 600, color: "rgba(255,255,255,0.6)", marginBottom: 7 }}>
                    Provision für Empfehlung<Tooltip text="% vom Umsatz oder fester Betrag?" />
                  </label>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
                    <select className="settings-input" value={settings.provisionType}
                      onChange={e => setSettings({ ...settings, provisionType: e.target.value })} style={{ cursor: "pointer" }}>
                      <option value="percentage">% vom Umsatz</option>
                      <option value="fixed">Fester Betrag (€)</option>
                    </select>
                    <input type="number" min="0" className="settings-input" value={settings.provisionValue}
                      onChange={e => setSettings({ ...settings, provisionValue: e.target.value })}
                      placeholder={settings.provisionType === "percentage" ? "z.B. 10" : "z.B. 5"} />
                  </div>
                </div>

                <div style={{ background: "rgba(16,185,129,0.08)", border: "1px solid rgba(16,185,129,0.2)", borderRadius: 12, padding: 14 }}>
                  <div style={{ fontSize: 11, color: "rgba(255,255,255,0.45)", marginBottom: 6 }}>Provision pro Empfehlung</div>
                  <div style={{ fontSize: 20, fontWeight: 700, color: "#10B981" }}>{calculatedCommission}€</div>
                  <div style={{ fontSize: 10, color: "rgba(255,255,255,0.35)", marginTop: 4 }}>
                    {settings.provisionType === "percentage" ? `${provisionValue}% von ${minRevenue}€` : "Fester Betrag"}
                  </div>
                </div>
              </div>

              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                <div style={{ background: "rgba(0,184,148,0.12)", border: "1px solid rgba(0,184,148,0.3)", borderRadius: 12, padding: 14 }}>
                  <div style={{ fontSize: 12, fontWeight: 600, color: "#10B981", marginBottom: 8 }}>💡 So funktioniert's</div>
                  <ul style={{ margin: 0, paddingLeft: 16, color: "rgba(255,255,255,0.6)", fontSize: 11, lineHeight: 1.6 }}>
                    <li>Neukunde kommt → mind. {minAmount}€ = 1 Stempel</li>
                    <li>Nach {visits} Besuchen (Gesamt: {minRevenue}€) → Provision fällig</li>
                    <li>Empfehler erhält <strong>{calculatedCommission}€</strong></li>
                  </ul>
                </div>
                <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 12, padding: 14 }}>
                  <div style={{ fontSize: 12, fontWeight: 600, color: "rgba(255,255,255,0.8)", marginBottom: 8 }}>🎯 Tipp</div>
                  <div style={{ color: "rgba(255,255,255,0.5)", fontSize: 11, lineHeight: 1.6 }}>
                    Je höher die Provision, desto mehr Neukunden bringt dein Kundenstamm.
                  </div>
                </div>
              </div>
            </div>

            <button onClick={handleSaveCommission} style={{ background: commissionSaved ? "#059669" : "#10B981", color: "#fff", fontWeight: 700, fontSize: 14, padding: "11px 24px", borderRadius: 10, border: "none", cursor: "pointer", display: "flex", alignItems: "center", gap: 8, fontFamily: "inherit" }}>
              {commissionSaved ? <><Check size={15} /> Gespeichert!</> : "Einstellungen speichern"}
            </button>
          </div>
        )}

        {/* Activity */}
        <div className="dark-card" style={{ marginBottom: 0 }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
            <div style={{ fontWeight: 700, color: "#fff", fontSize: 16 }}>Letzte Aktivitäten</div>
          </div>
          {recentActivity.length === 0 ? (
            <div style={{ padding: "24px 0", textAlign: "center", color: "rgba(255,255,255,0.3)", fontSize: 13 }}>
              Noch keine Aktivitäten — teile deinen QR-Code!
            </div>
          ) : recentActivity.map((item, i) => (
            <div key={i} className="activity-item">
              <div className="avatar">{item.initials}</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 600, fontSize: 14, color: "#fff" }}>{item.name}</div>
                <div style={{ fontSize: 13, color: "rgba(255,255,255,0.4)", marginTop: 1 }}>{item.action}</div>
              </div>
              <div style={{ fontSize: 12, color: "rgba(255,255,255,0.2)", flexShrink: 0 }}>{item.time}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}