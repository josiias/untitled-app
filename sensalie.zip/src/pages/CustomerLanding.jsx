import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import PhoneDemo from "@/components/customer/PhoneDemo";

// Hero background images — real lifestyle shots
const BG_IMAGES = [
  "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1200&q=85",
  "https://images.unsplash.com/photo-1554118811-1e0d58224f24?w=1200&q=85",
  "https://images.unsplash.com/photo-1560066984-138dadb4c035?w=1200&q=85",
  "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?w=1200&q=85",
];



const PARTNERS = [
  { emoji: "✂️", name: "Barbershops", img: "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?w=800&q=90" },
  { emoji: "☕", name: "Cafés", img: "https://images.unsplash.com/photo-1554118811-1e0d58224f24?w=800&q=90" },
  { emoji: "💅", name: "Nagelstudios", img: "https://images.unsplash.com/photo-1604654894610-df63bc536371?w=800&q=90" },
  { emoji: "💆", name: "Massagestudios", img: "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=800&q=90" },
  { emoji: "🍕", name: "Restaurants", img: "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&q=90" },
  { emoji: "💇", name: "Friseursalons", img: "https://images.unsplash.com/photo-1560066984-138dadb4c035?w=800&q=90" },
  { emoji: "🛍️", name: "Lokale Läden", img: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=800&q=90" },
];



function RegisterModal({ onClose, mode }) {
  const [step, setStep] = useState(mode === "login" ? 2 : 1);
  const [form, setForm] = useState({ name: "", phone: "", email: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleRegister = async (e) => {
    e.preventDefault();
    if (!form.name.trim() || (!form.phone.trim() && !form.email.trim())) { setError("Bitte mindestens Telefon oder E-Mail eingeben."); return; }
    setLoading(true); setError("");
    try {
      const contactField = form.phone.trim() || form.email.trim();
      const filterKey = form.phone.trim() ? "phone" : "email";
      const existing = await base44.entities.Customer.filter({ [filterKey]: contactField });
      if (existing?.length > 0) { setError("Dieser Kontakt ist bereits registriert. Bitte melde dich an."); setLoading(false); return; }

      // Resolve referral code from URL
      const urlRef = new URLSearchParams(window.location.search).get("ref");
      let referredById = null;
      if (urlRef) {
        const referrers = await base44.entities.Customer.filter({ referral_code: urlRef }, "-created_date", 1);
        if (referrers.length > 0) referredById = referrers[0].id;
      }

      const newReferralCode = form.name.split(" ")[0].toUpperCase().slice(0, 4) + Math.random().toString(36).slice(2, 6).toUpperCase();
      const custData = {
        name: form.name.trim(),
        phone: form.phone.trim() || undefined,
        email: form.email.trim() || undefined,
        referral_code: newReferralCode, total_stamps: 0, total_visits: 0,
        provision_earned: 0, provision_paid: 0,
      };
      if (referredById) custData.referred_by = referredById;
      const newCustomer = await base44.entities.Customer.create(custData);
      // Persist session — localStorage survives tab close
      localStorage.setItem("sensalie_customer_id", newCustomer.id);
      localStorage.setItem("sensalie_customer_phone", form.phone.trim() || form.email.trim());
      sessionStorage.setItem("customer_id", newCustomer.id);
      sessionStorage.setItem("customer_phone", form.phone.trim() || form.email.trim());
      setStep(99);
      setTimeout(() => navigate("/customer-dashboard"), 2000);
    } catch { setError("Fehler. Bitte versuche es erneut."); }
    setLoading(false);
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    if (!form.phone.trim()) { setError("Bitte gib deine Nummer ein."); return; }
    setLoading(true); setError("");
    try {
      const existing = await base44.entities.Customer.filter({ phone: form.phone });
      if (!existing?.length) { setError("Kein Konto mit dieser Nummer gefunden."); setLoading(false); return; }
      // Persist session — localStorage survives tab close
      localStorage.setItem("sensalie_customer_id", existing[0].id);
      localStorage.setItem("sensalie_customer_phone", form.phone.trim());
      sessionStorage.setItem("customer_id", existing[0].id);
      sessionStorage.setItem("customer_phone", form.phone.trim());
      navigate("/customer-dashboard");
    } catch { setError("Fehler beim Anmelden."); }
    setLoading(false);
  };

  const inp = { width: "100%", padding: "15px 18px", background: "rgba(255,255,255,0.07)", border: "1.5px solid rgba(255,255,255,0.12)", borderRadius: 16, fontSize: 15, color: "#fff", fontFamily: "inherit", outline: "none", boxSizing: "border-box" };

  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.8)", backdropFilter: "blur(20px)", display: "flex", alignItems: "flex-end", justifyContent: "center", zIndex: 100 }}>
      <div onClick={e => e.stopPropagation()} style={{ background: "#0d1520", borderRadius: "32px 32px 0 0", padding: "28px 24px 52px", width: "100%", maxWidth: 480, borderTop: "1px solid rgba(255,255,255,0.1)", animation: "slideUp 0.35s ease" }}>
        <div style={{ width: 40, height: 4, borderRadius: 100, background: "rgba(255,255,255,0.15)", margin: "0 auto 28px" }} />

        {step === 1 && (
          <>
            <div style={{ fontSize: 24, fontWeight: 900, color: "#fff", marginBottom: 4 }}>Konto erstellen</div>
            <div style={{ fontSize: 13, color: "rgba(255,255,255,0.35)", marginBottom: 24 }}>Kostenlos — in 30 Sekunden</div>
            <form onSubmit={handleRegister} style={{ display: "flex", flexDirection: "column", gap: 16 }}>
              <input placeholder="Dein Name" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} style={inp} onFocus={e => e.target.style.borderColor = "#10B981"} onBlur={e => e.target.style.borderColor = "rgba(255,255,255,0.12)"} />
              
              <div>
                <input placeholder="Telefonnummer" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} type="tel" style={inp} onFocus={e => e.target.style.borderColor = "#10B981"} onBlur={e => e.target.style.borderColor = "rgba(255,255,255,0.12)"} />
                <div style={{ fontSize: 11, color: "rgba(255,255,255,0.35)", marginTop: 6, marginLeft: 2 }}>→ Sofortige Benachrichtigungen bei Aktionen</div>
              </div>

              <div>
                <input placeholder="E-Mail" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} type="email" style={inp} onFocus={e => e.target.style.borderColor = "#10B981"} onBlur={e => e.target.style.borderColor = "rgba(255,255,255,0.12)"} />
                <div style={{ fontSize: 11, color: "rgba(255,255,255,0.35)", marginTop: 6, marginLeft: 2 }}>→ Updates, neue Partner & Programme</div>
              </div>

              <div style={{ fontSize: 11, color: "rgba(255,255,255,0.3)", fontStyle: "italic" }}>Mindestens eins ausfüllen</div>

              {error && <div style={{ fontSize: 12, color: "#ef4444", padding: "10px 14px", background: "rgba(239,68,68,0.1)", borderRadius: 12 }}>{error}</div>}
              <button type="submit" disabled={loading} style={{ padding: "16px", background: "#10B981", color: "#fff", fontWeight: 800, fontSize: 16, borderRadius: 16, border: "none", cursor: "pointer", fontFamily: "inherit", marginTop: 6, boxShadow: "0 8px 24px rgba(16,185,129,0.3)" }}>
                {loading ? "Wird erstellt..." : "Registrieren →"}
              </button>
              <button type="button" onClick={() => setStep(2)} style={{ fontSize: 13, color: "rgba(255,255,255,0.4)", background: "none", border: "none", cursor: "pointer", fontFamily: "inherit", marginTop: 4 }}>Bereits ein Konto? Anmelden</button>
            </form>
          </>
        )}

        {step === 2 && (
          <>
            <div style={{ fontSize: 24, fontWeight: 900, color: "#fff", marginBottom: 4 }}>Willkommen zurück</div>
            <div style={{ fontSize: 13, color: "rgba(255,255,255,0.35)", marginBottom: 28 }}>Melde dich mit deiner Nummer an</div>
            <form onSubmit={handleLogin} style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              <input placeholder="Telefonnummer" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} type="tel" autoFocus style={inp} onFocus={e => e.target.style.borderColor = "#10B981"} onBlur={e => e.target.style.borderColor = "rgba(255,255,255,0.12)"} />
              {error && <div style={{ fontSize: 12, color: "#ef4444", padding: "10px 14px", background: "rgba(239,68,68,0.1)", borderRadius: 12 }}>{error}</div>}
              <button type="submit" disabled={loading} style={{ padding: "16px", background: "#10B981", color: "#fff", fontWeight: 800, fontSize: 16, borderRadius: 16, border: "none", cursor: "pointer", fontFamily: "inherit", marginTop: 6, boxShadow: "0 8px 24px rgba(16,185,129,0.3)" }}>
                {loading ? "Anmelden..." : "Anmelden →"}
              </button>
              <button type="button" onClick={() => setStep(1)} style={{ fontSize: 13, color: "rgba(255,255,255,0.4)", background: "none", border: "none", cursor: "pointer", fontFamily: "inherit", marginTop: 4 }}>Noch kein Konto? Registrieren</button>
            </form>
          </>
        )}

        {step === 99 && (
          <div style={{ textAlign: "center", padding: "16px 0" }}>
            <div style={{ fontSize: 52, marginBottom: 16 }}>🎉</div>
            <div style={{ fontSize: 22, fontWeight: 900, color: "#fff", marginBottom: 8 }}>Willkommen!</div>
            <div style={{ fontSize: 14, color: "rgba(255,255,255,0.4)", lineHeight: 1.6 }}>Dein Konto ist bereit.<br />Du wirst weitergeleitet...</div>
            <div style={{ marginTop: 24, height: 3, background: "rgba(255,255,255,0.08)", borderRadius: 100, overflow: "hidden" }}>
              <div style={{ height: "100%", background: "#10B981", borderRadius: 100, animation: "progressBar 2s linear forwards" }} />
            </div>
          </div>
        )}
      </div>
      <style>{`@keyframes slideUp{from{transform:translateY(100%)}to{transform:translateY(0)}} @keyframes progressBar{from{width:0}to{width:100%}}`}</style>
    </div>
  );
}

export default function CustomerLanding() {
  const [bgIndex, setBgIndex] = useState(0);
  const [partnerIndex, setPartnerIndex] = useState(0);
  const [modal, setModal] = useState(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    setTimeout(() => setLoaded(true), 80);
    const bgInterval = setInterval(() => setBgIndex(i => (i + 1) % BG_IMAGES.length), 4500);
    const partnerInterval = setInterval(() => setPartnerIndex(i => (i + 1) % PARTNERS.length), 4000);
    return () => { clearInterval(bgInterval); clearInterval(partnerInterval); };
  }, []);

  return (
    <div style={{ background: "#060c12", minHeight: "100vh", fontFamily: "'Inter', sans-serif", color: "#fff", overflowX: "hidden" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');
        @keyframes fadeSlide { from{opacity:0;transform:translateY(24px)} to{opacity:1;transform:translateY(0)} }
        @keyframes bgFade { from{opacity:0} to{opacity:1} }
        @keyframes floatBadge { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-6px)} }
        @keyframes scrollHint { 0%,100%{opacity:0.3;transform:translateY(0)} 50%{opacity:0.7;transform:translateY(6px)} }
        @keyframes ctaPulse { 0%,100%{box-shadow:0 12px 40px rgba(16,185,129,0.4)} 50%{box-shadow:0 12px 60px rgba(16,185,129,0.75), 0 0 0 8px rgba(16,185,129,0.12)} }
        @keyframes mapPing { 0%{transform:scale(1);opacity:1} 100%{transform:scale(2.8);opacity:0} }
      `}</style>

      {/* Top bar */}
      <div style={{ position: "fixed", top: 0, left: 0, right: 0, zIndex: 50, padding: "14px 24px", display: "flex", alignItems: "center", justifyContent: "space-between", background: "rgba(6,12,18,0.8)", backdropFilter: "blur(20px)", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
        <div style={{ fontSize: 18, fontWeight: 900, letterSpacing: -0.5 }}>Sensalie<span style={{ color: "#10B981" }}>.</span></div>
        <button onClick={() => setModal("login")} style={{ padding: "8px 18px", background: "rgba(255,255,255,0.07)", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 100, fontSize: 13, fontWeight: 600, color: "#fff", cursor: "pointer", fontFamily: "inherit" }}>
          Anmelden
        </button>
      </div>

      {/* ── HERO ── */}
      <div style={{ position: "relative", minHeight: "100vh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", overflow: "hidden", padding: "110px 24px 80px" }}>

        {/* Sliding background images */}
        {BG_IMAGES.map((img, i) => (
          <div key={i} style={{
            position: "absolute", inset: 0, zIndex: 0,
            backgroundImage: `url(${img})`,
            backgroundSize: "cover", backgroundPosition: "center",
            opacity: i === bgIndex ? 1 : 0,
            transition: "opacity 1.2s ease",
          }} />
        ))}

        {/* Dark overlay with green tint */}
        <div style={{ position: "absolute", inset: 0, zIndex: 1, background: "linear-gradient(180deg, rgba(6,12,18,0.85) 0%, rgba(6,12,18,0.75) 40%, rgba(6,12,18,0.92) 80%, rgba(6,12,18,1) 100%)" }} />

        {/* Green glow top */}
        <div style={{ position: "absolute", top: -100, left: "50%", transform: "translateX(-50%)", width: 500, height: 400, background: "radial-gradient(ellipse, rgba(16,185,129,0.18) 0%, transparent 70%)", zIndex: 2, pointerEvents: "none" }} />

        {/* Content — two column on desktop, stacked on mobile */}
         <div style={{
           position: "relative", zIndex: 3,
           width: "100%", maxWidth: 900,
           display: "flex", flexDirection: "row", alignItems: "center",
           gap: 48, flexWrap: "wrap",
           justifyContent: "center",
           "@media (max-width: 640px)": { flexDirection: "column", textAlign: "center" },
         }}>

          {/* LEFT: Text */}
          <div style={{ flex: "1 1 300px", minWidth: 280, maxWidth: 460, width: "100%", display: "flex", flexDirection: "column", alignItems: "center" }}>

            {/* Big headline row 1 */}
            <div style={{ opacity: loaded ? 1 : 0, animation: loaded ? "fadeSlide 0.6s ease 0.05s both" : "none" }}>
              <div style={{ fontSize: "clamp(32px, 8vw, 52px)", fontWeight: 900, color: "#fff", lineHeight: 1.05, letterSpacing: -1.5, marginBottom: 4 }}>
                Sammel digitale
              </div>
              <div style={{ fontSize: "clamp(32px, 8vw, 52px)", fontWeight: 900, lineHeight: 1.05, letterSpacing: -1.5, marginBottom: 28 }}>
                <span style={{ color: "#10B981" }}>Stempelkarten</span>
              </div>
            </div>

            {/* Row 2 */}
            <div style={{ opacity: loaded ? 1 : 0, animation: loaded ? "fadeSlide 0.6s ease 0.15s both" : "none" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
                <span style={{ fontSize: 28 }}>🎁</span>
                <div style={{ fontSize: "clamp(22px, 5.5vw, 34px)", fontWeight: 900, color: "#fff", letterSpacing: -1, lineHeight: 1.1 }}>
                  Hol dir großartige Prämien
                </div>
              </div>
              <div style={{ fontSize: 13, color: "rgba(255,255,255,0.4)", marginBottom: 24, marginLeft: 38, lineHeight: 1.5 }}>
                Rabatte, Gratisleistungen & mehr
              </div>
            </div>

            {/* Row 3 — smaller */}
            <div style={{ opacity: loaded ? 1 : 0, animation: loaded ? "fadeSlide 0.6s ease 0.25s both" : "none" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
                <span style={{ fontSize: 22 }}>💸</span>
                <div style={{ fontSize: "clamp(17px, 4vw, 24px)", fontWeight: 800, color: "rgba(255,255,255,0.7)", letterSpacing: -0.5, lineHeight: 1.2 }}>
                  Verdiene <span style={{ color: "#10B981" }}>100 € und mehr</span>
                </div>
              </div>
              <div style={{ fontSize: 12, color: "rgba(255,255,255,0.35)", marginLeft: 32, marginBottom: 36, lineHeight: 1.5 }}>
                Einfach durch Empfehlen. Passiv. Automatisch.
              </div>
            </div>

            {/* CTAs */}
            <div style={{ opacity: loaded ? 1 : 0, animation: loaded ? "fadeSlide 0.6s ease 0.35s both" : "none", display: "flex", flexDirection: "column", gap: 10, maxWidth: 320, width: "100%" }}>
              <button onClick={() => setModal("register")} style={{ padding: "16px 24px", background: "#10B981", color: "#fff", fontWeight: 800, fontSize: 15, borderRadius: 16, border: "none", cursor: "pointer", fontFamily: "inherit", animation: "ctaPulse 2.4s ease-in-out infinite" }}
                onMouseEnter={e => e.currentTarget.style.animationPlayState = "paused"}
                onMouseLeave={e => e.currentTarget.style.animationPlayState = "running"}>
                Kostenlos registrieren
              </button>
            </div>
          </div>

          {/* RIGHT: Phone mockup */}
          <div style={{
            flex: "0 0 auto",
            opacity: loaded ? 1 : 0,
            animation: loaded ? "fadeSlide 0.8s ease 0.2s both" : "none",
            display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 0,
          }}>
            {/* Badge above phone — right aligned */}
            <div style={{
              display: "inline-flex", alignItems: "center", gap: 8,
              background: "rgba(16,185,129,0.15)", border: "1px solid rgba(16,185,129,0.3)",
              borderRadius: 100, padding: "7px 16px", marginBottom: 14,
              fontSize: 11, fontWeight: 700, color: "#10B981",
            }}>
              <span style={{ width: 6, height: 6, borderRadius: "50%", background: "#10B981", display: "inline-block", boxShadow: "0 0 8px #10B981" }} />
              Das neue Loyalitätsprogramm
            </div>
            {/* Simple phone frame with stamp card preview */}
            <div style={{
              width: 200, height: 360,
              background: "#111c26",
              borderRadius: 36,
              border: "6px solid rgba(255,255,255,0.1)",
              boxShadow: "0 32px 80px rgba(0,0,0,0.6), 0 0 0 1px rgba(255,255,255,0.05), inset 0 0 40px rgba(16,185,129,0.04)",
              overflow: "hidden",
              position: "relative",
              display: "flex", flexDirection: "column",
            }}>
              {/* Status bar */}
              <div style={{ height: 28, background: "#0d1520", display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 14px", flexShrink: 0 }}>
                <span style={{ fontSize: 9, color: "rgba(255,255,255,0.5)", fontWeight: 600 }}>9:41</span>
                <div style={{ width: 40, height: 10, background: "rgba(255,255,255,0.08)", borderRadius: 100 }} />
                <span style={{ fontSize: 9, color: "rgba(255,255,255,0.5)" }}>●●●</span>
              </div>
              {/* Content */}
              <div style={{ flex: 1, padding: "14px 12px", display: "flex", flexDirection: "column", gap: 10 }}>
                <div style={{ fontSize: 10, fontWeight: 700, color: "#10B981" }}>Meine Karten</div>
                {/* Stamp card 1 */}
                {[
                  { name: "Kings Barbershop", emoji: "✂️", stamps: 5, req: 8, color: "#10B981" },
                  { name: "Café Milano", emoji: "☕", stamps: 3, req: 6, color: "#F59E0B" },
                  { name: "Bella Nails", emoji: "💅", stamps: 7, req: 8, color: "#EC4899" },
                ].map((c, ci) => (
                  <div key={ci} style={{ background: "rgba(255,255,255,0.04)", border: `1px solid ${c.color}30`, borderRadius: 12, padding: "10px 10px" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 7 }}>
                      <span style={{ fontSize: 13 }}>{c.emoji}</span>
                      <span style={{ fontSize: 9, fontWeight: 700, color: "#fff", flex: 1 }}>{c.name}</span>
                      <span style={{ fontSize: 8, color: c.color, fontWeight: 700 }}>{c.stamps}/{c.req}</span>
                    </div>
                    <div style={{ display: "grid", gridTemplateColumns: `repeat(${c.req}, 1fr)`, gap: 2 }}>
                      {Array.from({ length: c.req }, (_, i) => (
                        <div key={i} style={{ height: 8, borderRadius: 2, background: i < c.stamps ? c.color : "rgba(255,255,255,0.07)" }} />
                      ))}
                    </div>
                  </div>
                ))}
                {/* Earnings badge */}
                <div style={{ marginTop: "auto", background: "linear-gradient(135deg, rgba(16,185,129,0.2), rgba(16,185,129,0.05))", border: "1px solid rgba(16,185,129,0.3)", borderRadius: 12, padding: "10px 10px", display: "flex", alignItems: "center", gap: 8 }}>
                  <span style={{ fontSize: 16 }}>💸</span>
                  <div>
                    <div style={{ fontSize: 11, fontWeight: 800, color: "#10B981" }}>42,50 € verdient</div>
                    <div style={{ fontSize: 8, color: "rgba(255,255,255,0.4)" }}>3 Empfehlungen</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div style={{ position: "absolute", bottom: 32, left: "50%", transform: "translateX(-50%)", zIndex: 3, display: "flex", flexDirection: "column", alignItems: "center", gap: 6, animation: "scrollHint 2s ease-in-out infinite" }}>
          <span style={{ fontSize: 11, color: "rgba(255,255,255,0.35)", letterSpacing: 1 }}>ENTDECKEN</span>
          <div style={{ width: 1, height: 32, background: "linear-gradient(to bottom, rgba(16,185,129,0.6), transparent)" }} />
        </div>
      </div>

      {/* ── BENEFITS SECTION ── */}
      <div style={{ padding: "48px 24px", background: "#0a1510" }}>
        <div style={{ maxWidth: 1000, margin: "0 auto" }}>
          <div style={{ textAlign: "center", marginBottom: 36 }}>
            <div style={{ fontSize: 11, fontWeight: 800, color: "#10B981", letterSpacing: 2.5, textTransform: "uppercase", marginBottom: 12 }}>Das macht Sensalie für dich</div>
            <div style={{ fontSize: 24, fontWeight: 900, color: "#fff", letterSpacing: -0.8, lineHeight: 1.2 }}>
              Mehr Wert aus jedem Besuch
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 16 }}>
            {[
              { emoji: "🎁", title: "Prämien sammeln", desc: "Mit jedem Einkauf näher zur nächsten Belohnung" },
              { emoji: "💸", title: "Geld verdienen", desc: "Empfehle Freunde und verdiene automatisch Provisionen" },
              { emoji: "📲", title: "Jederzeit dabei", desc: "Digitale Karten überall — ohne Papier, ohne Gedöns" },
              { emoji: "🤝", title: "Fair für alle", desc: "Deine Daten, deine Kontrolle — transparent und sicher" },
            ].map((b, i) => (
              <div key={i} style={{
                background: "rgba(16,185,129,0.08)", border: "1px solid rgba(16,185,129,0.2)", borderRadius: 20,
                padding: "24px 20px", textAlign: "center", opacity: loaded ? 1 : 0,
                animation: loaded ? `fadeSlide 0.6s ease ${0.1 + i * 0.1}s both` : "none",
              }}>
                <div style={{ fontSize: 40, marginBottom: 12 }}>{b.emoji}</div>
                <div style={{ fontSize: 15, fontWeight: 700, color: "#fff", marginBottom: 8 }}>{b.title}</div>
                <div style={{ fontSize: 12, color: "rgba(255,255,255,0.5)", lineHeight: 1.5 }}>{b.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── PARTNER CATEGORIES — auto-scrolling carousel ── */}
      <div style={{ padding: "48px 0", borderTop: "1px solid rgba(255,255,255,0.05)" }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,0.25)", textAlign: "center", letterSpacing: 2, marginBottom: 24 }}>PARTNER-KATEGORIEN</div>
        <div style={{ position: "relative", overflow: "hidden" }}>
          <div style={{
            display: "flex", gap: 16, padding: "0 20px",
            animation: "carouselSlide 20s linear infinite",
          }}>
            {[...PARTNERS, ...PARTNERS].map((p, i) => (
              <div key={i} style={{
                flexShrink: 0, width: 140, height: 160, borderRadius: 20, overflow: "hidden",
                position: "relative", border: "1px solid rgba(16,185,129,0.2)",
              }}>
                <img src={p.img} alt={p.name} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(6,12,18,0.88) 0%, rgba(6,12,18,0.1) 55%)" }} />
                <div style={{ position: "absolute", bottom: 12, left: 12, right: 12 }}>
                  <div style={{ fontSize: 20, marginBottom: 4 }}>{p.emoji}</div>
                  <div style={{ fontSize: 12, fontWeight: 700, color: "#fff", lineHeight: 1.2 }}>{p.name}</div>
                </div>
              </div>
            ))}
          </div>
          <style>{`
            @keyframes carouselSlide {
              0% { transform: translateX(0); }
              100% { transform: translateX(-${(140 + 16) * PARTNERS.length}px); }
            }
          `}</style>
        </div>
      </div>

      {/* ── HOW IT WORKS — Phone Demo ── */}
      <div style={{ padding: "56px 20px 20px", background: "linear-gradient(180deg, #0d1a10 0%, #112216 50%, #0d1a10 100%)" }}>
        <div style={{ textAlign: "center", marginBottom: 36 }}>
          <div style={{ fontSize: 11, fontWeight: 800, color: "#10B981", letterSpacing: 2.5, textTransform: "uppercase", marginBottom: 12 }}>So funktioniert's</div>
          <div style={{ fontSize: 26, fontWeight: 900, color: "#fff", letterSpacing: -0.8, lineHeight: 1.2 }}>
            Sieh's live in Aktion
          </div>
          <div style={{ fontSize: 13, color: "rgba(255,255,255,0.35)", marginTop: 10, lineHeight: 1.6 }}>
            Tippe auf einen Schritt oder schau einfach zu.
          </div>
        </div>
        <PhoneDemo />
      </div>

      {/* ── MAPS TEASER ── */}
      <div style={{ margin: "0 20px 0", padding: "48px 0 0" }}>
        <div style={{ textAlign: "center", marginBottom: 28 }}>
          <div style={{ fontSize: 11, fontWeight: 800, color: "#10B981", letterSpacing: 2.5, textTransform: "uppercase", marginBottom: 10 }}>Bald verfügbar</div>
          <div style={{ fontSize: 22, fontWeight: 900, color: "#fff", letterSpacing: -0.5, lineHeight: 1.3 }}>
            Entdecke Partner in deiner Nähe
          </div>
          <div style={{ fontSize: 13, color: "rgba(255,255,255,0.35)", marginTop: 8 }}>
            Lokale Geschäfte auf der Karte — einfach vorbeikommen, scannen, sammeln.
          </div>
        </div>
        {/* Realistic map */}
        <div style={{ borderRadius: 24, overflow: "hidden", position: "relative", height: 260, border: "1px solid rgba(16,185,129,0.2)", boxShadow: "0 8px 40px rgba(0,0,0,0.4)" }}>
          {/* OpenStreetMap embed — real streets, hue-shifted green */}
          <iframe
            src="https://www.openstreetmap.org/export/embed.html?bbox=13.37,52.50,13.42,52.53&layer=mapnik"
            style={{ width: "100%", height: "100%", border: "none", filter: "saturate(0.6) brightness(0.8) hue-rotate(140deg)", pointerEvents: "none" }}
            title="Karte"
          />
          {/* Subtle dark-green tint overlay */}
          <div style={{ position: "absolute", inset: 0, background: "rgba(6,18,12,0.38)", pointerEvents: "none" }} />
          {/* Animated pins on top */}
          {[
            { x: "28%", y: "38%", delay: "0s", label: "Barbershop" },
            { x: "58%", y: "55%", delay: "0.6s", label: "Café" },
            { x: "72%", y: "28%", delay: "1.2s", label: "Nagelstudio" },
            { x: "18%", y: "62%", delay: "0.3s", label: "Restaurant" },
            { x: "45%", y: "72%", delay: "0.9s", label: "Friseur" },
          ].map((pin, i) => (
            <div key={i} style={{ position: "absolute", left: pin.x, top: pin.y, transform: "translate(-50%,-50%)" }}>
              <div style={{ position: "absolute", width: 28, height: 28, borderRadius: "50%", border: "2px solid #10B981", left: -5, top: -5, animation: `mapPing 2s ease-out ${pin.delay} infinite`, opacity: 0.7 }} />
              <div style={{ width: 18, height: 18, borderRadius: "50%", background: "#10B981", border: "2px solid #fff", boxShadow: "0 0 12px rgba(16,185,129,0.8)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 8, fontWeight: 800, color: "#000", zIndex: 1, position: "relative" }}>✓</div>
              <div style={{ position: "absolute", top: 22, left: "50%", transform: "translateX(-50%)", background: "rgba(6,20,14,0.95)", border: "1px solid rgba(16,185,129,0.4)", borderRadius: 6, padding: "3px 7px", fontSize: 9, fontWeight: 700, color: "#10B981", whiteSpace: "nowrap" }}>{pin.label}</div>
            </div>
          ))}
          {/* Bottom fade + badge */}
          <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(6,12,18,0.65) 0%, transparent 45%)", pointerEvents: "none" }} />
          <div style={{ position: "absolute", bottom: 16, left: "50%", transform: "translateX(-50%)", background: "rgba(16,185,129,0.15)", border: "1px solid rgba(16,185,129,0.4)", borderRadius: 100, padding: "8px 18px", fontSize: 12, fontWeight: 700, color: "#10B981", whiteSpace: "nowrap", backdropFilter: "blur(6px)" }}>
            📍 Demnächst in deiner Stadt
          </div>
        </div>
      </div>

      {/* ── VISION SECTION ── */}
      <div style={{ margin: "40px 20px", borderRadius: 28, overflow: "hidden", position: "relative", minHeight: 280 }}>
        <img src="https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=800&q=80" alt="vision" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }} />
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(135deg, rgba(6,12,18,0.92) 0%, rgba(16,185,129,0.2) 100%)" }} />
        <div style={{ position: "relative", padding: "40px 28px" }}>
          <div style={{ fontSize: 11, fontWeight: 800, color: "#10B981", letterSpacing: 2, marginBottom: 14 }}>UNSERE VISION</div>
          <div style={{ fontSize: 22, fontWeight: 900, color: "#fff", lineHeight: 1.3, marginBottom: 16 }}>
            Jeder Einkauf soll sich lohnen. Nicht nur für das Geschäft — sondern für dich.
          </div>
          <div style={{ fontSize: 13, color: "rgba(255,255,255,0.5)", lineHeight: 1.7 }}>
            Sensalie verbindet lokale Unternehmen mit ihren treuesten Kunden — digital, fair und ohne Papierkram. Du wirst belohnt für das, was du eh schon tust.
          </div>
        </div>
      </div>

      {/* ── BOTTOM CTA ── */}
      <div style={{ padding: "48px 24px 80px", textAlign: "center", background: "linear-gradient(180deg, #060c12 0%, #0d1f17 50%, #0a1510 100%)" }}>
        <div style={{ fontSize: 30, fontWeight: 900, color: "#fff", letterSpacing: -0.8, marginBottom: 12 }}>
          Bereit für mehr<br />aus jedem Besuch?
        </div>
        <div style={{ fontSize: 14, color: "rgba(255,255,255,0.35)", marginBottom: 32, lineHeight: 1.7 }}>
          Kostenlos starten. Kein Abo. Keine versteckten Kosten.
        </div>
        <button onClick={() => setModal("register")} style={{ width: "100%", maxWidth: 320, padding: "17px 24px", background: "#10B981", color: "#fff", fontWeight: 800, fontSize: 16, borderRadius: 18, border: "none", cursor: "pointer", fontFamily: "inherit", display: "block", margin: "0 auto", animation: "ctaPulse 2.4s ease-in-out infinite" }}
          onMouseEnter={e => e.currentTarget.style.animationPlayState = "paused"}
          onMouseLeave={e => e.currentTarget.style.animationPlayState = "running"}>
          Jetzt kostenlos registrieren
        </button>
      </div>

      {modal && <RegisterModal mode={modal} onClose={() => setModal(null)} />}
    </div>
  );
}