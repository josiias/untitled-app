import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";

const MOCK_BUSINESS = {
  id: "demo-kings-barbershop-001",
  name: "Kings Barbershop",
  stamps_required: 8,
  min_purchase_amount: 20,
  reward_description: "10€ Gutschein",
  emoji: "✂️",
  category: "barbershop",
};

const CATEGORY_IMAGES = {
  barbershop: "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?w=800&q=80",
  cafe: "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=800&q=80",
  restaurant: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80",
  massage: "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=800&q=80",
  nails: "https://images.unsplash.com/photo-1604654894610-df63bc536371?w=800&q=80",
  fitness: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=800&q=80",
  beauty: "https://images.unsplash.com/photo-1560066984-138dadb4c035?w=800&q=80",
};

const ALL_IMAGES = Object.values(CATEGORY_IMAGES);

export default function ScanLanding() {
  const { businessId } = useParams();
  const [step, setStep] = useState("stamp-anim");
  const [animDone, setAnimDone] = useState(false);
  const [phone, setPhone] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [imgIndex, setImgIndex] = useState(0);
  const [realBusiness, setRealBusiness] = useState(null);
  const [customer, setCustomer] = useState(null);
  const [totalStamps, setTotalStamps] = useState(1);
  const [particles, setParticles] = useState([]);

  // Referral code aus URL-Parameter
  const referralCode = new URLSearchParams(window.location.search).get("ref") || null;

  useEffect(() => {
    if (!businessId) return;
    base44.entities.Business.filter({ id: businessId }, "-created_date", 1)
      .then(results => { if (results.length > 0) setRealBusiness(results[0]); })
      .catch(() => {});
  }, [businessId]);

  const business = realBusiness ? {
    id: realBusiness.id, name: realBusiness.name, stamps_required: realBusiness.stamps_required,
    min_purchase_amount: realBusiness.min_purchase_amount, reward_description: realBusiness.reward_description,
    emoji: realBusiness.emoji || "🏪", category: realBusiness.category || "barbershop",
  } : MOCK_BUSINESS;

  useEffect(() => {
    const colors = ["#FFD700", "#FF6B6B", "#4ECDC4", "#45B7D1", "#96CEB4", "#FFEAA7", "#DDA0DD"];
    setParticles(Array.from({ length: 30 }, (_, i) => ({ id: i, x: Math.random() * 100, delay: Math.random() * 1.5, duration: 2 + Math.random() * 2, color: colors[Math.floor(Math.random() * colors.length)], size: 6 + Math.random() * 8 })));
  }, []);

  useEffect(() => {
    if (step === "stamp-anim") { const t = setTimeout(() => setAnimDone(true), 1800); return () => clearTimeout(t); }
  }, [step]);

  useEffect(() => {
    const t = setInterval(() => setImgIndex(i => (i + 1) % ALL_IMAGES.length), 3000);
    return () => clearInterval(t);
  }, []);

  const handleRegister = async (e) => {
    e.preventDefault();
    setSubmitted(true);
    try {
      const bizId = business.id;

      // Resolve referral code to a customer ID
      let referredById = null;
      if (referralCode) {
        const referrers = await base44.entities.Customer.filter({ referral_code: referralCode }, "-created_date", 1);
        if (referrers.length > 0) referredById = referrers[0].id;
      }

      const existing = await base44.entities.Customer.filter({ phone, business_id: bizId }, "-created_date", 1);
      let cust;
      if (existing.length > 0) {
        cust = existing[0];
        const today = new Date().toISOString().split("T")[0];
        const recentTx = await base44.entities.StampTransaction.filter({ customer_id: cust.id, business_id: bizId }, "-created_date", 1);
        const alreadyToday = recentTx.length > 0 && recentTx[0].created_date?.startsWith(today);
        if (!alreadyToday) {
          await base44.entities.StampTransaction.create({ customer_id: cust.id, business_id: bizId, employee_confirmed: true, amount: business.min_purchase_amount });
          cust = await base44.entities.Customer.update(cust.id, { total_stamps: cust.total_stamps + 1, total_visits: cust.total_visits + 1 });
        }
      } else {
        // New customer — set referred_by if referral code was used
        const newCustData = {
          phone,
          business_id: bizId,
          name: "",
          referral_code: `REF-${Math.random().toString(36).substring(2, 8).toUpperCase()}`,
          total_stamps: 1,
          total_visits: 1,
          provision_earned: 0,
          provision_paid: 0,
        };
        if (referredById) newCustData.referred_by = referredById;
        cust = await base44.entities.Customer.create(newCustData);
        await base44.entities.StampTransaction.create({ customer_id: cust.id, business_id: bizId, employee_confirmed: true, amount: business.min_purchase_amount });
      }
      setCustomer(cust);
      setTotalStamps(cust.total_stamps);
    } catch (err) { console.error(err); }
    setStep("registered");
  };

  const S = { background: "#0a0f16", minHeight: "100vh", color: "#fff", fontFamily: "'Inter', sans-serif", position: "relative", overflow: "hidden", maxWidth: 600, margin: "0 auto" };

  return (
    <div style={S}>
      {/* Background orbs */}
      <div style={{ position: "fixed", top: -80, right: -80, width: 250, height: 250, background: "radial-gradient(circle, rgba(16,185,129,0.15) 0%, transparent 70%)", pointerEvents: "none" }} />

      {/* STEP 1: Stamp Animation */}
      {step === "stamp-anim" && (
        <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column" }}>
          {/* Slideshow */}
          <div style={{ position: "relative", height: 240, overflow: "hidden" }}>
            {ALL_IMAGES.map((src, i) => (
              <img key={i} src={src} alt="" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", opacity: i === imgIndex ? 1 : 0, transition: "opacity 0.8s ease" }} />
            ))}
            <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to bottom, rgba(0,0,0,0.3), rgba(10,15,22,1))" }} />
            <div style={{ position: "absolute", bottom: 20, left: 20 }}>
              <div style={{ fontSize: 20 }}>{business.emoji}</div>
              <div style={{ fontSize: 16, fontWeight: 800 }}>{business.name}</div>
            </div>
          </div>

          <div style={{ flex: 1, padding: "24px 20px", display: "flex", flexDirection: "column", alignItems: "center" }}>
            <div style={{ width: 72, height: 72, borderRadius: 20, background: "rgba(16,185,129,0.15)", border: "2px solid rgba(16,185,129,0.4)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 32, marginBottom: 20 }}>✓</div>
            <h1 style={{ fontSize: 22, fontWeight: 800, textAlign: "center", marginBottom: 8 }}>Glückwunsch! 🎉</h1>
            <p style={{ fontSize: 14, color: "rgba(255,255,255,0.5)", textAlign: "center", marginBottom: 28 }}>Du hast einen Stempel bei {business.name} erhalten!</p>

            <div style={{ width: "100%", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 16, padding: "16px", marginBottom: 28 }}>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: "rgba(255,255,255,0.5)", marginBottom: 10 }}>
                <span>Deine Stempelkarte</span>
                <span style={{ color: "#10B981", fontWeight: 700 }}>{totalStamps}/{business.stamps_required}</span>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: `repeat(${Math.min(business.stamps_required, 8)}, 1fr)`, gap: 6 }}>
                {Array.from({ length: business.stamps_required }).map((_, i) => (
                  <div key={i} style={{ aspectRatio: "1", borderRadius: 8, background: i < totalStamps ? "#10B981" : "rgba(255,255,255,0.06)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, color: "#fff", fontWeight: 700 }}>
                    {i < totalStamps ? "✓" : ""}
                  </div>
                ))}
              </div>
              <div style={{ marginTop: 12, fontSize: 12, color: "rgba(255,255,255,0.5)", textAlign: "center" }}>🎁 {business.reward_description}</div>
            </div>

            {animDone && (
              <div style={{ width: "100%", display: "flex", flexDirection: "column", gap: 10 }}>
                <button onClick={() => setStep("register-prompt")} style={{ width: "100%", padding: "14px", background: "#10B981", color: "#fff", fontWeight: 800, fontSize: 15, borderRadius: 14, border: "none", cursor: "pointer", fontFamily: "inherit" }}>✅ Stempel sichern</button>
                <button onClick={() => setStep("register-prompt")} style={{ width: "100%", padding: "10px", background: "transparent", color: "rgba(255,255,255,0.3)", fontSize: 11, borderRadius: 12, border: "1px solid rgba(255,255,255,0.08)", cursor: "pointer", fontFamily: "inherit" }}>⚠️ Ohne Registrierung (Stempel geht verloren)</button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* STEP 2: Register Prompt */}
      {step === "register-prompt" && (
        <div style={{ minHeight: "100vh", padding: "40px 24px", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
          <div style={{ fontSize: 40, marginBottom: 16 }}>📲</div>
          <h2 style={{ fontSize: 22, fontWeight: 800, textAlign: "center", marginBottom: 8 }}>Stempel sichern</h2>
          <p style={{ fontSize: 14, color: "rgba(255,255,255,0.5)", textAlign: "center", marginBottom: 28 }}>Nur deine Handynummer — fertig.</p>

          {[
            { icon: "🎯", text: "Stempel gehen nie verloren" },
            { icon: "🎁", text: `Prämie nach ${business.stamps_required} Stempeln: ${business.reward_description}` },
            { icon: "💸", text: "Empfehle weiter & verdiene bis zu 100€" },
          ].map((b, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10, alignSelf: "flex-start", width: "100%" }}>
              <span style={{ fontSize: 18 }}>{b.icon}</span>
              <span style={{ fontSize: 13, color: "rgba(255,255,255,0.6)" }}>{b.text}</span>
            </div>
          ))}

          <form onSubmit={handleRegister} style={{ width: "100%", marginTop: 20 }}>
            <input type="tel" placeholder="0151 12345678" value={phone} onChange={e => setPhone(e.target.value)} required autoFocus style={{ width: "100%", padding: "14px 16px", background: "rgba(255,255,255,0.06)", border: "1.5px solid rgba(255,255,255,0.12)", borderRadius: 14, fontSize: 16, color: "#fff", fontFamily: "inherit", outline: "none", textAlign: "center", letterSpacing: 1, marginBottom: 12, boxSizing: "border-box" }} />
            <button type="submit" disabled={submitted} style={{ width: "100%", padding: "14px", background: submitted ? "rgba(16,185,129,0.5)" : "#10B981", color: "#fff", fontWeight: 800, fontSize: 15, borderRadius: 14, border: "none", cursor: submitted ? "not-allowed" : "pointer", fontFamily: "inherit" }}>
              {submitted ? "Wird gespeichert…" : "Stempel jetzt sichern →"}
            </button>
          </form>
          <button onClick={() => window.close()} style={{ marginTop: 12, padding: "10px", background: "transparent", color: "rgba(255,255,255,0.2)", fontSize: 12, border: "none", cursor: "pointer", fontFamily: "inherit" }}>Nein danke</button>
        </div>
      )}

      {/* STEP 3: Registered */}
      {step === "registered" && (
        <div style={{ minHeight: "100vh", padding: "40px 20px", display: "flex", flexDirection: "column", alignItems: "center" }}>
          <div style={{ width: 72, height: 72, borderRadius: 20, background: "rgba(16,185,129,0.15)", border: "2px solid rgba(16,185,129,0.4)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 36, marginBottom: 20 }}>🎉</div>
          <h2 style={{ fontSize: 22, fontWeight: 800, textAlign: "center", marginBottom: 8 }}>Willkommen bei Sensalie!</h2>
          <p style={{ fontSize: 14, color: "rgba(255,255,255,0.5)", textAlign: "center", marginBottom: 28 }}>Stempel bei {business.name} gesichert 🔒</p>

          <div style={{ width: "100%", background: "rgba(16,185,129,0.08)", border: "1px solid rgba(16,185,129,0.2)", borderRadius: 16, padding: 16, marginBottom: 20 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
              <span style={{ fontSize: 18 }}>💸</span>
              <span style={{ fontSize: 13, color: "rgba(255,255,255,0.6)", lineHeight: 1.5 }}>Bei Sensalie kannst du dein Lieblingsunternehmen empfehlen und bis zu <strong style={{ color: "#10B981" }}>100€</strong> pro Empfehlung verdienen.</span>
            </div>
          </div>

          <button onClick={() => window.location.href = "/"} style={{ width: "100%", padding: "12px", background: "rgba(255,255,255,0.06)", color: "rgba(255,255,255,0.5)", fontWeight: 600, fontSize: 13, borderRadius: 12, border: "1px solid rgba(255,255,255,0.1)", cursor: "pointer", fontFamily: "inherit" }}>
            Zur Startseite
          </button>

          <div style={{ marginTop: 32, textAlign: "center" }}>
            <div style={{ fontSize: 16, fontWeight: 800, color: "#fff" }}>Sensalie<span style={{ color: "#10B981" }}>.</span></div>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,0.3)", marginTop: 4 }}>Deine digitale Kundenkarte</div>
          </div>
        </div>
      )}

      <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}