import { useState, useCallback } from "react";
import { Link, useNavigate } from "react-router-dom";

const ADMIN_PASSWORD = "sensalie2026admin";


export default function RoleSelect() {
  const [clicks, setClicks] = useState(0);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [password, setPassword] = useState("");
  const [error, setError] = useState(false);
  const [hovered, setHovered] = useState(null);
  const navigate = useNavigate();

  const handleLogoClick = useCallback(() => {
    setClicks(prev => {
      const next = prev + 1;
      if (next >= 5) { setShowPasswordModal(true); return 0; }
      return next;
    });
  }, []);

  const handlePasswordSubmit = (e) => {
    e.preventDefault();
    if (password === ADMIN_PASSWORD) {
      setShowPasswordModal(false);
      setPassword("");
      navigate("/admin-dashboard");
    } else {
      setError(true);
      setPassword("");
      setTimeout(() => setError(false), 1500);
    }
  };

  return (
    <div style={{
      minHeight: "100vh",
      background: "#07090d",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      padding: "40px 20px",
      fontFamily: "'Inter', sans-serif",
      color: "#fff",
      position: "relative",
      overflow: "hidden",
    }}>

      {/* ── ANIMATED BACKGROUND GLOWS ── */}
      <style>{`
        @keyframes glow-pulse-1 {
          0%, 100% { transform: scale(1) translate(0, 0); opacity: 0.55; }
          50% { transform: scale(1.12) translate(20px, -15px); opacity: 0.75; }
        }
        @keyframes glow-pulse-2 {
          0%, 100% { transform: scale(1) translate(0, 0); opacity: 0.4; }
          50% { transform: scale(1.08) translate(-15px, 20px); opacity: 0.6; }
        }
        @keyframes glow-pulse-3 {
          0%, 100% { transform: scale(1); opacity: 0.2; }
          50% { transform: scale(1.15); opacity: 0.35; }
        }
        @keyframes gradient-shift {
          0%, 100% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
        }
      `}</style>

      {/* Animated gradient background */}
      <div style={{
        position: "fixed", inset: 0, zIndex: 0, pointerEvents: "none",
        background: "linear-gradient(135deg, #07090d 0%, #0d1a12 30%, #07090d 60%, #0a1510 100%)",
        backgroundSize: "400% 400%",
        animation: "gradient-shift 14s ease-in-out infinite",
      }} />

      {/* Top-left green glow orb */}
      <div style={{
        position: "fixed", top: "-15%", left: "-10%",
        width: "55vw", height: "55vw", maxWidth: 480, maxHeight: 480,
        background: "radial-gradient(circle, rgba(16,185,129,0.22) 0%, transparent 70%)",
        animation: "glow-pulse-1 9s ease-in-out infinite",
        pointerEvents: "none", zIndex: 0,
      }} />

      {/* Bottom-right glow orb */}
      <div style={{
        position: "fixed", bottom: "-15%", right: "-10%",
        width: "50vw", height: "50vw", maxWidth: 440, maxHeight: 440,
        background: "radial-gradient(circle, rgba(16,185,129,0.12) 0%, transparent 70%)",
        animation: "glow-pulse-2 12s ease-in-out infinite",
        pointerEvents: "none", zIndex: 0,
      }} />

      {/* Center soft glow */}
      <div style={{
        position: "fixed", top: "45%", left: "50%", transform: "translate(-50%, -50%)",
        width: "80vw", height: "40vw", maxWidth: 560, maxHeight: 220,
        background: "radial-gradient(ellipse, rgba(16,185,129,0.06) 0%, transparent 70%)",
        animation: "glow-pulse-3 7s ease-in-out infinite",
        pointerEvents: "none", zIndex: 0,
      }} />

      {/* ── CONTENT ── */}
      <div style={{ position: "relative", zIndex: 1, width: "100%", maxWidth: 400, display: "flex", flexDirection: "column", alignItems: "center" }}>

        {/* Wordmark */}
        <div onClick={handleLogoClick} style={{ cursor: "default", userSelect: "none", marginBottom: 8, textAlign: "center" }}>
          <div style={{ fontSize: 36, fontWeight: 800, letterSpacing: -1, color: "#fff", lineHeight: 1 }}>
            Sensalie<span style={{ color: "#10B981" }}>.</span>
          </div>
        </div>

        {/* Tagline */}
        <div style={{ textAlign: "center", marginBottom: 32 }}>
          <div style={{ fontSize: 13, color: "rgba(255,255,255,0.4)", lineHeight: 1.7, letterSpacing: 0.2 }}>
            Wir verbinden Kunden &amp; Unternehmer —<br />
            <span style={{ color: "rgba(16,185,129,0.9)", fontWeight: 600 }}>für echte Loyalität, die sich lohnt.</span>
          </div>
        </div>

        {/* Cards */}
        <div style={{ display: "flex", flexDirection: "column", gap: 12, width: "100%" }}>

          {/* KUNDE */}
          <Link to="/customer" style={{ textDecoration: "none" }}
            onMouseEnter={() => setHovered("customer")}
            onMouseLeave={() => setHovered(null)}>
            <div style={{
              background: hovered === "customer" ? "rgba(16,185,129,0.14)" : "rgba(16,185,129,0.07)",
              border: `1.5px solid ${hovered === "customer" ? "rgba(16,185,129,0.5)" : "rgba(16,185,129,0.22)"}`,
              borderRadius: 20,
              padding: "20px 20px",
              cursor: "pointer",
              backdropFilter: "blur(16px)",
              transition: "background 0.25s, border-color 0.25s, transform 0.2s, box-shadow 0.25s",
              transform: hovered === "customer" ? "translateY(-3px)" : "translateY(0)",
              boxShadow: hovered === "customer" ? "0 12px 40px rgba(16,185,129,0.18)" : "none",
              display: "flex", alignItems: "center", gap: 16,
            }}>
              <div style={{
                width: 48, height: 48, borderRadius: 14, flexShrink: 0,
                background: "rgba(16,185,129,0.12)",
                display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22,
              }}>🛍️</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 16, fontWeight: 800, color: "#fff", marginBottom: 3 }}>Ich bin Kunde</div>
                <div style={{ fontSize: 12, color: "rgba(255,255,255,0.45)", lineHeight: 1.5 }}>
                  Stempel sammeln, Prämien einlösen &amp; verdienen.
                </div>
                <div style={{ display: "flex", gap: 5, marginTop: 8, flexWrap: "wrap" }}>
                  {["🎁 Prämien", "💸 Provision", "⭐ Treue"].map(b => (
                    <span key={b} style={{
                      fontSize: 10, fontWeight: 600, color: "#10B981",
                      background: "rgba(16,185,129,0.1)", border: "1px solid rgba(16,185,129,0.2)",
                      borderRadius: 100, padding: "2px 8px",
                    }}>{b}</span>
                  ))}
                </div>
              </div>
              <div style={{
                color: "#10B981", fontSize: 18,
                opacity: hovered === "customer" ? 1 : 0.4,
                transition: "opacity 0.2s, transform 0.2s",
                transform: hovered === "customer" ? "translateX(4px)" : "translateX(0)"
              }}>→</div>
            </div>
          </Link>

          {/* UNTERNEHMER */}
          <Link to="/for-business" style={{ textDecoration: "none" }}
            onMouseEnter={() => setHovered("business")}
            onMouseLeave={() => setHovered(null)}>
            <div style={{
              background: hovered === "business" ? "rgba(255,255,255,0.09)" : "rgba(255,255,255,0.04)",
              border: `1.5px solid ${hovered === "business" ? "rgba(255,255,255,0.22)" : "rgba(255,255,255,0.09)"}`,
              borderRadius: 20,
              padding: "20px 20px",
              cursor: "pointer",
              backdropFilter: "blur(16px)",
              transition: "background 0.25s, border-color 0.25s, transform 0.2s, box-shadow 0.25s",
              transform: hovered === "business" ? "translateY(-3px)" : "translateY(0)",
              boxShadow: hovered === "business" ? "0 12px 40px rgba(255,255,255,0.06)" : "none",
              display: "flex", alignItems: "center", gap: 16,
            }}>
              <div style={{
                width: 48, height: 48, borderRadius: 14, flexShrink: 0,
                background: "rgba(255,255,255,0.06)",
                display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22,
              }}>🏪</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 16, fontWeight: 800, color: "#fff", marginBottom: 3 }}>Ich bin Unternehmer</div>
                <div style={{ fontSize: 12, color: "rgba(255,255,255,0.45)", lineHeight: 1.5 }}>
                  Kundenbindung stärken &amp; Neukunden gewinnen.
                </div>
                <div style={{ display: "flex", gap: 5, marginTop: 8, flexWrap: "wrap" }}>
                  {["📈 Umsatz", "🔄 Neukunden", "❤️ Bindung"].map(b => (
                    <span key={b} style={{
                      fontSize: 10, fontWeight: 600, color: "rgba(255,255,255,0.55)",
                      background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)",
                      borderRadius: 100, padding: "2px 8px",
                    }}>{b}</span>
                  ))}
                </div>
              </div>
              <div style={{
                color: "rgba(255,255,255,0.4)", fontSize: 18,
                opacity: hovered === "business" ? 1 : 0.4,
                transition: "opacity 0.2s, transform 0.2s",
                transform: hovered === "business" ? "translateX(4px)" : "translateX(0)"
              }}>→</div>
            </div>
          </Link>
        </div>

        {/* Footer */}
        <div style={{ marginTop: 36, fontSize: 11, color: "rgba(255,255,255,0.15)", textAlign: "center" }}>
          © 2026 Sensalie · Einfach. Digital. Loyal.
        </div>
      </div>

      {/* Password Modal */}
      {showPasswordModal && (
        <div
          onClick={() => { setShowPasswordModal(false); setPassword(""); setError(false); }}
          style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.75)", backdropFilter: "blur(16px)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 100, padding: 24 }}
        >
          <div
            onClick={e => e.stopPropagation()}
            style={{ background: "#111e28", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 20, padding: "32px 24px", width: "100%", maxWidth: 320, textAlign: "center" }}
          >
            <div style={{ fontSize: 28, marginBottom: 12 }}>🔐</div>
            <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 6 }}>Admin-Zugang</div>
            <div style={{ fontSize: 12, color: "rgba(255,255,255,0.4)", marginBottom: 24 }}>Passwort eingeben</div>
            <form onSubmit={handlePasswordSubmit}>
              <input
                autoFocus type="password" value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                style={{
                  width: "100%", padding: "12px 16px",
                  background: error ? "rgba(239,68,68,0.1)" : "rgba(255,255,255,0.06)",
                  border: `1.5px solid ${error ? "rgba(239,68,68,0.5)" : "rgba(255,255,255,0.12)"}`,
                  borderRadius: 12, fontSize: 16, color: "#fff", fontFamily: "inherit",
                  outline: "none", textAlign: "center", letterSpacing: 4,
                  marginBottom: 14, boxSizing: "border-box", transition: "border 0.2s",
                }}
              />
              {error && <div style={{ fontSize: 12, color: "#ef4444", marginBottom: 12 }}>Falsches Passwort</div>}
              <button type="submit" style={{ width: "100%", padding: "12px", background: "#10B981", color: "#fff", fontWeight: 700, fontSize: 14, borderRadius: 12, border: "none", cursor: "pointer", fontFamily: "inherit" }}>
                Einloggen
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}