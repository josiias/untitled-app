import React, { useEffect, useState } from "react";
import Navbar from "../components/landing/Navbar";
import HeroSection from "../components/landing/HeroSection";
import BenefitsReveal from "../components/landing/BenefitsReveal";
import StatsStrip from "../components/landing/StatsStrip";
import DashboardSection from "../components/landing/DashboardSection.jsx";
import VideoSection from "../components/landing/VideoSection";
import HowItWorks from "../components/landing/HowItWorks";
import PricingSection from "../components/landing/PricingSection.jsx";
import CtaSection from "../components/landing/CtaSection";
import Footer from "../components/landing/Footer";

export default function Landing() {
  const [scrollRatio, setScrollRatio] = useState(0);

  useEffect(() => {
    const onScroll = () => {
      const max = document.documentElement.scrollHeight - window.innerHeight;
      setScrollRatio(max > 0 ? Math.min(1, window.scrollY / max) : 0);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Dynamic background: shifts through deep dark → teal-dark → deep forest as user scrolls
  // Phase 1 (0–40%): near black #080e0c
  // Phase 2 (40–70%): deep teal-green
  // Phase 3 (70–100%): rich dark forest
  const p1 = Math.min(1, scrollRatio / 0.4);
  const p2 = Math.min(1, Math.max(0, (scrollRatio - 0.4) / 0.3));
  const p3 = Math.min(1, Math.max(0, (scrollRatio - 0.7) / 0.3));

  const bg1r = Math.round(8  + p1 * 4  - p3 * 2);
  const bg1g = Math.round(14 + p1 * 28 + p2 * 20 - p3 * 4);
  const bg1b = Math.round(12 + p1 * 20 + p2 * 10 - p3 * 4);
  const bg2r = Math.round(4  + p1 * 2);
  const bg2g = Math.round(8  + p1 * 20 + p2 * 16);
  const bg2b = Math.round(6  + p1 * 14 + p2 * 8);

  return (
    <div style={{
      background: `linear-gradient(180deg, rgb(${bg1r},${bg1g},${bg1b}) 0%, rgb(${bg2r},${bg2g},${bg2b}) 100%)`,
      minHeight: "100vh",
      transition: "background 0.3s ease",
      overflowX: "hidden",
      width: "100%",
    }}>
      <Navbar />
      <HeroSection />
      <BenefitsReveal />
      <DashboardSection />
      <StatsStrip />
      <VideoSection />
      <HowItWorks />
      <PricingSection />
      <CtaSection />
      <Footer />
    </div>
  );
}