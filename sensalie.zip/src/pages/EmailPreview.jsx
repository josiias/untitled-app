import React from "react";

export default function EmailPreview() {
  const mockBusiness = {
    name: "Kings Barbershop",
    min_purchase_amount: 20,
    stamps_required: 8,
    recommended_provision: 10
  };

  const emailHTML = `
<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue', sans-serif; line-height: 1.6; color: #374151; background: #f3f4f6; }
    .container { max-width: 600px; margin: 0 auto; background: #ffffff; }
    .header { background: linear-gradient(135deg, rgba(16,185,129,0.08), rgba(16,185,129,0.02)); padding: 40px 24px; text-align: center; border-bottom: 1px solid rgba(16,185,129,0.1); }
    .logo { font-size: 28px; font-weight: 800; color: #000; margin-bottom: 8px; letter-spacing: -0.5px; }
    .logo span { color: #10B981; }
    .headline { font-size: 24px; font-weight: 700; color: #1f2937; margin: 32px 24px 12px; text-align: center; }
    .subheadline { font-size: 16px; color: #6b7280; text-align: center; margin: 0 24px 32px; }
    .confirmation-block { background: linear-gradient(135deg, rgba(16,185,129,0.06), rgba(16,185,129,0.02)); border: 2px solid #10B981; border-radius: 12px; margin: 24px; padding: 24px; }
    .confirmation-item { display: flex; justify-content: space-between; align-items: center; padding: 12px 0; border-bottom: 1px solid rgba(16,185,129,0.1); }
    .confirmation-item:last-child { border-bottom: none; }
    .confirmation-label { color: #6b7280; font-size: 14px; font-weight: 500; }
    .confirmation-value { color: #10B981; font-size: 16px; font-weight: 700; }
    .explanation { background: #f3f4f6; border-radius: 8px; padding: 20px; margin: 24px; color: #374151; font-size: 14px; line-height: 1.6; }
    .explanation strong { color: #1f2937; }
    .cta-section { text-align: center; margin: 32px 24px; }
    .cta-button { background: #10B981; color: white; padding: 14px 32px; border-radius: 8px; text-decoration: none; font-weight: 700; font-size: 14px; display: inline-block; transition: background 0.2s; }
    .cta-button:hover { background: #059669; }
    .next-steps { margin: 24px; }
    .next-steps h3 { color: #1f2937; font-size: 16px; font-weight: 700; margin-bottom: 16px; }
    .step { display: flex; gap: 12px; margin-bottom: 16px; }
    .step-number { background: #10B981; color: white; width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0; font-weight: 700; font-size: 12px; }
    .step-text { color: #374151; font-size: 14px; }
    .footer { background: #f9fafb; border-top: 1px solid #e5e7eb; padding: 24px; text-align: center; color: #6b7280; font-size: 12px; }
    .footer a { color: #10B981; text-decoration: none; }
    @media (max-width: 600px) {
      .headline { font-size: 20px; margin: 24px 16px 8px; }
      .subheadline { margin: 0 16px 24px; font-size: 14px; }
      .confirmation-block { margin: 16px; padding: 16px; }
      .header { padding: 32px 16px; }
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="logo">Sensalie<span>.</span></div>
    </div>

    <div class="headline">🎉 Dein Unternehmen ist jetzt live auf Sensalie</div>
    <div class="subheadline">Du bist bereit, Kundenbindung und Empfehlungen automatisiert zu nutzen</div>

    <div class="confirmation-block">
      <div class="confirmation-item" style="border-bottom: none;">
        <span class="confirmation-value" style="width: 100%; text-align: center; font-size: 18px;">${mockBusiness.name}</span>
      </div>
    </div>

    <div class="explanation">
      <strong>So funktioniert es:</strong><br><br>
      Ab jetzt kann jeder Kunde durch einen einfachen <strong>QR-Scan an deinem System teilnehmen</strong>, Stempel sammeln und automatisch Empfehlungen generieren. Deine Kunden werden zu deinen besten Vertriebsmitarbeitern.
    </div>

    <div class="cta-section">
      <a href="#" class="cta-button">Zur QR-Code Seite</a>
    </div>

    <div class="next-steps">
      <h3>Deine nächsten Schritte:</h3>
      <div class="step">
        <div class="step-number">1</div>
        <div class="step-text"><strong>QR-Code herunterladen</strong> und überall im Geschäft platzieren (Kasse, Eingang, Tisch)</div>
      </div>
      <div class="step">
        <div class="step-number">2</div>
        <div class="step-text"><strong>Mitarbeiter instruieren</strong> — beim Einkauf QR-Scan anbieten</div>
      </div>
      <div class="step">
        <div class="step-number">3</div>
        <div class="step-text"><strong>Provisionen optimieren</strong> — in deinem Dashboard anpassen</div>
      </div>
      <div class="step">
        <div class="step-number">4</div>
        <div class="step-text"><strong>Erste Kunden aktivieren</strong> — ab sofort wird jeder Einkauf zu einer Empfehlung</div>
      </div>
    </div>

    <div class="footer">
      <p>Fragen? <a href="mailto:support@sensalie.app">Schreib uns eine E-Mail</a> oder besuche unsere <a href="#">FAQ</a>.</p>
      <p style="margin-top: 12px;">© 2026 Sensalie. Alle Rechte vorbehalten.</p>
    </div>
  </div>
</body>
</html>
  `;

  return (
    <div style={{ minHeight: "100vh", background: "#f3f4f6", padding: "20px" }}>
      <div style={{ maxWidth: "800px", margin: "0 auto" }}>
        <div style={{ background: "#fff", padding: "20px", borderRadius: "8px", marginBottom: "20px" }}>
          <h1 style={{ fontSize: "24px", fontWeight: "700", color: "#1f2937", marginBottom: "8px" }}>E-Mail Vorschau</h1>
          <p style={{ color: "#6b7280", fontSize: "14px" }}>So sieht die Bestätigungsmail aus (mit Beispiel-Daten)</p>
        </div>
        <div style={{ background: "#fff", borderRadius: "8px", overflow: "hidden", boxShadow: "0 2px 8px rgba(0,0,0,0.1)" }}>
          <iframe
            srcDoc={emailHTML}
            style={{ width: "100%", border: "none", minHeight: "1200px", display: "block" }}
            title="Email Preview"
          />
        </div>
        <div style={{ background: "#fff", padding: "20px", borderRadius: "8px", marginTop: "20px", color: "#6b7280", fontSize: "13px" }}>
          <p><strong>Hinweis:</strong> Diese E-Mail wird automatisch versendet, sobald ein Unternehmer sich erfolgreich auf der Waitlist registriert. Die Daten werden dynamisch aus der Business-Entity befüllt.</p>
        </div>
      </div>
    </div>
  );
}