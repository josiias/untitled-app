import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { WaitlistEntry } from "@/api/entities";

const branches = ["Barbershop", "Friseur", "Nagelstudio", "Café", "Restaurant", "Andere"];

const inputStyle = {
  width: "100%",
  background: "rgba(255,255,255,0.07)",
  border: "1px solid rgba(255,255,255,0.15)",
  borderRadius: 12,
  padding: "14px 16px",
  color: "#fff",
  fontSize: 15,
  outline: "none",
  boxSizing: "border-box",
  transition: "border-color 0.2s",
  fontFamily: "inherit",
};

const labelStyle = {
  color: "rgba(255,255,255,0.6)",
  fontSize: 13,
  fontWeight: 500,
  display: "block",
  marginBottom: 6,
};

const steps = [
  { title: "Dein Unternehmen", subtitle: "Erzähl uns über dein Business" },
  { title: "Deine Kontaktdaten", subtitle: "Wie können wir dich erreichen?" },
  { title: "Fast fertig!", subtitle: "Noch ein optionaler Schritt" },
];

export default function Waitlist() {
  const [step, setStep] = useState(0);
  const [form, setForm] = useState({
    businessName: "",
    branch: "",
    name: "",
    email: "",
    phone: "",
    googleMaps: "",
  });
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleNext = (e) => {
    e.preventDefault();
    setStep((s) => s + 1);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      await WaitlistEntry.create({
        business_name: form.businessName,
        contact_name: form.name,
        email: form.email,
        phone: form.phone,
        industry: form.branch,
        google_maps_link: form.googleMaps,
        status: "Neu",
      });
      
      // Sende Bestätigungs-E-Mail via Backend-Funktion
      await base44.functions.invoke('sendWaitlistConfirmationEmail', {
        email: form.email,
        businessName: form.businessName,
        contactName: form.name
      });
      
      setSubmitted(true);
    } catch (err) {
      setError("Fehler beim Speichern. Bitte versuche es später erneut.");
    } finally {
      setLoading(false);
    }
  };

  const onFocus = (e) => { e.target.style.borderColor = "#00b894"; };
  const onBlur = (e) => { e.target.style.borderColor = "rgba(255,255,255,0.15)"; };

  if (submitted) {
    return (
      <div style={{ minHeight: "100vh", background: "#080e0c", display: "flex", alignItems: "center", justifyContent: "center", padding: "40px 20px" }}>
        <div style={{ textAlign: "center", maxWidth: 420 }}>
          <div style={{ fontSize: 52, marginBottom: 20 }}>🎉</div>
          <h2 style={{ fontFamily: "'Bricolage Grotesque', sans-serif", fontSize: "clamp(24px, 4vw, 36px)", fontWeight: 800, color: "#fff", marginBottom: 14, letterSpacing: "-0.5px" }}>
            Du bist dabei!
          </h2>
          <p style={{ color: "rgba(255,255,255,0.45)", fontSize: 15, lineHeight: 1.6 }}>
            Wir melden uns in Kürze bei dir. Mach dich bereit — dein Wachstum startet bald.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div style={{ minHeight: "100vh", background: "#080e0c", display: "flex", alignItems: "center", justifyContent: "center", padding: "40px 20px" }}>
      <div style={{ width: "100%", maxWidth: 480 }}>

        {/* Logo */}
        <div style={{ textAlign: "center", marginBottom: 20 }}>
          <a href="/" style={{ textDecoration: "none" }}>
            <span style={{ fontFamily: "'Bricolage Grotesque', sans-serif", fontSize: 24, fontWeight: 700, color: "#fff", letterSpacing: "-0.5px" }}>
              Sensalie<span style={{ color: "#00b894" }}>.</span>
            </span>
          </a>
        </div>

        {/* Scarcity badge */}
        <div style={{ textAlign: "center", marginBottom: 32 }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: 8, background: "rgba(0,184,148,0.1)", border: "1px solid rgba(0,184,148,0.3)", borderRadius: 100, padding: "7px 16px" }}>
            <span style={{ fontSize: 13 }}>🔒</span>
            <span style={{ color: "#00b894", fontSize: 13, fontWeight: 600 }}>Nur 50 Early-Access-Plätze — sichere dir jetzt deinen.</span>
          </div>
        </div>

        {/* Progress bar */}
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 36 }}>
          {steps.map((_, i) => (
            <React.Fragment key={i}>
              <div style={{
                width: 28, height: 28, borderRadius: "50%",
                background: i <= step ? "#00b894" : "rgba(255,255,255,0.08)",
                border: `2px solid ${i <= step ? "#00b894" : "rgba(255,255,255,0.12)"}`,
                display: "flex", alignItems: "center", justifyContent: "center",
                flexShrink: 0, transition: "all 0.3s ease",
              }}>
                {i < step ? (
                  <span style={{ color: "#fff", fontSize: 12, fontWeight: 700 }}>✓</span>
                ) : (
                  <span style={{ color: i === step ? "#fff" : "rgba(255,255,255,0.3)", fontSize: 12, fontWeight: 600 }}>{i + 1}</span>
                )}
              </div>
              {i < steps.length - 1 && (
                <div style={{ flex: 1, height: 2, borderRadius: 100, background: i < step ? "#00b894" : "rgba(255,255,255,0.08)", transition: "background 0.3s ease" }} />
              )}
            </React.Fragment>
          ))}
        </div>

        {/* Step header */}
        <div style={{ marginBottom: 28 }}>
          <p style={{ color: "#00b894", fontSize: 12, fontWeight: 700, letterSpacing: 3, textTransform: "uppercase", marginBottom: 8 }}>
            Schritt {step + 1} von {steps.length}
          </p>
          <h1 style={{ fontFamily: "'Bricolage Grotesque', sans-serif", fontSize: "clamp(22px, 4vw, 32px)", fontWeight: 800, color: "#fff", letterSpacing: "-0.5px", marginBottom: 6 }}>
            {steps[step].title}
          </h1>
          <p style={{ color: "rgba(255,255,255,0.4)", fontSize: 14 }}>{steps[step].subtitle}</p>
        </div>

        {/* Step 1 */}
        {step === 0 && (
          <form onSubmit={handleNext} style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <div>
              <label style={labelStyle}>Name deines Unternehmens</label>
              <input name="businessName" value={form.businessName} onChange={handleChange} required placeholder="z.B. Kings Barbershop" style={inputStyle} onFocus={onFocus} onBlur={onBlur} />
            </div>
            <div>
              <label style={labelStyle}>Branche</label>
              <select name="branch" value={form.branch} onChange={handleChange} required
                style={{ ...inputStyle, appearance: "none", cursor: "pointer", color: form.branch ? "#fff" : "rgba(255,255,255,0.35)" }}
                onFocus={onFocus} onBlur={onBlur}>
                <option value="" disabled style={{ background: "#0f1f16", color: "rgba(255,255,255,0.4)" }}>Bitte wählen</option>
                {branches.map(b => <option key={b} value={b} style={{ background: "#0f1f16", color: "#fff" }}>{b}</option>)}
              </select>
            </div>
            <button type="submit" style={btnStyle} onMouseEnter={e => e.currentTarget.style.background = "#00a07e"} onMouseLeave={e => e.currentTarget.style.background = "#00b894"}>
              Weiter →
            </button>
          </form>
        )}

        {/* Step 2 */}
        {step === 1 && (
          <form onSubmit={handleNext} style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <div>
              <label style={labelStyle}>Dein Name</label>
              <input name="name" value={form.name} onChange={handleChange} required placeholder="Wie heißt du?" style={inputStyle} onFocus={onFocus} onBlur={onBlur} />
            </div>
            <div>
              <label style={labelStyle}>E-Mail-Adresse</label>
              <input name="email" type="email" value={form.email} onChange={handleChange} required placeholder="du@example.com" style={inputStyle} onFocus={onFocus} onBlur={onBlur} />
            </div>
            <div>
              <label style={labelStyle}>Telefonnummer <span style={{ color: "rgba(255,255,255,0.3)", fontWeight: 400 }}>(optional)</span></label>
              <input name="phone" type="tel" value={form.phone} onChange={handleChange} placeholder="+49 123 456789" style={inputStyle} onFocus={onFocus} onBlur={onBlur} />
              <p style={{ color: "rgba(255,255,255,0.3)", fontSize: 12, marginTop: 6 }}>💬 Für sofortige Rückmeldung via WhatsApp</p>
            </div>
            <div style={{ display: "flex", gap: 12 }}>
              <button type="button" onClick={() => setStep(0)} style={{ ...btnStyle, background: "rgba(255,255,255,0.07)", border: "1px solid rgba(255,255,255,0.15)", flex: "0 0 auto", width: "auto", padding: "15px 20px" }}
                onMouseEnter={e => e.currentTarget.style.background = "rgba(255,255,255,0.12)"}
                onMouseLeave={e => e.currentTarget.style.background = "rgba(255,255,255,0.07)"}>
                ←
              </button>
              <button type="submit" style={{ ...btnStyle, flex: 1 }} onMouseEnter={e => e.currentTarget.style.background = "#00a07e"} onMouseLeave={e => e.currentTarget.style.background = "#00b894"}>
                Weiter →
              </button>
            </div>
          </form>
        )}

        {/* Step 3 */}
        {step === 2 && (
          <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <div>
              <label style={labelStyle}>
                Google Maps Link <span style={{ color: "rgba(255,255,255,0.3)", fontWeight: 400 }}>(optional)</span>
              </label>
              <input name="googleMaps" value={form.googleMaps} onChange={handleChange} placeholder="https://maps.google.com/..." style={inputStyle} onFocus={onFocus} onBlur={onBlur} />
              <style>{`
                @keyframes tipGlow {
                  0%, 100% { color: rgba(255,255,255,0.3); }
                  50% { color: rgba(0,184,148,0.9); }
                }
                .tip-blink { animation: tipGlow 2.4s ease-in-out infinite; }
              `}</style>
              <p className="tip-blink" style={{ fontSize: 12, marginTop: 8, lineHeight: 1.5 }}>
                💡 Wir holen automatisch deine Fotos & Infos — spart dir 10 Min. Setup
              </p>
            </div>
            <div style={{ display: "flex", gap: 12 }}>
              <button type="button" onClick={() => setStep(1)} style={{ ...btnStyle, background: "rgba(255,255,255,0.07)", border: "1px solid rgba(255,255,255,0.15)", flex: "0 0 auto", width: "auto", padding: "15px 20px" }}
                onMouseEnter={e => e.currentTarget.style.background = "rgba(255,255,255,0.12)"}
                onMouseLeave={e => e.currentTarget.style.background = "rgba(255,255,255,0.07)"}>
                ←
              </button>
              <button type="submit" disabled={loading} style={{ ...btnStyle, flex: 1, opacity: loading ? 0.7 : 1 }} onMouseEnter={e => e.currentTarget.style.background = "#00a07e"} onMouseLeave={e => e.currentTarget.style.background = "#00b894"}>
                {loading ? "Wird gespeichert..." : "Jetzt Platz sichern →"}
              </button>
            </div>
            {error && <p style={{ color: "#ff6b6b", fontSize: 13, textAlign: "center", marginTop: 4 }}>{error}</p>}
          </form>
        )}
      </div>
    </div>
  );
}

const btnStyle = {
  width: "100%",
  background: "#00b894",
  color: "#fff",
  fontWeight: 700,
  fontSize: 15,
  padding: "15px 24px",
  borderRadius: 100,
  border: "none",
  cursor: "pointer",
  transition: "background 0.2s",
  fontFamily: "inherit",
};