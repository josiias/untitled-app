import { useState, useEffect, useRef } from "react";
import SuggestBusinessTab from "@/components/customer/SuggestBusinessTab";
import SupportChatTab from "@/components/customer/SupportChatTab";
import NotificationSettings, { useNotificationChecker } from "@/components/customer/NotificationSettings";
import LevelSystem, { calcUserStats, LEVELS } from "@/components/customer/LevelSystem";
import { WelcomeBanner, TabHint } from "@/components/customer/OnboardingTooltips";
import ProfilePage from "@/components/customer/ProfilePage";

// ── Mock Data ──────────────────────────────────────────────────────────────────
const USER = { name: "Max Mustermann", phone: "0151 234 567 89", avatar: "MM", since: "März 2026" };

const STAMP_CARDS = [
  {
    id: 1, name: "Kings Barbershop", emoji: "✂️", category: "Barbershop",
    stamps: 5, required: 8, reward: "10€ Gutschein",
    img: "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?w=800&q=80",
    color: "#10B981",
    appointment: { date: "Mo, 21. Apr.", time: "14:00 Uhr", confirmed: true },
  },
  {
    id: 2, name: "Café Milano", emoji: "☕", category: "Café",
    stamps: 3, required: 6, reward: "1 Kaffee gratis",
    img: "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=800&q=80",
    color: "#F59E0B",
    appointment: null,
  },
  {
    id: 3, name: "Bella Nails", emoji: "💅", category: "Beauty",
    stamps: 7, required: 8, reward: "Maniküre gratis",
    img: "https://images.unsplash.com/photo-1604654894610-df63bc536371?w=800&q=80",
    color: "#EC4899",
    appointment: { date: "Do, 24. Apr.", time: "11:30 Uhr", confirmed: true },
  },
  {
    id: 4, name: "Massage Studio", emoji: "💆", category: "Wellness",
    stamps: 1, required: 10, reward: "1 Massage gratis",
    img: "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=800&q=80",
    color: "#8B5CF6",
    appointment: null,
  },
];

const REWARDS = [
  { id: 1, title: "10€ Gutschein", from: "Kings Barbershop", emoji: "✂️", expires: "30.06.2026", status: "bereit" },
  { id: 2, title: "Kaffee gratis", from: "Café Milano", emoji: "☕", expires: "15.05.2026", status: "bald" },
];

const REFERRAL_STATS = {
  code: "MAX2026",
  earned: 42.50,
  pending: 15.00,
  count: 3,
  history: [
    { name: "Sara K.", date: "10.04.2026", amount: 15.00, status: "ausstehend" },
    { name: "Jonas W.", date: "02.04.2026", amount: 12.50, status: "ausgezahlt" },
    { name: "Amir S.", date: "28.03.2026", amount: 15.00, status: "ausgezahlt" },
  ],
};

const PARTNER_BUSINESSES = [
  {
    id: 1, name: "Kings Barbershop", emoji: "✂️", category: "Barbershop",
    img: "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?w=800&q=80",
    reward: "10€ Gutschein", provision: "15€ pro Empfehlung", color: "#10B981", type: "both",
  },
  {
    id: 2, name: "Café Milano", emoji: "☕", category: "Café",
    img: "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=800&q=80",
    reward: "1 Kaffee gratis", provision: "8€ pro Empfehlung", color: "#F59E0B", type: "both",
  },
  {
    id: 3, name: "Bella Nails", emoji: "💅", category: "Nagelstudio",
    img: "https://images.unsplash.com/photo-1604654894610-df63bc536371?w=800&q=80",
    reward: "Maniküre gratis", provision: "12€ pro Empfehlung", color: "#EC4899", type: "both",
  },
  {
    id: 4, name: "Lotus Massage", emoji: "💆", category: "Massage",
    img: "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=800&q=80",
    reward: "1 Massage gratis", provision: "18€ pro Empfehlung", color: "#8B5CF6", type: "both",
  },
  {
    id: 5, name: "Sushi Lounge", emoji: "🍱", category: "Restaurant",
    img: "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=800&q=80",
    reward: "1 Rolle gratis", provision: "10€ pro Empfehlung", color: "#06B6D4", type: "both",
  },
  {
    id: 6, name: "Glam Studio", emoji: "💄", category: "Beauty",
    img: "https://images.unsplash.com/photo-1560066984-138dadb4c035?w=800&q=80",
    reward: "Styling gratis", provision: "14€ pro Empfehlung", color: "#F472B6", type: "both",
  },
];

const ACTIVITY = [
  { icon: "✂️", text: "Stempel bei Kings Barbershop", time: "Heute, 14:32", type: "stamp" },
  { icon: "💅", text: "Stempel bei Bella Nails", time: "Gestern, 11:05", type: "stamp" },
  { icon: "💸", text: "12,50€ Provision erhalten", time: "02.04.2026", type: "reward" },
  { icon: "✂️", text: "Stempel bei Kings Barbershop", time: "28.03.2026", type: "stamp" },
];

const TABS = [
  { id: "home", icon: "▦", label: "Übersicht" },
  { id: "cards", icon: "◈", label: "Karten" },
  { id: "rewards", icon: "⬡", label: "Prämien" },
  { id: "referral", icon: "◎", label: "Empfehlen" },
  { id: "suggest", icon: "💡", label: "Wunsch" },
  { id: "support", icon: "💬", label: "Support" },
  { id: "analytics", icon: "📈", label: "Analyse", comingSoon: true },
];

const CHART_POINTS = [
  { month: "Jan", saved: 0, earned: 0 },
  { month: "Feb", saved: 8, earned: 0 },
  { month: "Mär", saved: 8, earned: 12.5 },
  { month: "Apr", saved: 34, earned: 42.5 },
];

function LockedAnalyticsChart() {
  const [showModal, setShowModal] = useState(false);
  const W = 280, H = 90, pad = 10;
  const maxVal = 50;

  const toX = (i) => pad + (i / (CHART_POINTS.length - 1)) * (W - pad * 2);
  const toY = (v) => H - pad - (v / maxVal) * (H - pad * 2);

  const pathSaved = CHART_POINTS.map((d, i) => `${i === 0 ? "M" : "L"} ${toX(i)} ${toY(d.saved)}`).join(" ");
  const pathEarned = CHART_POINTS.map((d, i) => `${i === 0 ? "M" : "L"} ${toX(i)} ${toY(d.earned)}`).join(" ");

  return (
    <>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
        <div style={{ fontSize: 14, fontWeight: 700, color: "rgba(255,255,255,0.6)" }}>📈 Mein Verlauf</div>
        <div style={{ fontSize: 10, fontWeight: 600, color: "#A78BFA", background: "rgba(167,139,250,0.15)", padding: "2px 8px", borderRadius: 6 }}>PLUS</div>
      </div>

      <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 20, padding: 16, position: "relative" }}>
        <div style={{ display: "flex", gap: 24, marginBottom: 12 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <div style={{ width: 8, height: 8, borderRadius: "50%", background: "#10B981" }} />
            <span style={{ fontSize: 11, color: "rgba(255,255,255,0.5)" }}>Gespart</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <div style={{ width: 8, height: 8, borderRadius: "50%", background: "#A78BFA" }} />
            <span style={{ fontSize: 11, color: "rgba(255,255,255,0.5)" }}>Verdient</span>
          </div>
        </div>

        <svg width={W} height={H} style={{ width: "100%", height: "auto" }}>
          {[0, 0.25, 0.5, 0.75, 1].map((t, i) => (
            <line key={i} x1={pad} y1={toY(t * maxVal)} x2={W - pad} y2={toY(t * maxVal)} stroke="rgba(255,255,255,0.05)" strokeWidth={1} />
          ))}
          <path d={pathSaved} fill="none" stroke="#10B981" strokeWidth={2} />
          <path d={pathEarned} fill="none" stroke="#A78BFA" strokeWidth={2} />
          {CHART_POINTS.map((d, i) => (
            <circle key={i} cx={toX(i)} cy={toY(d.saved)} r={3} fill="#10B981" />
          ))}
          {CHART_POINTS.map((d, i) => (
            <circle key={`e${i}`} cx={toX(i)} cy={toY(d.earned)} r={3} fill="#A78BFA" />
          ))}
          {CHART_POINTS.map((d, i) => (
            <text key={`t${i}`} x={toX(i)} y={H - 2} textAnchor="middle" fontSize={10} fill="rgba(255,255,255,0.3)">{d.month}</text>
          ))}
        </svg>

        <div onClick={() => setShowModal(true)} style={{
          position: "absolute", inset: 0, borderRadius: 20,
          background: "rgba(10,15,22,0.55)", backdropFilter: "blur(3px)",
          display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 6,
          cursor: "pointer",
        }}>
          <div style={{ fontSize: 32 }}>🔒</div>
          <div style={{ fontSize: 12, fontWeight: 700, color: "#fff", textAlign: "center" }}>Sensalie Plus freischalten</div>
        </div>

        {showModal && (
          <div onClick={() => setShowModal(false)} style={{ position: "fixed", inset: 0, zIndex: 100, background: "rgba(0,0,0,0.75)", backdropFilter: "blur(10px)", display: "flex", alignItems: "flex-end", justifyContent: "center" }}>
            <div onClick={e => e.stopPropagation()} style={{ width: "100%", maxWidth: 600, background: "#111e28", borderRadius: "28px 28px 0 0", border: "1px solid rgba(168,85,247,0.2)", borderBottom: "none", padding: "24px 24px 48px" }}>
              <div style={{ textAlign: "center", marginBottom: 24 }}>
                <div style={{ fontSize: 40, marginBottom: 12 }}>📈</div>
                <div style={{ fontSize: 18, fontWeight: 800, color: "#fff", marginBottom: 4 }}>Detaillierte Analyse</div>
                <div style={{ fontSize: 12, color: "rgba(255,255,255,0.45)" }}>Sieh genau, wie viel du pro Monat sparst und verdienst — mit Sensalie Plus.</div>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 24 }}>
                {["Vollständige Sparübersicht", "Monatliche Verdienstanalyse", "Empfehlungs-Statistiken"].map((f, i) => (
                  <div key={i} style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13, color: "rgba(255,255,255,0.7)" }}>
                    <span style={{ color: "#A78BFA" }}>✦</span>{f}
                  </div>
                ))}
              </div>
              <div style={{ background: "rgba(167,139,250,0.1)", border: "1px solid rgba(167,139,250,0.2)", borderRadius: 14, padding: 14, marginBottom: 20, textAlign: "center" }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: "#A78BFA", marginBottom: 4 }}>Sensalie Plus · 1,99 € / Monat</div>
                <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)" }}>Bald verfügbar</div>
              </div>
              <button onClick={() => setShowModal(false)} style={{ width: "100%", padding: "12px", background: "rgba(255,255,255,0.06)", color: "rgba(255,255,255,0.4)", border: "none", borderRadius: 12, fontSize: 13, cursor: "pointer", fontFamily: "inherit" }}>
                Schließen
              </button>
            </div>
          </div>
        )}
      </div>
    </>
  );
}

function StampDots({ stamps, required, color }) {
  const safeRequired = Math.max(1, Math.floor(Number(required) || 8));
  const safeStamps = Math.max(0, Math.floor(Number(stamps) || 0));
  const safeColor = color || "#10B981";
  const items = Array.from({ length: safeRequired }, (_, i) => i);
  return (
    <div style={{ display: "grid", gridTemplateColumns: `repeat(${Math.min(safeRequired, 8)}, 1fr)`, gap: 4 }}>
      {items.map((i) => (
        <div key={i} style={{ aspectRatio: "1/1", borderRadius: 6, background: i < safeStamps ? safeColor : "rgba(255,255,255,0.06)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, color: "#fff", fontWeight: 700, transition: "background 0.3s" }}>
          {i < safeStamps ? "✓" : ""}
        </div>
      ))}
    </div>
  );
}

function StampCard({ card, compact = false, onBookAppointment }) {
  const pct = Math.round((card.stamps / card.required) * 100);
  const isAlmostDone = card.stamps >= card.required - 1;

  return (
    <div style={{ borderRadius: 20, overflow: "hidden", background: "#111e28", border: "1px solid rgba(255,255,255,0.08)", position: "relative" }}>
      <img src={card.img} alt={card.name} style={{ width: "100%", height: 180, objectFit: "cover", display: "block" }} />
      {isAlmostDone && (
        <div style={{ position: "absolute", top: 12, right: 12, background: card.color, color: "#fff", fontSize: 12, fontWeight: 800, padding: "6px 12px", borderRadius: 100, boxShadow: `0 4px 12px ${card.color}60` }}>
          Fast da! 🎉
        </div>
      )}
      <div style={{ padding: "16px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12 }}>
          <div style={{ width: 44, height: 44, borderRadius: 12, background: `${card.color}22`, border: `1.5px solid ${card.color}44`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20, flexShrink: 0 }}>
            {card.emoji}
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 14, fontWeight: 800, color: "#fff" }}>{card.name}</div>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)" }}>{card.category}</div>
          </div>
        </div>

        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
          <span style={{ fontSize: 11, color: "rgba(255,255,255,0.4)" }}>Fortschritt</span>
          <span style={{ fontSize: 11, fontWeight: 700, color: card.color }}>{card.stamps}/{card.required}</span>
        </div>
        <div style={{ height: 4, background: "rgba(255,255,255,0.08)", borderRadius: 100, marginBottom: compact ? 14 : 10 }}>
          <div style={{ height: "100%", width: `${pct}%`, background: card.color, borderRadius: 100, transition: "width 0.6s ease" }} />
        </div>
        {!compact && <StampDots stamps={card.stamps} required={card.required} color={card.color} />}

        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 12, paddingTop: 12, borderTop: "1px solid rgba(255,255,255,0.06)" }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: card.color, display: "flex", alignItems: "center", gap: 4 }}>
            🎁 {card.reward}
          </div>
          {card.appointment ? (
            <button onClick={onBookAppointment && (() => onBookAppointment(card))} style={{ display: "flex", alignItems: "center", gap: 4, background: "rgba(255,255,255,0.07)", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 8, padding: "4px 8px", cursor: "pointer", fontSize: 10, color: "rgba(255,255,255,0.6)", fontFamily: "inherit" }}>
              📅{card.appointment.date}
            </button>
          ) : (
            <button onClick={onBookAppointment && (() => onBookAppointment(card))} style={{ background: `${card.color}22`, border: `1px solid ${card.color}44`, borderRadius: 8, padding: "4px 8px", cursor: "pointer", fontSize: 10, color: card.color, fontWeight: 700, fontFamily: "inherit" }}>
              📅 Termin buchen
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

function Leaderboard() {
  const topUsers = [
    { rank: 1, name: "Anna W.", level: "Diamond", points: 2840 },
    { rank: 2, name: "Max M.", level: "Platinum", points: 2650 },
    { rank: 3, name: "Sophie K.", level: "Gold", points: 2420 },
    { rank: 4, name: "Lukas B.", level: "Silver", points: 1950 },
    { rank: 5, name: "Emma L.", level: "Bronze", points: 1620 },
  ];

  return (
    <div>
      <div style={{ fontSize: 14, fontWeight: 700, color: "rgba(255,255,255,0.6)", marginBottom: 12 }}>🏆 Top Nutzer</div>
      <div style={{ background: "rgba(255,255,255,0.03)", borderRadius: 16, overflow: "hidden" }}>
        {topUsers.map((user, i) => (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 16px", borderBottom: i < topUsers.length - 1 ? "1px solid rgba(255,255,255,0.05)" : "none" }}>
            <div style={{ width: 32, height: 32, borderRadius: "50%", background: i === 0 ? "#FFD700" : i === 1 ? "#C0C0C0" : "#CD7F32", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, fontWeight: 800, color: "#000" }}>
              {i < 3 ? ["🥇", "🥈", "🥉"][i] : user.rank}
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: "#fff" }}>{user.name}</div>
              <div style={{ fontSize: 10, color: "rgba(255,255,255,0.4)" }}>{user.level} • {user.points.toLocaleString()} Punkte</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function CustomerDashboard() {
  const [activeTab, setActiveTab] = useState("home");
  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [copied, setCopied] = useState(false);

  useNotificationChecker([], []);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(REFERRAL_STATS.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (showProfile) return <ProfilePage onClose={() => setShowProfile(false)} />;

  return (
    <div style={{ background: "#0a0f16", minHeight: "100vh", color: "#fff", fontFamily: "'Inter', sans-serif", paddingBottom: 80, position: "relative", maxWidth: 600, margin: "0 auto" }}>
      <div style={{ position: "fixed", top: -100, right: -100, width: 300, height: 300, background: "radial-gradient(circle, rgba(16,185,129,0.08) 0%, transparent 70%)", pointerEvents: "none", zIndex: 0 }} />

      {/* Header */}
      <div style={{ position: "sticky", top: 0, zIndex: 20, background: "rgba(10,15,22,0.92)", backdropFilter: "blur(20px)", padding: "14px 20px", borderBottom: "1px solid rgba(255,255,255,0.06)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ fontSize: 18, fontWeight: 800, letterSpacing: -0.5 }}>Sensalie<span style={{ color: "#10B981" }}>.</span></div>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <button onClick={() => setShowNotifications(!showNotifications)} style={{ width: 36, height: 36, borderRadius: 10, background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>🔔</button>
          <button onClick={() => setShowProfile(true)} style={{ width: 36, height: 36, borderRadius: 10, background: "linear-gradient(135deg, #10B981, #059669)", border: "none", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 800, color: "#fff" }}>{USER.avatar}</button>
        </div>
      </div>

      {showNotifications && (
        <div style={{ position: "fixed", inset: 0, zIndex: 50, background: "rgba(0,0,0,0.6)", backdropFilter: "blur(8px)", display: "flex", alignItems: "flex-end", justifyContent: "center" }} onClick={() => setShowNotifications(false)}>
          <div onClick={e => e.stopPropagation()} style={{ width: "100%", maxWidth: 600, padding: "0 0 20px" }}>
            <NotificationSettings onClose={() => setShowNotifications(false)} />
          </div>
        </div>
      )}

      {/* Main Content */}
      <div style={{ padding: "20px", position: "relative", zIndex: 1 }}>
        <TabHint tabId={activeTab} />

        {activeTab === "home" && (
          <div>
            <WelcomeBanner userName={USER.name} />
            <div style={{ marginBottom: 24 }}>
              <div style={{ fontSize: 22, fontWeight: 800, color: "#fff" }}>Hey, {USER.name.split(" ")[0]} 👋</div>
              <div style={{ fontSize: 13, color: "rgba(255,255,255,0.4)", marginTop: 4 }}>Seit {USER.since} dabei</div>
            </div>

            {/* Stats */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10, marginBottom: 24 }}>
              {[
                { label: "Stempel", value: 18, color: "#10B981", emoji: "⬛" },
                { label: "Prämien", value: 2, color: "#F59E0B", emoji: "🎁" },
                { label: "Verdient", value: "42,50€", color: "#EC4899", emoji: "💸" },
              ].map((s, i) => (
                <div key={i} style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 16, padding: "14px 12px", textAlign: "center" }}>
                  <div style={{ fontSize: 18 }}>{s.emoji}</div>
                  <div style={{ fontSize: 20, fontWeight: 800, color: s.color, marginTop: 4 }}>{s.value}</div>
                  <div style={{ fontSize: 10, color: "rgba(255,255,255,0.35)", marginTop: 2 }}>{s.label}</div>
                </div>
              ))}
            </div>

            {/* Stamp Cards */}
            <div style={{ marginBottom: 24 }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: "rgba(255,255,255,0.6)", marginBottom: 12 }}>Aktuelle Karten</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                {STAMP_CARDS.slice(0, 2).map(card => <StampCard key={card.id} card={card} compact />)}
              </div>
              {STAMP_CARDS.length > 2 && (
                <button onClick={() => setActiveTab("cards")} style={{ width: "100%", marginTop: 12, padding: "10px", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 12, color: "rgba(255,255,255,0.5)", fontSize: 12, fontWeight: 600, cursor: "pointer", fontFamily: "inherit" }}>
                  Alle {STAMP_CARDS.length} Karten anzeigen →
                </button>
              )}
            </div>

            {/* Activity */}
            {ACTIVITY.length > 0 && (
              <div style={{ marginBottom: 24 }}>
                <div style={{ fontSize: 14, fontWeight: 700, color: "rgba(255,255,255,0.6)", marginBottom: 12 }}>Aktivität</div>
                <div style={{ background: "rgba(255,255,255,0.03)", borderRadius: 16, overflow: "hidden" }}>
                  {ACTIVITY.map((item, i) => (
                    <div key={i} style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 16px", borderBottom: i < ACTIVITY.length - 1 ? "1px solid rgba(255,255,255,0.05)" : "none" }}>
                      <span style={{ fontSize: 18 }}>{item.icon}</span>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 13, color: "#fff" }}>{item.text}</div>
                        <div style={{ fontSize: 11, color: "rgba(255,255,255,0.35)", marginTop: 1 }}>{item.time}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Analytics */}
            <LockedAnalyticsChart />

            {/* Leaderboard */}
            <div style={{ marginTop: 24 }}>
              <Leaderboard />
            </div>
          </div>
        )}

        {activeTab === "cards" && (
          <div>
            <div style={{ fontSize: 18, fontWeight: 800, marginBottom: 20 }}>Meine Stempelkarten</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
              {STAMP_CARDS.map(card => <StampCard key={card.id} card={card} />)}
            </div>
          </div>
        )}

        {activeTab === "rewards" && (
          <div>
            <div style={{ fontSize: 18, fontWeight: 800, marginBottom: 20 }}>Meine Prämien</div>
            {REWARDS.length === 0 ? (
              <div style={{ textAlign: "center", padding: 40, color: "rgba(255,255,255,0.3)" }}>
                <div style={{ fontSize: 32, marginBottom: 8 }}>🎁</div>
                <div style={{ fontSize: 13, lineHeight: 1.6 }}>Noch keine Prämien — sammel weiter Stempel!</div>
              </div>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                {REWARDS.map(reward => (
                  <div key={reward.id} style={{ background: "linear-gradient(135deg, rgba(16,185,129,0.12), rgba(16,185,129,0.04))", border: "1px solid rgba(16,185,129,0.3)", borderRadius: 16, padding: 16, display: "flex", alignItems: "center", gap: 14 }}>
                    <div style={{ width: 48, height: 48, borderRadius: 14, background: "rgba(16,185,129,0.2)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22 }}>🎁</div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 14, fontWeight: 700, color: "#fff" }}>{reward.title}</div>
                      <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", marginTop: 2 }}>{reward.from} • Gültig bis {reward.expires}</div>
                    </div>
                    <div style={{ padding: "6px 14px", borderRadius: 100, background: "#10B981", color: "#fff", fontSize: 11, fontWeight: 700 }}>
                      Einlösen
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === "referral" && (
          <div>
            <div style={{ fontSize: 18, fontWeight: 800, marginBottom: 20 }}>Empfehlen & Verdienen</div>
            <div style={{ background: "linear-gradient(135deg, rgba(16,185,129,0.15), rgba(16,185,129,0.05))", border: "1px solid rgba(16,185,129,0.25)", borderRadius: 20, padding: 20, marginBottom: 20 }}>
              <div style={{ fontSize: 13, color: "rgba(255,255,255,0.5)", marginBottom: 6 }}>Dein Empfehlungscode</div>
              <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                <div style={{ flex: 1, background: "rgba(255,255,255,0.06)", borderRadius: 12, padding: "12px 16px", fontSize: 18, fontWeight: 800, letterSpacing: 2, color: "#10B981" }}>{REFERRAL_STATS.code}</div>
                <button onClick={handleCopyCode} style={{ padding: "12px 16px", background: copied ? "rgba(16,185,129,0.3)" : "#10B981", color: "#fff", fontWeight: 700, fontSize: 13, borderRadius: 12, border: "none", cursor: "pointer", fontFamily: "inherit", transition: "all 0.2s", whiteSpace: "nowrap" }}>
                  {copied ? "✓ Kopiert!" : "Kopieren"}
                </button>
              </div>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10, marginBottom: 20 }}>
              {[
                { label: "Verdient", value: `${REFERRAL_STATS.earned.toFixed(2)}€`, color: "#10B981" },
                { label: "Ausstehend", value: `${REFERRAL_STATS.pending.toFixed(2)}€`, color: "#F59E0B" },
                { label: "Empfehlungen", value: REFERRAL_STATS.count, color: "#8B5CF6" },
              ].map((s, i) => (
                <div key={i} style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 14, padding: "14px 10px", textAlign: "center" }}>
                  <div style={{ fontSize: 18, fontWeight: 800, color: s.color }}>{s.value}</div>
                  <div style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", marginTop: 2 }}>{s.label}</div>
                </div>
              ))}
            </div>
            <div style={{ background: "rgba(255,255,255,0.03)", borderRadius: 16, overflow: "hidden" }}>
              <div style={{ padding: "12px 16px", borderBottom: "1px solid rgba(255,255,255,0.06)", fontSize: 13, fontWeight: 700, color: "rgba(255,255,255,0.6)" }}>Empfehlungs-Verlauf</div>
              {REFERRAL_STATS.history.map((h, i) => (
                <div key={i} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "12px 16px", borderBottom: i < REFERRAL_STATS.history.length - 1 ? "1px solid rgba(255,255,255,0.05)" : "none" }}>
                  <div>
                    <div style={{ fontSize: 13, color: "#fff", fontWeight: 600 }}>{h.name}</div>
                    <div style={{ fontSize: 11, color: "rgba(255,255,255,0.35)", marginTop: 1 }}>{h.date}</div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <div style={{ fontSize: 14, fontWeight: 700, color: h.status === "ausgezahlt" ? "#10B981" : "#F59E0B" }}>+{h.amount.toFixed(2)}€</div>
                    <div style={{ fontSize: 10, color: "rgba(255,255,255,0.35)", marginTop: 1 }}>{h.status}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === "suggest" && (
          <div>
            <div style={{ fontSize: 18, fontWeight: 800, marginBottom: 20 }}>Partner entdecken</div>
            <SuggestBusinessTab businesses={PARTNER_BUSINESSES} loadingBiz={false} />
          </div>
        )}

        {activeTab === "support" && (
          <div>
            <div style={{ fontSize: 18, fontWeight: 800, marginBottom: 20 }}>Support</div>
            <SupportChatTab />
          </div>
        )}
      </div>

      {/* Bottom Nav */}
      <div style={{ position: "fixed", bottom: 0, left: "50%", transform: "translateX(-50%)", width: "100%", maxWidth: 600, background: "rgba(10,15,22,0.95)", backdropFilter: "blur(20px)", borderTop: "1px solid rgba(255,255,255,0.08)", padding: "8px 0 env(safe-area-inset-bottom)", zIndex: 20 }}>
        <div style={{ display: "flex", justifyContent: "space-around" }}>
          {TABS.map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 3, padding: "8px 12px", background: "none", border: "none", cursor: "pointer", fontFamily: "inherit", transition: "all 0.2s", color: activeTab === tab.id ? "#10B981" : "rgba(255,255,255,0.3)", opacity: tab.comingSoon ? 0.5 : 1, pointerEvents: tab.comingSoon ? "none" : "auto" }}>
              <span style={{ fontSize: 16 }}>{tab.icon}</span>
              <span style={{ fontSize: 9, fontWeight: 700 }}>{tab.label}</span>
              {activeTab === tab.id && <div style={{ width: 4, height: 4, borderRadius: "50%", background: "#10B981", marginTop: 1 }} />}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}