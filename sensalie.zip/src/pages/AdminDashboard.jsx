import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line
} from "recharts";
import { Building2, Users, Stamp, Euro, TrendingUp, Award, Check, Loader2 } from "lucide-react";

// ─── helpers ──────────────────────────────────────────────────────────────────
const fmt = (n) => Number(n || 0).toFixed(2);
const fmtDate = (d) => new Date(d).toLocaleDateString("de-DE", { day: "2-digit", month: "short" });

// Build last-N-days labels
const lastNDays = (n) => {
  const result = [];
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    result.push({ date: d.toISOString().slice(0, 10), label: d.toLocaleDateString("de-DE", { day: "2-digit", month: "short" }) });
  }
  return result;
};

const COLORS = ["#10B981", "#F59E0B", "#8B5CF6", "#EC4899", "#3B82F6"];

// ─── Stat Card ────────────────────────────────────────────────────────────────
function StatCard({ label, value, icon: Icon, sub, color = "#10B981" }) {
  return (
    <div style={{ background: "#fff", border: "1px solid rgba(0,0,0,0.07)", borderRadius: 16, padding: "20px 22px", display: "flex", flexDirection: "column", gap: 6 }}>
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between" }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: "#9ca3af", letterSpacing: 0.5, textTransform: "uppercase" }}>{label}</div>
        <div style={{ width: 32, height: 32, borderRadius: 10, background: `${color}15`, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <Icon size={16} color={color} />
        </div>
      </div>
      <div style={{ fontSize: 30, fontWeight: 900, color: "#111827", lineHeight: 1 }}>{value}</div>
      {sub && <div style={{ fontSize: 11, color: "#9ca3af", marginTop: 2 }}>{sub}</div>}
    </div>
  );
}

// ─── Section wrapper ──────────────────────────────────────────────────────────
function Card({ title, children, style }) {
  return (
    <div style={{ background: "#fff", border: "1px solid rgba(0,0,0,0.07)", borderRadius: 16, padding: "22px 22px 18px", ...style }}>
      {title && <div style={{ fontSize: 13, fontWeight: 700, color: "#374151", marginBottom: 16 }}>{title}</div>}
      {children}
    </div>
  );
}

// ─── Custom Tooltip ───────────────────────────────────────────────────────────
function ChartTip({ active, payload, label, unit = "" }) {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background: "#111827", border: "none", borderRadius: 10, padding: "8px 14px", fontSize: 12, color: "#fff" }}>
      <div style={{ color: "#9ca3af", marginBottom: 4 }}>{label}</div>
      {payload.map((p, i) => (
        <div key={i} style={{ color: p.color || "#10B981", fontWeight: 700 }}>{p.name}: {p.value}{unit}</div>
      ))}
    </div>
  );
}

// ─── Main ─────────────────────────────────────────────────────────────────────
export default function AdminDashboard() {
  const { user } = useAuth();
  const [businesses, setBusinesses] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [payouts, setPayouts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("analytics");
  const [updatingPayout, setUpdatingPayout] = useState(null);

  useEffect(() => {
    if (user && user.role !== "admin") window.location.href = "/";
  }, [user]);

  useEffect(() => {
    const load = async () => {
      try {
        const [biz, cust, trans, pay] = await Promise.all([
          base44.entities.Business.list(),
          base44.entities.Customer.list(),
          base44.entities.StampTransaction.list("-created_date", 500),
          base44.entities.ReferralPayout.list("-created_date", 200),
        ]);
        setBusinesses(biz); setCustomers(cust); setTransactions(trans); setPayouts(pay);
      } catch (e) { console.error(e); }
      finally { setLoading(false); }
    };
    load();
  }, []);

  const updatePayoutStatus = async (id, status) => {
    setUpdatingPayout(id);
    await base44.entities.ReferralPayout.update(id, { status });
    setPayouts(p => p.map(x => x.id === id ? { ...x, status } : x));
    setUpdatingPayout(null);
  };

  const toggleBusinessLock = async (biz) => {
    const newLocked = !biz.is_locked;
    await base44.entities.Business.update(biz.id, { is_locked: newLocked });
    setBusinesses(b => b.map(x => x.id === biz.id ? { ...x, is_locked: newLocked } : x));
  };

  // ── derived analytics ──────────────────────────────────────────────────────
  const totalRevenue = transactions.reduce((s, t) => s + (t.amount || 0), 0);
  const openPayoutsTotal = payouts.filter(p => p.status === "offen").reduce((s, p) => s + p.amount, 0);
  const paidPayoutsTotal = payouts.filter(p => p.status === "ausgezahlt").reduce((s, p) => s + p.amount, 0);

  // Stamps per day (last 14 days)
  const days14 = lastNDays(14);
  const stampsPerDay = days14.map(({ date, label }) => ({
    label,
    Stempel: transactions.filter(t => t.created_date?.slice(0, 10) === date).length,
  }));

  // Payouts per day (last 14 days)
  const payoutsPerDay = days14.map(({ date, label }) => ({
    label,
    "Provision €": payouts.filter(p => p.created_date?.slice(0, 10) === date).reduce((s, p) => s + p.amount, 0),
  }));

  // Top customers by stamps
  const topCustomers = [...customers]
    .sort((a, b) => (b.total_stamps || 0) - (a.total_stamps || 0))
    .slice(0, 8)
    .map(c => ({ name: c.name?.split(" ")[0] || "?", Stempel: c.total_stamps || 0, Besuche: c.total_visits || 0 }));

  // Business breakdown: stamps per business
  const bizMap = {};
  businesses.forEach(b => { bizMap[b.id] = b.name; });
  const stampsPerBiz = businesses.map(b => ({
    name: b.name?.split(" ")[0] || b.name,
    value: transactions.filter(t => t.business_id === b.id).length,
  })).filter(x => x.value > 0).sort((a, b) => b.value - a.value);

  // Hour distribution of stamps
  const hourData = Array.from({ length: 24 }, (_, h) => ({
    hour: `${h}h`,
    Scans: transactions.filter(t => {
      const d = new Date(t.created_date);
      return d.getHours() === h;
    }).length,
  }));

  // Referral conversion rate
  const customersWithReferral = customers.filter(c => c.referred_by).length;
  const referralRate = customers.length ? Math.round((customersWithReferral / customers.length) * 100) : 0;

  const TABS = [
    { id: "analytics", label: "Analytics" },
    { id: "businesses", label: "Unternehmen" },
    { id: "customers", label: "Kunden" },
    { id: "payouts", label: "Provisionen" },
    { id: "transactions", label: "Transaktionen" },
  ];

  if (!user || user.role !== "admin") {
    return <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center" }}><div style={{ color: "#ef4444", fontWeight: 600 }}>Zugriff verweigert</div></div>;
  }

  if (loading) {
    return <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center" }}><Loader2 size={32} color="#10B981" style={{ animation: "spin 1s linear infinite" }} /></div>;
  }

  return (
    <div style={{ minHeight: "100vh", background: "#f3f4f6", fontFamily: "'Inter', sans-serif" }}>
      <style>{`@keyframes spin { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }`}</style>

      {/* Header */}
      <div style={{ background: "#fff", borderBottom: "1px solid rgba(0,0,0,0.07)", padding: "0 24px", position: "sticky", top: 0, zIndex: 20 }}>
        <div style={{ maxWidth: 1280, margin: "0 auto", height: 60, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 34, height: 34, background: "#10B981", borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>⚙️</div>
            <div>
              <div style={{ fontSize: 16, fontWeight: 800, color: "#111827" }}>Sensalie Admin</div>
              <div style={{ fontSize: 11, color: "#9ca3af" }}>Operator Dashboard</div>
            </div>
          </div>
          <a href="/" style={{ fontSize: 13, color: "#10B981", textDecoration: "none", fontWeight: 600 }}>← Zurück</a>
        </div>
      </div>

      <div style={{ maxWidth: 1280, margin: "0 auto", padding: "28px 24px 60px" }}>

        {/* KPI Row */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 14, marginBottom: 28 }}>
          <StatCard label="Unternehmen" value={businesses.length} icon={Building2} sub={`${businesses.filter(b => !b.is_locked).length} aktiv`} />
          <StatCard label="Kunden" value={customers.length} icon={Users} sub={`${referralRate}% via Empfehlung`} color="#8B5CF6" />
          <StatCard label="Stempel total" value={transactions.length} icon={Stamp} sub={`${stampsPerDay[13]?.Stempel || 0} heute`} color="#F59E0B" />
          <StatCard label="Gesamtumsatz" value={`${fmt(totalRevenue)} €`} icon={TrendingUp} sub="aus Transaktionen" color="#3B82F6" />
          <StatCard label="Prov. offen" value={`${fmt(openPayoutsTotal)} €`} icon={Euro} sub={`${fmt(paidPayoutsTotal)} € ausgezahlt`} color="#EC4899" />
          <StatCard label="Empfehlungen" value={payouts.length} icon={Award} sub={`${payouts.filter(p => p.status === "offen").length} offen`} color="#10B981" />
        </div>

        {/* Tabs */}
        <div style={{ display: "flex", gap: 4, marginBottom: 24, background: "#fff", borderRadius: 12, padding: 4, border: "1px solid rgba(0,0,0,0.07)", width: "fit-content", flexWrap: "wrap" }}>
          {TABS.map(t => (
            <button key={t.id} onClick={() => setActiveTab(t.id)} style={{
              padding: "8px 16px", borderRadius: 8, border: "none", cursor: "pointer",
              background: activeTab === t.id ? "#10B981" : "transparent",
              color: activeTab === t.id ? "#fff" : "#6b7280",
              fontWeight: activeTab === t.id ? 700 : 500, fontSize: 13,
              fontFamily: "inherit", transition: "all 0.2s",
            }}>{t.label}</button>
          ))}
        </div>

        {/* ── ANALYTICS TAB ── */}
        {activeTab === "analytics" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>

            {/* Row 1: Stamps trend + Payout trend */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18 }}>
              <Card title="Stempel pro Tag (letzte 14 Tage)">
                <ResponsiveContainer width="100%" height={200}>
                  <AreaChart data={stampsPerDay} margin={{ top: 4, right: 4, bottom: 0, left: -20 }}>
                    <defs>
                      <linearGradient id="stampGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10B981" stopOpacity={0.25} />
                        <stop offset="95%" stopColor="#10B981" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" />
                    <XAxis dataKey="label" tick={{ fontSize: 10, fill: "#9ca3af" }} tickLine={false} axisLine={false} />
                    <YAxis tick={{ fontSize: 10, fill: "#9ca3af" }} tickLine={false} axisLine={false} />
                    <Tooltip content={<ChartTip />} />
                    <Area type="monotone" dataKey="Stempel" stroke="#10B981" strokeWidth={2} fill="url(#stampGrad)" dot={false} />
                  </AreaChart>
                </ResponsiveContainer>
              </Card>

              <Card title="Provisionen pro Tag (letzte 14 Tage)">
                <ResponsiveContainer width="100%" height={200}>
                  <AreaChart data={payoutsPerDay} margin={{ top: 4, right: 4, bottom: 0, left: -10 }}>
                    <defs>
                      <linearGradient id="payGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#8B5CF6" stopOpacity={0.25} />
                        <stop offset="95%" stopColor="#8B5CF6" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" />
                    <XAxis dataKey="label" tick={{ fontSize: 10, fill: "#9ca3af" }} tickLine={false} axisLine={false} />
                    <YAxis tick={{ fontSize: 10, fill: "#9ca3af" }} tickLine={false} axisLine={false} />
                    <Tooltip content={<ChartTip unit=" €" />} />
                    <Area type="monotone" dataKey="Provision €" stroke="#8B5CF6" strokeWidth={2} fill="url(#payGrad)" dot={false} />
                  </AreaChart>
                </ResponsiveContainer>
              </Card>
            </div>

            {/* Row 2: Top Customers + Business Pie */}
            <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 18 }}>
              <Card title="Top Kunden nach Stempeln">
                <ResponsiveContainer width="100%" height={220}>
                  <BarChart data={topCustomers} layout="vertical" margin={{ top: 0, right: 12, bottom: 0, left: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" horizontal={false} />
                    <XAxis type="number" tick={{ fontSize: 10, fill: "#9ca3af" }} tickLine={false} axisLine={false} />
                    <YAxis dataKey="name" type="category" tick={{ fontSize: 11, fill: "#374151", fontWeight: 600 }} tickLine={false} axisLine={false} width={64} />
                    <Tooltip content={<ChartTip />} />
                    <Bar dataKey="Stempel" fill="#10B981" radius={[0, 6, 6, 0]} />
                    <Bar dataKey="Besuche" fill="#D1FAE5" radius={[0, 6, 6, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </Card>

              <Card title="Stempel je Unternehmen">
                {stampsPerBiz.length === 0 ? (
                  <div style={{ height: 220, display: "flex", alignItems: "center", justifyContent: "center", color: "#9ca3af", fontSize: 13 }}>Noch keine Daten</div>
                ) : (
                  <>
                    <ResponsiveContainer width="100%" height={170}>
                      <PieChart>
                        <Pie data={stampsPerBiz} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={70} innerRadius={40}>
                          {stampsPerBiz.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                        </Pie>
                        <Tooltip content={({ active, payload }) => active && payload?.length ? (
                          <div style={{ background: "#111827", borderRadius: 10, padding: "8px 14px", fontSize: 12, color: "#fff" }}>
                            <div style={{ fontWeight: 700, color: payload[0].payload.fill }}>{payload[0].name}</div>
                            <div>{payload[0].value} Stempel</div>
                          </div>
                        ) : null} />
                      </PieChart>
                    </ResponsiveContainer>
                    <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
                      {stampsPerBiz.slice(0, 4).map((b, i) => (
                        <div key={i} style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 11 }}>
                          <div style={{ width: 8, height: 8, borderRadius: "50%", background: COLORS[i % COLORS.length], flexShrink: 0 }} />
                          <span style={{ color: "#374151", flex: 1 }}>{b.name}</span>
                          <span style={{ color: "#6b7280", fontWeight: 600 }}>{b.value}</span>
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </Card>
            </div>

            {/* Row 3: Hour heatmap */}
            <Card title="Scan-Aktivität nach Uhrzeit">
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={hourData} margin={{ top: 4, right: 4, bottom: 0, left: -20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" vertical={false} />
                  <XAxis dataKey="hour" tick={{ fontSize: 9, fill: "#9ca3af" }} tickLine={false} axisLine={false} interval={1} />
                  <YAxis tick={{ fontSize: 10, fill: "#9ca3af" }} tickLine={false} axisLine={false} />
                  <Tooltip content={<ChartTip />} />
                  <Bar dataKey="Scans" fill="#F59E0B" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </Card>

            {/* Row 4: Referral funnel numbers */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 14 }}>
              {[
                { label: "Neukunden via Empfehlung", value: customersWithReferral, of: customers.length, color: "#10B981" },
                { label: "Empfehler aktiv", value: [...new Set(payouts.map(p => p.referrer_customer_id))].length, of: customers.length, color: "#8B5CF6" },
                { label: "Conversion-Rate", value: `${referralRate}%`, of: null, color: "#F59E0B" },
                { label: "Ø Stempel / Kunde", value: customers.length ? Math.round(customers.reduce((s, c) => s + (c.total_stamps || 0), 0) / customers.length) : 0, of: null, color: "#3B82F6" },
              ].map((m, i) => (
                <Card key={i} style={{ padding: "18px 20px" }}>
                  <div style={{ fontSize: 10, fontWeight: 700, color: "#9ca3af", letterSpacing: 0.5, textTransform: "uppercase", marginBottom: 8 }}>{m.label}</div>
                  <div style={{ fontSize: 28, fontWeight: 900, color: m.color }}>{m.value}</div>
                  {m.of != null && <div style={{ fontSize: 11, color: "#9ca3af", marginTop: 3 }}>von {m.of} gesamt</div>}
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* ── BUSINESSES ── */}
        {activeTab === "businesses" && (
          <Card>
            <div style={{ overflowX: "auto" }}>
              <table style={{ width: "100%", borderCollapse: "collapse" }}>
                <thead>
                  <tr style={{ borderBottom: "1px solid #f3f4f6" }}>
                    {["Name", "Email", "Min. Betrag", "Stempel erforderlich", "Status", "Aktion"].map(h => (
                     <th key={h} style={{ padding: "10px 14px", textAlign: "left", fontSize: 11, fontWeight: 700, color: "#9ca3af", textTransform: "uppercase", letterSpacing: 0.5 }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {businesses.map(biz => (
                    <tr key={biz.id} style={{ borderBottom: "1px solid #f9fafb" }}
                      onMouseEnter={e => e.currentTarget.style.background = "#f9fafb"}
                      onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
                      <td style={{ padding: "12px 14px", fontSize: 13, color: "#111827", fontWeight: 600 }}>{biz.name}</td>
                      <td style={{ padding: "12px 14px", fontSize: 13, color: "#6b7280" }}>{biz.email}</td>
                      <td style={{ padding: "12px 14px", fontSize: 13, color: "#6b7280" }}>{biz.min_purchase_amount}€</td>
                      <td style={{ padding: "12px 14px", fontSize: 13, color: "#6b7280" }}>{biz.stamps_required}</td>
                      <td style={{ padding: "12px 14px" }}>
                       <span style={{ background: biz.is_locked ? "#fee2e2" : "#D1FAE5", color: biz.is_locked ? "#dc2626" : "#065f46", padding: "4px 10px", borderRadius: 6, fontSize: 11, fontWeight: 700 }}>
                         {biz.is_locked ? "Gesperrt" : "Aktiv"}
                       </span>
                      </td>
                      <td style={{ padding: "12px 14px" }}>
                       <button onClick={() => toggleBusinessLock(biz)}
                         style={{ background: biz.is_locked ? "#10B981" : "#fee2e2", color: biz.is_locked ? "#fff" : "#dc2626", border: "none", borderRadius: 8, padding: "6px 12px", fontSize: 11, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" }}>
                         {biz.is_locked ? "Entsperren" : "Sperren"}
                       </button>
                      </td>
                      </tr>
                  ))}
                  {!businesses.length && <tr><td colSpan={5} style={{ padding: 32, textAlign: "center", color: "#9ca3af", fontSize: 13 }}>Keine Unternehmen vorhanden</td></tr>}
                </tbody>
              </table>
            </div>
          </Card>
        )}

        {/* ── CUSTOMERS ── */}
        {activeTab === "customers" && (
          <Card>
            <div style={{ overflowX: "auto" }}>
              <table style={{ width: "100%", borderCollapse: "collapse" }}>
                <thead>
                  <tr style={{ borderBottom: "1px solid #f3f4f6" }}>
                    {["Name", "Telefon", "Referral-Code", "Stempel", "Besuche", "Verdient", "Erhalten"].map(h => (
                      <th key={h} style={{ padding: "10px 14px", textAlign: "left", fontSize: 11, fontWeight: 700, color: "#9ca3af", textTransform: "uppercase", letterSpacing: 0.5 }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {[...customers].sort((a, b) => (b.total_stamps || 0) - (a.total_stamps || 0)).map(c => (
                    <tr key={c.id} style={{ borderBottom: "1px solid #f9fafb" }}
                      onMouseEnter={e => e.currentTarget.style.background = "#f9fafb"}
                      onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
                      <td style={{ padding: "12px 14px", fontSize: 13, color: "#111827", fontWeight: 600 }}>{c.name}</td>
                      <td style={{ padding: "12px 14px", fontSize: 13, color: "#6b7280" }}>{c.phone}</td>
                      <td style={{ padding: "12px 14px", fontSize: 12, color: "#10B981", fontFamily: "monospace", fontWeight: 700 }}>{c.referral_code || "—"}</td>
                      <td style={{ padding: "12px 14px", fontSize: 13, color: "#10B981", fontWeight: 700 }}>{c.total_stamps || 0}</td>
                      <td style={{ padding: "12px 14px", fontSize: 13, color: "#6b7280" }}>{c.total_visits || 0}</td>
                      <td style={{ padding: "12px 14px", fontSize: 13, color: "#8B5CF6", fontWeight: 600 }}>{fmt(c.provision_earned)}€</td>
                      <td style={{ padding: "12px 14px", fontSize: 13, color: "#6b7280" }}>{fmt(c.provision_paid)}€</td>
                    </tr>
                  ))}
                  {!customers.length && <tr><td colSpan={7} style={{ padding: 32, textAlign: "center", color: "#9ca3af", fontSize: 13 }}>Keine Kunden vorhanden</td></tr>}
                </tbody>
              </table>
            </div>
          </Card>
        )}

        {/* ── PAYOUTS ── */}
        {activeTab === "payouts" && (
          <Card>
            <div style={{ overflowX: "auto" }}>
              <table style={{ width: "100%", borderCollapse: "collapse" }}>
                <thead>
                  <tr style={{ borderBottom: "1px solid #f3f4f6" }}>
                    {["Betrag", "Status", "Datum", "Aktion"].map(h => (
                      <th key={h} style={{ padding: "10px 14px", textAlign: "left", fontSize: 11, fontWeight: 700, color: "#9ca3af", textTransform: "uppercase", letterSpacing: 0.5 }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {payouts.map(p => (
                    <tr key={p.id} style={{ borderBottom: "1px solid #f9fafb" }}
                      onMouseEnter={e => e.currentTarget.style.background = "#f9fafb"}
                      onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
                      <td style={{ padding: "12px 14px", fontSize: 14, fontWeight: 800, color: "#10B981" }}>{fmt(p.amount)}€</td>
                      <td style={{ padding: "12px 14px" }}>
                        <span style={{ background: p.status === "offen" ? "#FEF3C7" : "#D1FAE5", color: p.status === "offen" ? "#92400e" : "#065f46", padding: "4px 10px", borderRadius: 6, fontSize: 11, fontWeight: 700 }}>
                          {p.status === "offen" ? "Offen" : "Ausgezahlt"}
                        </span>
                      </td>
                      <td style={{ padding: "12px 14px", fontSize: 13, color: "#6b7280" }}>{fmtDate(p.created_date)}</td>
                      <td style={{ padding: "12px 14px" }}>
                        {p.status === "offen" && (
                          <button onClick={() => updatePayoutStatus(p.id, "ausgezahlt")} disabled={updatingPayout === p.id}
                            style={{ background: "#10B981", color: "#fff", border: "none", borderRadius: 8, padding: "7px 14px", fontSize: 12, fontWeight: 700, cursor: "pointer", display: "flex", alignItems: "center", gap: 6, fontFamily: "inherit" }}>
                            {updatingPayout === p.id ? <Loader2 size={12} style={{ animation: "spin 1s linear infinite" }} /> : <Check size={12} />} Auszahlen
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                  {!payouts.length && <tr><td colSpan={4} style={{ padding: 32, textAlign: "center", color: "#9ca3af", fontSize: 13 }}>Keine Provisionen vorhanden</td></tr>}
                </tbody>
              </table>
            </div>
          </Card>
        )}

        {/* ── TRANSACTIONS ── */}
        {activeTab === "transactions" && (
          <Card>
            <div style={{ overflowX: "auto" }}>
              <table style={{ width: "100%", borderCollapse: "collapse" }}>
                <thead>
                  <tr style={{ borderBottom: "1px solid #f3f4f6" }}>
                    {["Betrag", "Bestätigt", "Datum"].map(h => (
                      <th key={h} style={{ padding: "10px 14px", textAlign: "left", fontSize: 11, fontWeight: 700, color: "#9ca3af", textTransform: "uppercase", letterSpacing: 0.5 }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {transactions.map(t => (
                    <tr key={t.id} style={{ borderBottom: "1px solid #f9fafb" }}
                      onMouseEnter={e => e.currentTarget.style.background = "#f9fafb"}
                      onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
                      <td style={{ padding: "12px 14px", fontSize: 14, fontWeight: 700, color: "#10B981" }}>{t.amount}€</td>
                      <td style={{ padding: "12px 14px" }}>
                        <span style={{ background: t.employee_confirmed ? "#D1FAE5" : "#fee2e2", color: t.employee_confirmed ? "#065f46" : "#dc2626", padding: "4px 10px", borderRadius: 6, fontSize: 11, fontWeight: 700 }}>
                          {t.employee_confirmed ? "Bestätigt" : "Ausstehend"}
                        </span>
                      </td>
                      <td style={{ padding: "12px 14px", fontSize: 13, color: "#6b7280" }}>{fmtDate(t.created_date)}</td>
                    </tr>
                  ))}
                  {!transactions.length && <tr><td colSpan={3} style={{ padding: 32, textAlign: "center", color: "#9ca3af", fontSize: 13 }}>Keine Transaktionen vorhanden</td></tr>}
                </tbody>
              </table>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}