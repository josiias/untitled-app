import { useState } from "react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { Link } from "react-router-dom";

const MAIN_CHART_DATA = [
  { tag: "Mo 7. Apr", stempel: 4, kunden: 2, umsatz: 80 },
  { tag: "Di 8. Apr", stempel: 7, kunden: 5, umsatz: 140 },
  { tag: "Mi 9. Apr", stempel: 5, kunden: 3, umsatz: 100 },
  { tag: "Do 10. Apr", stempel: 12, kunden: 9, umsatz: 240 },
  { tag: "Fr 11. Apr", stempel: 18, kunden: 14, umsatz: 360 },
  { tag: "Sa 12. Apr", stempel: 23, kunden: 19, umsatz: 460 },
  { tag: "So 13. Apr", stempel: 9, kunden: 7, umsatz: 180 },
  { tag: "Mo 14. Apr", stempel: 11, kunden: 8, umsatz: 220 },
  { tag: "Di 15. Apr", stempel: 15, kunden: 11, umsatz: 300 },
];

const STAMP_PROGRESS_DATA = [
  { name: "1–2 Stempel", value: 18, color: "#3B82F6" },
  { name: "3–5 Stempel", value: 31, color: "#F59E0B" },
  { name: "6–7 Stempel", value: 12, color: "#EC4899" },
  { name: "Prämie bereit", value: 6, color: "#10B981" },
];

const TOP_KUNDEN = [
  { name: "Mehmet B.", stempel: 34, besuche: 12 },
  { name: "Jonas W.", stempel: 27, besuche: 9 },
  { name: "Sara K.", stempel: 21, besuche: 7 },
  { name: "Fatima A.", stempel: 16, besuche: 5 },
  { name: "Lukas M.", stempel: 11, besuche: 4 },
];

const RANG_FARBEN = ["#F59E0B", "#94A3B8", "#CD7F32", "#10B981", "#3B82F6"];

const ChartTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background: "#111e28", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 10, padding: "10px 14px", fontSize: 12 }}>
      <div style={{ color: "rgba(255,255,255,0.5)", marginBottom: 6 }}>{label}</div>
      {payload.map((p, i) => (
        <div key={i} style={{ color: p.color, fontWeight: 700 }}>{p.name}: {p.value}{p.name === "Umsatz" ? "€" : ""}</div>
      ))}
    </div>
  );
};

export default function BusinessAnalytics() {
  const [activeMetric, setActiveMetric] = useState("stempel");

  const metricConfig = {
    stempel: { label: "Stempel", color: "#10B981", name: "Stempel" },
    kunden: { label: "Kunden", color: "#F59E0B", name: "Kunden" },
    umsatz: { label: "Umsatz", color: "#3B82F6", name: "Umsatz" },
  };
  const m = metricConfig[activeMetric];

  const totalStempel = MAIN_CHART_DATA.reduce((s, d) => s + d.stempel, 0);
  const totalKunden = MAIN_CHART_DATA.reduce((s, d) => s + d.kunden, 0);
  const totalUmsatz = MAIN_CHART_DATA.reduce((s, d) => s + d.umsatz, 0);

  return (
    <div style={{ background: "#0a0f16", minHeight: "100vh", color: "#fff", fontFamily: "'Inter', sans-serif", paddingBottom: 40 }}>
      {/* Header */}
      <div style={{ padding: "16px 20px", display: "flex", alignItems: "center", justifyContent: "space-between", borderBottom: "1px solid rgba(255,255,255,0.06)", background: "rgba(10,15,22,0.95)", backdropFilter: "blur(20px)", position: "sticky", top: 0, zIndex: 10 }}>
        <Link to="/business" style={{ fontSize: 13, color: "#10B981", textDecoration: "none", fontWeight: 600 }}>← Zurück</Link>
        <div>
          <div style={{ fontSize: 15, fontWeight: 700, textAlign: "center" }}>Meine Auswertung</div>
          <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", textAlign: "center" }}>letzte 9 Tage</div>
        </div>
        <span style={{ fontSize: 10, background: "rgba(245,158,11,0.15)", color: "#F59E0B", padding: "4px 8px", borderRadius: 8, fontWeight: 700 }}>Demo</span>
      </div>

      <div style={{ padding: "20px" }}>
        {/* Metric Switcher */}
        <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 20, padding: 16, marginBottom: 20 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: "rgba(255,255,255,0.6)", marginBottom: 12 }}>Was ist letzte Woche passiert?</div>
          <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
            {Object.entries(metricConfig).map(([key, cfg]) => (
              <button key={key} onClick={() => setActiveMetric(key)} style={{ padding: "8px 14px", borderRadius: 10, border: "none", cursor: "pointer", fontFamily: "inherit", fontSize: 12, fontWeight: 700, background: activeMetric === key ? cfg.color : "rgba(255,255,255,0.06)", color: activeMetric === key ? "#fff" : "rgba(255,255,255,0.4)", transition: "all 0.2s" }}>
                {cfg.label}
              </button>
            ))}
          </div>

          {/* Quick stats */}
          <div style={{ display: "flex", gap: 12, marginBottom: 16 }}>
            {[
              { label: "Stempel vergeben", value: totalStempel, color: "#10B981", key: "stempel" },
              { label: "Scan-Kunden", value: totalKunden, color: "#F59E0B", key: "kunden" },
              { label: "Mindestumsatz", value: `${totalUmsatz}€`, color: "#3B82F6", key: "umsatz" },
            ].map(s => (
              <div key={s.key} onClick={() => setActiveMetric(s.key)} style={{ flex: 1, cursor: "pointer", borderLeft: `3px solid ${activeMetric === s.key ? s.color : "rgba(255,255,255,0.08)"}`, paddingLeft: 10, transition: "all 0.2s" }}>
                <div style={{ fontSize: 18, fontWeight: 800, color: s.color }}>{s.value}</div>
                <div style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", marginTop: 2 }}>{s.label}</div>
              </div>
            ))}
          </div>

          <ResponsiveContainer width="100%" height={160}>
            <AreaChart data={MAIN_CHART_DATA}>
              <defs>
                <linearGradient id="colorGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={m.color} stopOpacity={0.3} />
                  <stop offset="95%" stopColor={m.color} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="tag" tick={{ fontSize: 9, fill: "rgba(255,255,255,0.3)" }} tickLine={false} />
              <YAxis tick={{ fontSize: 9, fill: "rgba(255,255,255,0.3)" }} tickLine={false} axisLine={false} />
              <Tooltip content={<ChartTooltip />} />
              <Area type="monotone" dataKey={activeMetric} name={m.name} stroke={m.color} strokeWidth={2} fill="url(#colorGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Treue-Verteilung */}
        <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 20, padding: 16, marginBottom: 20 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: "rgba(255,255,255,0.6)", marginBottom: 14 }}>Wie treu sind meine Kunden?</div>
          <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
            <PieChart width={120} height={120}>
              <Pie data={STAMP_PROGRESS_DATA} cx={55} cy={55} innerRadius={35} outerRadius={55} paddingAngle={3} dataKey="value">
                {STAMP_PROGRESS_DATA.map((e, i) => <Cell key={i} fill={e.color} />)}
              </Pie>
            </PieChart>
            <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 8 }}>
              {STAMP_PROGRESS_DATA.map((d, i) => (
                <div key={i} style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                    <div style={{ width: 8, height: 8, borderRadius: "50%", background: d.color, flexShrink: 0 }} />
                    <span style={{ fontSize: 11, color: "rgba(255,255,255,0.5)" }}>{d.name}</span>
                  </div>
                  <span style={{ fontSize: 12, fontWeight: 700, color: d.color }}>{d.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Empfehlungen + Prämien */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 20 }}>
          <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 16, padding: 16 }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: "rgba(255,255,255,0.5)", marginBottom: 12 }}>Empfehlungen</div>
            <div style={{ fontSize: 28, fontWeight: 800, color: "#10B981" }}>31</div>
            <div style={{ fontSize: 10, color: "rgba(255,255,255,0.35)", marginTop: 2 }}>gesamt</div>
            <div style={{ marginTop: 12, display: "flex", gap: 8 }}>
              <div style={{ flex: 1, background: "rgba(245,158,11,0.1)", borderRadius: 8, padding: "8px 10px", textAlign: "center" }}>
                <div style={{ fontSize: 14, fontWeight: 800, color: "#F59E0B" }}>87€</div>
                <div style={{ fontSize: 9, color: "rgba(255,255,255,0.35)", marginTop: 2 }}>offen</div>
              </div>
              <div style={{ flex: 1, background: "rgba(16,185,129,0.1)", borderRadius: 8, padding: "8px 10px", textAlign: "center" }}>
                <div style={{ fontSize: 14, fontWeight: 800, color: "#10B981" }}>42€</div>
                <div style={{ fontSize: 9, color: "rgba(255,255,255,0.35)", marginTop: 2 }}>ausgezahlt</div>
              </div>
            </div>
          </div>
          <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 16, padding: 16 }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: "rgba(255,255,255,0.5)", marginBottom: 12 }}>Prämien</div>
            <div style={{ fontSize: 28, fontWeight: 800, color: "#EC4899" }}>6</div>
            <div style={{ fontSize: 10, color: "rgba(255,255,255,0.35)", marginTop: 2 }}>diese Woche eingelöst</div>
          </div>
        </div>

        {/* Top Kunden */}
        <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 20, padding: 16 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: "rgba(255,255,255,0.6)", marginBottom: 14 }}>🏆 Treueste Kunden</div>
          {TOP_KUNDEN.map((c, i) => {
            const pct = Math.round((c.stempel / TOP_KUNDEN[0].stempel) * 100);
            return (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 0", borderBottom: i < TOP_KUNDEN.length - 1 ? "1px solid rgba(255,255,255,0.05)" : "none" }}>
                <div style={{ width: 28, height: 28, borderRadius: 8, background: `${RANG_FARBEN[i]}20`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 800, color: RANG_FARBEN[i], flexShrink: 0 }}>{i + 1}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                    <span style={{ fontSize: 13, color: "#fff", fontWeight: 600 }}>{c.name}</span>
                    <span style={{ fontSize: 12, color: RANG_FARBEN[i], fontWeight: 700 }}>{c.stempel} Stempel</span>
                  </div>
                  <div style={{ height: 4, background: "rgba(255,255,255,0.06)", borderRadius: 100 }}>
                    <div style={{ height: "100%", width: `${pct}%`, background: RANG_FARBEN[i], borderRadius: 100 }} />
                  </div>
                  <div style={{ fontSize: 10, color: "rgba(255,255,255,0.3)", marginTop: 3 }}>{c.besuche} Besuche</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}