import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";

const STATUS_OPTIONS = ["Neu", "Kontaktiert", "Onboarded"];

const STATUS_STYLES = {
  Neu: { background: "rgba(0,184,148,0.12)", color: "#00b894", border: "1px solid rgba(0,184,148,0.3)" },
  Kontaktiert: { background: "rgba(255,193,7,0.12)", color: "#ffc107", border: "1px solid rgba(255,193,7,0.3)" },
  Onboarded: { background: "rgba(99,102,241,0.12)", color: "#818cf8", border: "1px solid rgba(99,102,241,0.3)" },
};

export default function Admin() {
  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);
  const [updating, setUpdating] = useState(null);

  useEffect(() => {
    base44.auth.me().then((u) => {
      setUser(u);
      if (u) loadEntries();
      else setLoading(false);
    }).catch(() => {
      base44.auth.redirectToLogin(window.location.href);
    });
  }, []);

  const loadEntries = async () => {
    const data = await base44.entities.WaitlistEntry.list("-created_date", 100);
    setEntries(data);
    setLoading(false);
  };

  const handleStatusChange = async (id, newStatus) => {
    setUpdating(id);
    await base44.entities.WaitlistEntry.update(id, { status: newStatus });
    setEntries((prev) => prev.map((e) => e.id === id ? { ...e, status: newStatus } : e));
    setUpdating(null);
  };

  if (loading) {
    return (
      <div style={{ minHeight: "100vh", background: "#080e0c", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ width: 32, height: 32, border: "3px solid rgba(0,184,148,0.2)", borderTop: "3px solid #00b894", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );
  }

  if (!user) {
    base44.auth.redirectToLogin(window.location.href);
    return null;
  }

  return (
    <div style={{ minHeight: "100vh", background: "#080e0c", padding: "0 0 60px" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@700;800&display=swap');
        .admin-table { width: 100%; border-collapse: collapse; }
        .admin-table th { color: rgba(255,255,255,0.35); font-size: 11px; font-weight: 600; letter-spacing: 1.5px; text-transform: uppercase; padding: 12px 16px; text-align: left; border-bottom: 1px solid rgba(255,255,255,0.06); }
        .admin-table td { padding: 14px 16px; border-bottom: 1px solid rgba(255,255,255,0.04); color: rgba(255,255,255,0.85); font-size: 14px; vertical-align: middle; }
        .admin-table tr:hover td { background: rgba(255,255,255,0.02); }
        .status-select { border-radius: 100px; padding: 5px 12px; font-size: 12px; font-weight: 600; cursor: pointer; outline: none; appearance: none; font-family: inherit; }
        @media(max-width:640px) {
          .col-industry, .col-email { display: none; }
          .admin-table td, .admin-table th { padding: 10px 12px; }
        }
      `}</style>

      {/* Header */}
      <div style={{ background: "rgba(8,14,12,0.95)", borderBottom: "1px solid rgba(0,184,148,0.12)", padding: "0 24px", position: "sticky", top: 0, zIndex: 10 }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", height: 64, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
            <a href="/" style={{ textDecoration: "none" }}>
              <span style={{ fontFamily: "'Bricolage Grotesque', sans-serif", fontSize: 20, fontWeight: 700, color: "#fff" }}>
                Sensalie<span style={{ color: "#00b894" }}>.</span>
              </span>
            </a>
            <span style={{ color: "rgba(255,255,255,0.2)", fontSize: 16 }}>/</span>
            <span style={{ color: "rgba(255,255,255,0.5)", fontSize: 14, fontWeight: 500 }}>Admin</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <span style={{ color: "rgba(255,255,255,0.4)", fontSize: 13 }}>{user.email}</span>
            <button onClick={() => base44.auth.logout("/")} style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, padding: "6px 14px", color: "rgba(255,255,255,0.5)", fontSize: 13, cursor: "pointer", fontFamily: "inherit" }}>
              Logout
            </button>
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "40px 24px 0" }}>
        {/* Stats */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12, marginBottom: 32 }}>
          {[
            { label: "Gesamt", value: entries.length, color: "#fff" },
            { label: "Kontaktiert", value: entries.filter(e => e.status === "Kontaktiert").length, color: "#ffc107" },
            { label: "Onboarded", value: entries.filter(e => e.status === "Onboarded").length, color: "#818cf8" },
          ].map((s) => (
            <div key={s.label} style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 14, padding: "18px 20px" }}>
              <div style={{ color: "rgba(255,255,255,0.35)", fontSize: 11, fontWeight: 600, letterSpacing: 1.5, textTransform: "uppercase", marginBottom: 6 }}>{s.label}</div>
              <div style={{ fontFamily: "'Bricolage Grotesque', sans-serif", fontSize: 28, fontWeight: 700, color: s.color }}>{s.value}</div>
            </div>
          ))}
        </div>

        {/* Table */}
        <div style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 16, overflow: "hidden" }}>
          <div style={{ padding: "16px 20px", borderBottom: "1px solid rgba(255,255,255,0.06)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <span style={{ color: "#fff", fontWeight: 600, fontSize: 15 }}>Waitlist Einträge</span>
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <div style={{ width: 6, height: 6, borderRadius: "50%", background: "#00b894", boxShadow: "0 0 8px #00b894" }} />
              <span style={{ color: "#00b894", fontSize: 12, fontWeight: 600 }}>Live</span>
            </div>
          </div>
          <div style={{ overflowX: "auto" }}>
            <table className="admin-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Unternehmen</th>
                  <th className="col-email">E-Mail</th>
                  <th className="col-industry">Branche</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {entries.length === 0 ? (
                  <tr>
                    <td colSpan={5} style={{ textAlign: "center", color: "rgba(255,255,255,0.2)", padding: "40px" }}>
                      Noch keine Einträge
                    </td>
                  </tr>
                ) : entries.map((entry) => (
                  <tr key={entry.id}>
                    <td style={{ fontWeight: 500 }}>{entry.contact_name || "—"}</td>
                    <td>{entry.business_name}</td>
                    <td className="col-email" style={{ color: "rgba(255,255,255,0.5)" }}>{entry.email}</td>
                    <td className="col-industry" style={{ color: "rgba(255,255,255,0.5)" }}>{entry.industry || "—"}</td>
                    <td>
                      <select
                        className="status-select"
                        value={entry.status || "Neu"}
                        disabled={updating === entry.id}
                        onChange={(e) => handleStatusChange(entry.id, e.target.value)}
                        style={{
                          ...STATUS_STYLES[entry.status || "Neu"],
                          opacity: updating === entry.id ? 0.5 : 1,
                        }}
                      >
                        {STATUS_OPTIONS.map((s) => (
                          <option key={s} value={s} style={{ background: "#0f1f16", color: "#fff" }}>{s}</option>
                        ))}
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}