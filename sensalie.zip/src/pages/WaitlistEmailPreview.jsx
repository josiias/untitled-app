import React, { useState } from "react";
import { ChevronLeft, Smartphone, Monitor } from "lucide-react";

export default function WaitlistEmailPreview() {
  const [view, setView] = useState("both");

  const mockData = {
    email: "anna@cafeamilano.de",
    businessName: "Café Milano",
    contactName: "Anna Rossi"
  };

  const emailHTML = `
<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue', sans-serif; line-height: 1.6; color: #374151; background: #f3f4f6; }
    .container { max-width: 600px; margin: 0 auto; background: #ffffff; }
    .header { background: linear-gradient(135deg, rgba(16,185,129,0.08), rgba(16,185,129,0.02)); padding: 40px 24px; text-align: center; border-bottom: 1px solid rgba(16,185,129,0.1); }
    .logo { font-size: 28px; font-weight: 800; color: #000; margin-bottom: 8px; letter-spacing: -0.5px; }
    .logo span { color: #10B981; }
    .content { padding: 40px 24px; }
    .headline { font-size: 24px; font-weight: 700; color: #1f2937; margin: 0 0 24px; }
    .text { color: #6b7280; font-size: 15px; line-height: 1.6; margin: 16px 0; }
    .steps { background: rgba(16,185,129,0.05); border-left: 4px solid #10B981; padding: 20px; border-radius: 8px; margin: 24px 0; }
    .step { margin: 12px 0; color: #374151; font-size: 14px; }
    .step strong { color: #1f2937; }
    .footer { background: #f9fafb; border-top: 1px solid #e5e7eb; padding: 24px; text-align: center; color: #6b7280; font-size: 12px; }
    .footer a { color: #10B981; text-decoration: none; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="logo">Sensalie<span>.</span></div>
    </div>

    <div class="content">
      <div class="headline">🎉 Du bist auf der Warteliste!</div>
      
      <div class="text">Hallo <strong>${mockData.contactName}</strong>,</div>
      
      <div class="text">vielen Dank für deine Registrierung! <strong>${mockData.businessName}</strong> ist jetzt auf der Sensalie Early-Access Warteliste und du gehörst zu den ersten 50 Unternehmern, die unser System nutzen können.</div>
      
      <div class="text">Du erhältst sehr bald eine E-Mail mit deinem Zugang und einer detaillierten Anleitung zum Start.</div>
      
      <div class="steps">
        <strong style="color: #1f2937;"><strong>${mockData.businessName}</strong></strong>
        <div class="step">Mindestbetrag pro Kauf für einen Stempel</div>
        <div class="step">Stempel erforderlich für Prämienerreichung</div>
      </div>
      
      <div class="text">Fragen? Schreib uns einfach eine Nachricht — wir helfen dir gerne weiter.</div>
      
      <div class="text">Bis bald!<br><strong>Das Sensalie Team</strong></div>
    </div>

    <div class="footer">
      <p>© 2026 Sensalie. Alle Rechte vorbehalten.</p>
    </div>
  </div>
</body>
</html>
  `;

  return (
    <div style={{ minHeight: "100vh", background: "#f3f4f6", fontFamily: "inherit" }}>
      {/* Header */}
      <div style={{
        background: "#fff",
        borderBottom: "1px solid #e5e7eb",
        padding: "16px 24px",
        position: "sticky",
        top: 0,
        zIndex: 10,
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between"
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <a href="/" style={{ cursor: "pointer", display: "flex", alignItems: "center", gap: 8, textDecoration: "none", color: "#10B981" }}>
            <ChevronLeft size={20} />
            <span style={{ fontSize: 14, fontWeight: 600 }}>Zurück</span>
          </a>
        </div>
        <h1 style={{ fontSize: 18, fontWeight: 700, color: "#1f2937", margin: 0 }}>E-Mail Vorschau</h1>
        <div style={{ width: 80 }} />
      </div>

      {/* View Selector */}
      <div style={{ background: "#fff", borderBottom: "1px solid #e5e7eb", padding: "12px 24px" }}>
        <div style={{ display: "flex", gap: 8 }}>
          <button
            onClick={() => setView("desktop")}
            style={{
              padding: "8px 16px",
              borderRadius: 6,
              border: "none",
              background: view === "desktop" ? "#10B981" : "#f3f4f6",
              color: view === "desktop" ? "#fff" : "#6b7280",
              cursor: "pointer",
              fontWeight: 600,
              fontSize: 13,
              display: "flex",
              alignItems: "center",
              gap: 6,
              transition: "all 0.2s"
            }}>
            <Monitor size={16} />
            Desktop
          </button>
          <button
            onClick={() => setView("mobile")}
            style={{
              padding: "8px 16px",
              borderRadius: 6,
              border: "none",
              background: view === "mobile" ? "#10B981" : "#f3f4f6",
              color: view === "mobile" ? "#fff" : "#6b7280",
              cursor: "pointer",
              fontWeight: 600,
              fontSize: 13,
              display: "flex",
              alignItems: "center",
              gap: 6,
              transition: "all 0.2s"
            }}>
            <Smartphone size={16} />
            Mobil
          </button>
          <button
            onClick={() => setView("both")}
            style={{
              padding: "8px 16px",
              borderRadius: 6,
              border: "none",
              background: view === "both" ? "#10B981" : "#f3f4f6",
              color: view === "both" ? "#fff" : "#6b7280",
              cursor: "pointer",
              fontWeight: 600,
              fontSize: 13,
              transition: "all 0.2s"
            }}>
            Beide
          </button>
        </div>
      </div>

      {/* Preview Content */}
      <div style={{ padding: "32px 24px" }}>
        <div style={{
          display: view === "both" ? "grid" : "flex",
          gridTemplateColumns: view === "both" ? "1fr 1fr" : undefined,
          gap: 32,
          justifyContent: view === "desktop" || view === "mobile" ? "center" : undefined
        }}>
          {/* Desktop Preview */}
          {(view === "desktop" || view === "both") && (
            <div>
              <div style={{
                fontSize: 13,
                fontWeight: 600,
                color: "#6b7280",
                marginBottom: 12,
                textAlign: view === "both" ? "left" : "center"
              }}>
                💻 Desktop View (600px)
              </div>
              <div style={{
                background: "#e5e7eb",
                borderRadius: 12,
                padding: "16px",
                boxShadow: "0 10px 40px rgba(0,0,0,0.1)",
                maxWidth: 640
              }}>
                <iframe
                  srcDoc={emailHTML}
                  style={{
                    width: "100%",
                    border: "none",
                    borderRadius: 8,
                    minHeight: "900px",
                    display: "block",
                    background: "#fff"
                  }}
                  title="Email Desktop Preview"
                />
              </div>
            </div>
          )}

          {/* Mobile Preview */}
          {(view === "mobile" || view === "both") && (
            <div>
              <div style={{
                fontSize: 13,
                fontWeight: 600,
                color: "#6b7280",
                marginBottom: 12,
                textAlign: view === "both" ? "left" : "center"
              }}>
                📱 Mobile View (375px)
              </div>
              <div style={{
                background: "#e5e7eb",
                borderRadius: 12,
                padding: "12px",
                boxShadow: "0 10px 40px rgba(0,0,0,0.1)",
                maxWidth: 399,
                margin: "0 auto"
              }}>
                {/* iPhone Frame */}
                <div style={{
                  background: "#000",
                  borderRadius: 40,
                  padding: "12px",
                  border: "8px solid #000",
                  boxShadow: "inset 0 0 0 1px #333"
                }}>
                  <div style={{
                    background: "#e5e7eb",
                    borderRadius: 32,
                    overflow: "hidden",
                    position: "relative"
                  }}>
                    {/* Notch */}
                    <div style={{
                      position: "absolute",
                      top: 0,
                      left: "50%",
                      transform: "translateX(-50%)",
                      width: 150,
                      height: 28,
                      background: "#000",
                      borderRadius: "0 0 30px 30px",
                      zIndex: 10
                    }} />
                    <iframe
                      srcDoc={emailHTML}
                      style={{
                        width: "100%",
                        border: "none",
                        minHeight: "900px",
                        display: "block",
                        background: "#fff"
                      }}
                      title="Email Mobile Preview"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Info Box */}
        <div style={{
          background: "#f0fdf4",
          border: "1px solid #86efac",
          borderRadius: 8,
          padding: "16px",
          marginTop: 32,
          maxWidth: 800,
          margin: "32px auto 0"
        }}>
          <p style={{ color: "#166534", fontSize: 13, lineHeight: 1.6, margin: 0 }}>
            <strong>ℹ️ Beispieldaten:</strong> Diese Vorschau verwendet Beispieldaten (Café Milano, Anna Rossi). Die echte E-Mail wird mit den tatsächlichen Daten des Unternehmers versendet. Testen Sie gerne mit Test-E-Mail-Adressen.
          </p>
        </div>
      </div>
    </div>
  );
}