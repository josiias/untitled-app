import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import Landing from './pages/Landing';
import RoleSelect from './pages/RoleSelect';
import Waitlist from './pages/Waitlist';
import Admin from './pages/Admin';
import Business from './pages/Business';
import ScanStamp from './pages/ScanStamp';
import AdminDashboard from './pages/AdminDashboard';
import EmailPreview from './pages/EmailPreview';
import WaitlistEmailPreview from './pages/WaitlistEmailPreview';
import CustomerDashboard from './pages/CustomerDashboard';
import CustomerLanding from './pages/CustomerLanding';
import BusinessAnalytics from './pages/BusinessAnalytics';
import ScanLanding from './pages/ScanLanding';
// Add page imports here

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route path="/" element={<RoleSelect />} />
      <Route path="/for-business" element={<Landing />} />
      <Route path="/waitlist" element={<Waitlist />} />
      <Route path="/admin" element={<Admin />} />
      <Route path="/business" element={<Business />} />
      <Route path="/scan/:businessId" element={<ScanStamp />} />
      <Route path="/admin-dashboard" element={<AdminDashboard />} />
      <Route path="/email-preview" element={<EmailPreview />} />
      <Route path="/waitlist-email-preview" element={<WaitlistEmailPreview />} />
      <Route path="/customer-dashboard" element={<CustomerDashboard />} />
      <Route path="/customer" element={<CustomerLanding />} />
      <Route path="/analytics" element={<BusinessAnalytics />} />
      <Route path="/scan-landing/:businessId" element={<ScanLanding />} />
      {/* Add your page Route elements here */}
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App