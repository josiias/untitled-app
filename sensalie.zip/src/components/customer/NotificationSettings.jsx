import { useState, useEffect } from "react";

const STORAGE_KEY = "sensalie_notification_prefs";
const DEFAULT_PREFS = { enabled: false, stampProgress: true, rewardExpiry: true };

function Toggle({ checked, onChange }) {
  return (
    <div onClick={() => onChange(!checked)} style={{ width: 44, height: 24, borderRadius: 100, background: checked ? "#10B981" : "rgba(255,255,255,0.12)", position: "relative", cursor: "pointer", transition: "background 0.25s", flexShrink: 0 }}>
      <div style={{ position: "absolute", top: 2, left: checked ? 22 : 2, width: 20, height: 20, borderRadius: "50%", background: "#fff", transition: "left 0.25s", boxShadow: "0 1px 4px rgba(0,0,0,0.3)" }} />
    </div>
  );
}

export default function NotificationSettings({ onClose }) {
  const [prefs, setPrefs] = useState(DEFAULT_PREFS);
  const [permission, setPermission] = useState("default");
  const [requesting, setRequesting] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    try { const stored = localStorage.getItem(STORAGE_KEY); if (stored) setPrefs(JSON.parse(stored)); } catch (e) {}
    if ("Notification" in window) setPermission(Notification.permission);
  }, []);

  const requestPermission = async () => {
    if (!("Notification" in window)) return;
    setRequesting(true);
    const result = await Notification.requestPermission();
    setPermission(result);
    setRequesting(false);
    if (result === "granted") {
      updatePref("enabled", true);
      new Notification("Sensalie 💚", { body: "Benachrichtigungen sind jetzt aktiv!" });
    }
  };

  const updatePref = (key, value) => {
    setPrefs(prev => { const next = { ...prev, [key]: value }; localStorage.setItem(STORAGE_KEY, JSON.stringify(next)); return next; });
  };

  const handleSave = () => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(prefs));
    setSaved(true);
    setTimeout(() => { setSaved(false); onClose && onClose(); }, 1200);
  };

  const notSupported = !("Notification" in window);

  return (
    <div style={{ background: "#111e28", borderRadius: 20, padding: 24, color: "#fff", fontFamily: "inherit" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
        <div>
          <div style={{ fontSize: 16, fontWeight: 700 }}>🔔 Benachrichtigungen</div>
          <div style={{ fontSize: 12, color: "rgba(255,255,255,0.4)", marginTop: 2 }}>Bleib immer auf dem Laufenden</div>
        </div>
        {onClose && <button onClick={onClose} style={{ background: "none", border: "none", color: "rgba(255,255,255,0.4)", fontSize: 18, cursor: "pointer" }}>✕</button>}
      </div>

      {notSupported ? (
        <div style={{ background: "rgba(245,158,11,0.1)", border: "1px solid rgba(245,158,11,0.3)", borderRadius: 12, padding: 14, fontSize: 13, color: "#F59E0B", marginBottom: 16 }}>
          ⚠️ Dein Browser unterstützt keine Push-Benachrichtigungen.
        </div>
      ) : permission === "denied" ? (
        <div style={{ background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.3)", borderRadius: 12, padding: 14, fontSize: 13, color: "#ef4444", marginBottom: 16 }}>
          🚫 Du hast Benachrichtigungen blockiert. Bitte erlaube sie in deinen Browser-Einstellungen.
        </div>
      ) : permission !== "granted" ? (
        <div style={{ background: "rgba(16,185,129,0.08)", border: "1px solid rgba(16,185,129,0.2)", borderRadius: 12, padding: 16, marginBottom: 16 }}>
          <div style={{ fontSize: 13, color: "rgba(255,255,255,0.7)", marginBottom: 12 }}>Tippe auf „Erlauben", damit Sensalie dich benachrichtigen kann.</div>
          <button onClick={requestPermission} disabled={requesting} style={{ width: "100%", padding: "10px", background: "#10B981", color: "#fff", fontWeight: 700, fontSize: 13, borderRadius: 10, border: "none", cursor: "pointer", fontFamily: "inherit" }}>
            {requesting ? "Warte auf Erlaubnis…" : "🔔 Benachrichtigungen erlauben"}
          </button>
        </div>
      ) : (
        <div style={{ background: "rgba(16,185,129,0.1)", borderRadius: 10, padding: "8px 12px", fontSize: 12, color: "#10B981", marginBottom: 16 }}>Benachrichtigungen sind erlaubt ✓</div>
      )}

      {[
        { key: "enabled", label: "Alle Benachrichtigungen", desc: "Master-Schalter" },
        { key: "stampProgress", label: "⬛ Stempelkarte fast voll", desc: "Bei 80% der Stempel" },
        { key: "rewardExpiry", label: "🎁 Gutschein läuft bald ab", desc: "7 Tage vor Ablauf" },
      ].map(item => (
        <div key={item.key} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "14px 0", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
          <div>
            <div style={{ fontSize: 13, fontWeight: 600, color: "#fff" }}>{item.label}</div>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", marginTop: 2 }}>{item.desc}</div>
          </div>
          <Toggle checked={prefs[item.key]} onChange={v => {
            if (item.key === "enabled" && v && permission !== "granted") { requestPermission(); }
            else { updatePref(item.key, v); }
          }} />
        </div>
      ))}

      <button onClick={handleSave} style={{ width: "100%", marginTop: 20, padding: "12px", background: saved ? "rgba(16,185,129,0.2)" : "#10B981", color: "#fff", fontWeight: 700, fontSize: 13, borderRadius: 12, border: "none", cursor: "pointer", fontFamily: "inherit", transition: "background 0.3s" }}>
        {saved ? "✓ Gespeichert!" : "Einstellungen speichern"}
      </button>
    </div>
  );
}

export function useNotificationChecker(stampCards, rewards) {
  useEffect(() => {
    if (!("Notification" in window) || Notification.permission !== "granted") return;
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      const prefs = stored ? JSON.parse(stored) : DEFAULT_PREFS;
      if (!prefs.enabled) return;
      if (prefs.stampProgress) {
        stampCards.forEach(card => {
          const pct = card.stamps / card.required;
          if (pct >= 0.8 && pct < 1) {
            const remaining = card.required - card.stamps;
            const key = `notif_stamp_${card.id}_${card.stamps}`;
            if (!sessionStorage.getItem(key)) {
              sessionStorage.setItem(key, "1");
              setTimeout(() => new Notification("Sensalie 🔥", { body: `Noch ${remaining} Stempel bei ${card.name}!` }), 2000);
            }
          }
        });
      }
    } catch (e) {}
  }, []);
}