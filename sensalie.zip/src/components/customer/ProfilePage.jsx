import { useState } from "react";

const STATS = [
  { label: "Stempel gesamt", value: 16, emoji: "⬛", color: "#10B981" },
  { label: "Prämien eingelöst", value: 2, emoji: "🎁", color: "#F59E0B" },
  { label: "Provision verdient", value: "42,50€", emoji: "💸", color: "#EC4899" },
  { label: "Empfehlungen", value: 3, emoji: "👥", color: "#8B5CF6" },
];

const HISTORY = [
  { emoji: "✂️", business: "Kings Barbershop", type: "stempel", detail: "+1 Stempel", date: "Heute, 14:32", color: "#10B981" },
  { emoji: "💅", business: "Bella Nails", type: "stempel", detail: "+1 Stempel", date: "Gestern, 11:05", color: "#EC4899" },
  { emoji: "💸", business: "Empfehlung · Jonas W.", type: "provision", detail: "+12,50€", date: "02.04.2026", color: "#F59E0B" },
  { emoji: "✂️", business: "Kings Barbershop", type: "praemie", detail: "10€ Gutschein eingelöst 🎉", date: "28.03.2026", color: "#10B981" },
];

const PREFERENCES = [
  { id: "notifications_stamps", label: "Stempel-Erinnerungen", desc: "Benachrichtigung wenn du fast fertig bist", default: true },
  { id: "notifications_rewards", label: "Prämien-Ablauf", desc: "Erinnere mich vor dem Ablaufdatum", default: true },
  { id: "notifications_offers", label: "Aktionen & Angebote", desc: "Neue Aktionen von Partnerbetrieben", default: false },
];

export default function ProfilePage({ onClose, user }) {
  const userName = user?.full_name || "Nutzer";
  const userPhone = user?.phone || "";
  const [editMode, setEditMode] = useState(false);
  const [form, setForm] = useState({ name: userName, phone: userPhone, email: user?.email || "", city: "" });
  const [prefs, setPrefs] = useState(() => { const map = {}; PREFERENCES.forEach(p => { map[p.id] = p.default; }); return map; });
  const [saved, setSaved] = useState(false);
  const [historyFilter, setHistoryFilter] = useState("alle");

  const handleSave = () => { setSaved(true); setEditMode(false); setTimeout(() => setSaved(false), 2000); };
  const filtered = historyFilter === "alle" ? HISTORY : HISTORY.filter(h => h.type === historyFilter);
  const initials = userName.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2);

  return (
    <div style={{ background: "#0a0f16", minHeight: "100vh", color: "#fff", fontFamily: "inherit", paddingBottom: 40 }}>
      <div style={{ padding: "16px 20px", display: "flex", alignItems: "center", justifyContent: "space-between", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
        <button onClick={onClose} style={{ background: "none", border: "none", color: "#10B981", fontSize: 14, fontWeight: 600, cursor: "pointer", fontFamily: "inherit", display: "flex", alignItems: "center", gap: 4 }}>← Zurück</button>
        <div style={{ fontSize: 15, fontWeight: 700, color: "#fff" }}>Mein Profil</div>
        <button onClick={editMode ? handleSave : () => setEditMode(true)} style={{ background: editMode ? "#10B981" : "rgba(255,255,255,0.06)", border: editMode ? "none" : "1px solid rgba(255,255,255,0.1)", borderRadius: 10, padding: "8px 14px", fontSize: 12, fontWeight: 700, color: "#fff", cursor: "pointer", fontFamily: "inherit" }}>
          {saved ? "✓ Gespeichert" : editMode ? "Speichern" : "Bearbeiten"}
        </button>
      </div>

      <div style={{ padding: "24px 20px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 24, background: "rgba(255,255,255,0.03)", borderRadius: 16, padding: 16 }}>
          <div style={{ width: 56, height: 56, borderRadius: 18, background: "linear-gradient(135deg, #10B981, #059669)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20, fontWeight: 800, color: "#fff", flexShrink: 0 }}>{initials}</div>
          <div>
            <div style={{ fontSize: 16, fontWeight: 700 }}>{form.name}</div>
            <div style={{ fontSize: 12, color: "rgba(255,255,255,0.4)", marginTop: 2 }}>Aktives Konto</div>
          </div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 10, marginBottom: 24 }}>
          {STATS.map((s, i) => (
            <div key={i} style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 14, padding: "14px 12px", textAlign: "center" }}>
              <div style={{ fontSize: 18 }}>{s.emoji}</div>
              <div style={{ fontSize: 18, fontWeight: 800, color: s.color, marginTop: 4 }}>{s.value}</div>
              <div style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", marginTop: 2 }}>{s.label}</div>
            </div>
          ))}
        </div>

        <div style={{ background: "rgba(255,255,255,0.03)", borderRadius: 16, padding: "16px 18px", marginBottom: 20 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: "rgba(255,255,255,0.6)", marginBottom: 14 }}>Persönliche Daten</div>
          {[{ label: "Name", field: "name", icon: "👤" }, { label: "Telefon", field: "phone", icon: "📱" }, { label: "E-Mail", field: "email", icon: "✉️" }, { label: "Stadt", field: "city", icon: "📍" }].map((item, i, arr) => (
            <div key={item.field} style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 0", borderBottom: i < arr.length - 1 ? "1px solid rgba(255,255,255,0.05)" : "none" }}>
              <span style={{ fontSize: 16 }}>{item.icon}</span>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 10, color: "rgba(255,255,255,0.35)", marginBottom: 2 }}>{item.label}</div>
                {editMode ? (
                  <input value={form[item.field]} onChange={e => setForm(f => ({ ...f, [item.field]: e.target.value }))} style={{ background: "rgba(255,255,255,0.07)", border: "1px solid rgba(16,185,129,0.4)", borderRadius: 8, padding: "6px 10px", fontSize: 13, color: "#fff", fontFamily: "inherit", outline: "none", width: "100%" }} />
                ) : (
                  <div style={{ fontSize: 14, color: "#fff" }}>{form[item.field] || "—"}</div>
                )}
              </div>
            </div>
          ))}
        </div>

        <div style={{ background: "rgba(255,255,255,0.03)", borderRadius: 16, padding: "16px 18px", marginBottom: 20 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: "rgba(255,255,255,0.6)", marginBottom: 14 }}>Präferenzen</div>
          {PREFERENCES.map((pref, i) => (
            <div key={pref.id} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "12px 0", borderBottom: i < PREFERENCES.length - 1 ? "1px solid rgba(255,255,255,0.05)" : "none" }}>
              <div>
                <div style={{ fontSize: 13, fontWeight: 600 }}>{pref.label}</div>
                <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", marginTop: 1 }}>{pref.desc}</div>
              </div>
              <div onClick={() => setPrefs(p => ({ ...p, [pref.id]: !p[pref.id] }))} style={{ width: 40, height: 22, borderRadius: 100, background: prefs[pref.id] ? "#10B981" : "rgba(255,255,255,0.1)", position: "relative", cursor: "pointer", transition: "background 0.3s", flexShrink: 0 }}>
                <div style={{ position: "absolute", top: 2, left: prefs[pref.id] ? 20 : 2, width: 18, height: 18, borderRadius: "50%", background: "#fff", transition: "left 0.3s" }} />
              </div>
            </div>
          ))}
        </div>

        <div style={{ background: "rgba(255,255,255,0.03)", borderRadius: 16, padding: "16px 18px" }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: "rgba(255,255,255,0.6)", marginBottom: 12 }}>Verlauf</div>
          <div style={{ display: "flex", gap: 8, overflowX: "auto", marginBottom: 14 }}>
            {[{ id: "alle", label: "Alle" }, { id: "stempel", label: "⬛ Stempel" }, { id: "provision", label: "💸 Provision" }, { id: "praemie", label: "🎁 Prämien" }].map(f => (
              <button key={f.id} onClick={() => setHistoryFilter(f.id)} style={{ whiteSpace: "nowrap", padding: "6px 14px", borderRadius: 100, fontSize: 11, fontWeight: 600, border: "none", cursor: "pointer", fontFamily: "inherit", background: historyFilter === f.id ? "#10B981" : "rgba(255,255,255,0.07)", color: historyFilter === f.id ? "#fff" : "rgba(255,255,255,0.45)" }}>{f.label}</button>
            ))}
          </div>
          {filtered.map((item, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 0", borderBottom: i < filtered.length - 1 ? "1px solid rgba(255,255,255,0.05)" : "none" }}>
              <div style={{ width: 36, height: 36, borderRadius: 10, background: `${item.color}20`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, flexShrink: 0 }}>{item.emoji}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 600 }}>{item.business}</div>
                <div style={{ fontSize: 11, color: "rgba(255,255,255,0.35)", marginTop: 1 }}>{item.date}</div>
              </div>
              <div style={{ fontSize: 12, color: item.color, fontWeight: 700 }}>{item.detail}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}