import { useState, useEffect } from "react";

const STORAGE_KEY = "sensalie_onboarding_v2";

const TAB_HINTS = {
  home: { emoji: "👋", title: "Dein Überblick", text: "Hier siehst du alle Highlights auf einen Blick — Ersparnisse, Termine und aktuelle Aktionen." },
  cards: { emoji: "◈", title: "Deine Stempelkarten", text: "Jeder Besuch bringt dich näher zur Prämie. Zeig den QR-Code unten an der Kasse." },
  rewards: { emoji: "🎁", title: "Einlösbare Prämien", text: "Sobald du genug Stempel hast, erscheint deine Prämie hier — einfach an der Kasse vorzeigen." },
  referral: { emoji: "💸", title: "Geld verdienen", text: "Teile deinen Link und verdiene automatisch Provision für jeden Freund, den du bringst." },
  suggest: { emoji: "💡", title: "Wünsche einreichen", text: "Dein Lieblingsladen noch nicht dabei? Schlage ihn vor — wir kontaktieren ihn für dich." },
  support: { emoji: "💬", title: "Julia hilft dir", text: "Hast du Fragen? Julia antwortet sofort — oder erstelle ein Ticket für unser Team." },
};

function getSeenTabs() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"); } catch { return []; }
}

function markTabSeen(tabId) {
  const seen = getSeenTabs();
  if (!seen.includes(tabId)) localStorage.setItem(STORAGE_KEY, JSON.stringify([...seen, tabId]));
}

export function WelcomeBanner({ userName }) {
  const [visible, setVisible] = useState(false);
  useEffect(() => { if (!getSeenTabs().includes("welcome")) setVisible(true); }, []);
  const dismiss = () => { markTabSeen("welcome"); setVisible(false); };
  if (!visible) return null;

  return (
    <div style={{ background: "linear-gradient(135deg, rgba(16,185,129,0.15), rgba(16,185,129,0.05))", border: "1px solid rgba(16,185,129,0.25)", borderRadius: 16, padding: "16px", marginBottom: 16, position: "relative" }}>
      <button onClick={dismiss} style={{ position: "absolute", top: 10, right: 10, background: "none", border: "none", color: "rgba(255,255,255,0.3)", fontSize: 16, cursor: "pointer" }}>✕</button>
      <div style={{ display: "flex", gap: 10, marginBottom: 10 }}>
        <span style={{ fontSize: 20 }}>👋</span>
        <div>
          <div style={{ fontSize: 14, fontWeight: 700, color: "#fff" }}>Willkommen bei Sensalie{userName ? `, ${userName.split(" ")[0]}` : ""}!</div>
          <div style={{ fontSize: 12, color: "rgba(255,255,255,0.5)", marginTop: 2 }}>Entdecke alle Tabs — sammel Stempel, löse Prämien ein und verdiene.</div>
        </div>
      </div>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        {["◈ Karten", "🎁 Prämien", "💸 Empfehlen"].map((label, i) => (
          <span key={i} style={{ padding: "4px 10px", background: "rgba(16,185,129,0.15)", borderRadius: 100, fontSize: 11, color: "#10B981", fontWeight: 600 }}>{label}</span>
        ))}
      </div>
    </div>
  );
}

export function TabHint({ tabId }) {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => {
      const seen = getSeenTabs();
      if (!seen.includes(tabId) && tabId !== "home") { setVisible(true); markTabSeen(tabId); }
    }, 600);
    return () => clearTimeout(t);
  }, [tabId]);

  if (!visible || !TAB_HINTS[tabId]) return null;
  const hint = TAB_HINTS[tabId];

  return (
    <div style={{ background: "rgba(16,185,129,0.08)", border: "1px solid rgba(16,185,129,0.2)", borderRadius: 14, padding: "14px 16px", marginBottom: 16, position: "relative" }}>
      <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 2, background: "linear-gradient(90deg, #10B981, transparent)", borderRadius: "14px 14px 0 0" }} />
      <div style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
        <span style={{ fontSize: 20 }}>{hint.emoji}</span>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: "#fff", marginBottom: 4 }}>{hint.title}</div>
          <div style={{ fontSize: 12, color: "rgba(255,255,255,0.5)", lineHeight: 1.5 }}>{hint.text}</div>
        </div>
        <button onClick={() => setVisible(false)} style={{ background: "none", border: "none", color: "rgba(255,255,255,0.3)", fontSize: 14, cursor: "pointer" }}>✕</button>
      </div>
    </div>
  );
}