import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import BusinessMap from "@/components/customer/BusinessMap";

const CATEGORIES = [
  { name: "Barbershop", emoji: "✂️" }, { name: "Café", emoji: "☕" }, { name: "Restaurant", emoji: "🍽️" },
  { name: "Beauty", emoji: "💄" }, { name: "Nagelstudio", emoji: "💅" }, { name: "Friseur", emoji: "💇" },
  { name: "Massage", emoji: "💆" }, { name: "Wellness", emoji: "🧖" }, { name: "Fitness", emoji: "🏋️" },
  { name: "Bäckerei", emoji: "🥐" }, { name: "Andere", emoji: "🏪" },
];

const FREQUENCY_OPTIONS = [
  { value: "täglich", label: "Täglich", emoji: "🔥" }, { value: "wöchentlich", label: "Wöchentlich", emoji: "📅" },
  { value: "monatlich", label: "Monatlich", emoji: "🗓️" }, { value: "selten", label: "Selten", emoji: "💭" },
];

const STATUS_CONFIG = {
  offen: { label: "Vorgeschlagen", color: "#F59E0B", bg: "rgba(245,158,11,0.12)", border: "rgba(245,158,11,0.3)" },
  in_bearbeitung: { label: "Wird kontaktiert ⚡", color: "#10B981", bg: "rgba(16,185,129,0.12)", border: "rgba(16,185,129,0.3)" },
  gewonnen: { label: "Jetzt dabei! 🎉", color: "#63FFB4", bg: "rgba(99,255,180,0.12)", border: "rgba(99,255,180,0.3)" },
};

function BusinessBrowseTab({ businesses, loadingBiz }) {
  const [selectedCat, setSelectedCat] = useState(null);
  const [viewMode, setViewMode] = useState("list");
  const [cityFilter, setCityFilter] = useState(null);
  const [userCoords, setUserCoords] = useState(null);
  const [userCity, setUserCity] = useState(null);

  useEffect(() => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(async (pos) => {
      try {
        const { latitude, longitude } = pos.coords;
        setUserCoords([latitude, longitude]);
        const res = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json&accept-language=de`);
        const data = await res.json();
        const city = data.address?.city || data.address?.town || data.address?.village || null;
        if (city) { setUserCity(city); setCityFilter(city); }
      } catch (e) {}
    }, () => {});
  }, []);

  const filtered = businesses.filter(b => {
    const catOk = !selectedCat || b.category === selectedCat;
    const cityOk = !cityFilter || b.city?.toLowerCase() === cityFilter.toLowerCase();
    return catOk && cityOk;
  });

  return (
    <div>
      <div style={{ display: "flex", background: "rgba(255,255,255,0.05)", borderRadius: 12, padding: 4, marginBottom: 16 }}>
        {[{ id: "list", label: "☰ Liste" }, { id: "map", label: "🗺️ Karte" }].map(v => (
          <button key={v.id} onClick={() => setViewMode(v.id)} style={{ flex: 1, padding: "8px", borderRadius: 9, border: "none", cursor: "pointer", fontFamily: "inherit", fontSize: 12, fontWeight: 700, transition: "all 0.2s", background: viewMode === v.id ? "#10B981" : "transparent", color: viewMode === v.id ? "#fff" : "rgba(255,255,255,0.4)" }}>
            {v.label}
          </button>
        ))}
      </div>

      {userCity && (
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14, fontSize: 12, color: "rgba(255,255,255,0.5)" }}>
          <span>📍 {userCity}</span>
          <button onClick={() => setCityFilter(cityFilter ? null : userCity)} style={{ padding: "4px 10px", borderRadius: 10, fontSize: 11, fontWeight: 700, border: "none", cursor: "pointer", fontFamily: "inherit", background: cityFilter ? "#10B981" : "rgba(255,255,255,0.08)", color: "#fff" }}>
            {cityFilter ? "✓ Lokal" : "Alle"}
          </button>
        </div>
      )}

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 8, marginBottom: 16 }}>
        <button onClick={() => setSelectedCat(null)} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 3, padding: "10px 4px", borderRadius: 12, border: "none", cursor: "pointer", fontFamily: "inherit", background: !selectedCat ? "#10B981" : "rgba(255,255,255,0.05)" }}>
          <span style={{ fontSize: 16 }}>⬛</span>
          <span style={{ fontSize: 10, color: !selectedCat ? "#fff" : "rgba(255,255,255,0.5)", fontWeight: 700 }}>Alle</span>
        </button>
        {CATEGORIES.map(cat => {
          const isActive = selectedCat === cat.name;
          const count = businesses.filter(b => b.category === cat.name && (!cityFilter || b.city?.toLowerCase() === cityFilter?.toLowerCase())).length;
          return (
            <button key={cat.name} onClick={() => setSelectedCat(isActive ? null : cat.name)} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 3, padding: "10px 4px", borderRadius: 12, border: isActive ? "none" : "1px solid rgba(255,255,255,0.08)", cursor: "pointer", fontFamily: "inherit", background: isActive ? "#10B981" : "rgba(255,255,255,0.05)", opacity: count === 0 ? 0.4 : 1 }}>
              <span style={{ fontSize: 16 }}>{cat.emoji}</span>
              <span style={{ fontSize: 9, color: isActive ? "#fff" : "rgba(255,255,255,0.5)", fontWeight: 700 }}>{cat.name}</span>
            </button>
          );
        })}
      </div>

      {viewMode === "map" && <BusinessMap businesses={filtered} userCoords={userCoords} userCity={userCity} />}

      {viewMode === "list" && (
        loadingBiz ? (
          <div style={{ textAlign: "center", padding: 32, color: "rgba(255,255,255,0.3)", fontSize: 13 }}>Lädt…</div>
        ) : filtered.length === 0 ? (
          <div style={{ textAlign: "center", padding: 32, color: "rgba(255,255,255,0.3)" }}>
            <div style={{ fontSize: 28, marginBottom: 8 }}>🏪</div>
            <div style={{ fontSize: 13 }}>Noch keine Partner{selectedCat ? ` für ${selectedCat}` : ""}</div>
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {filtered.map(biz => {
              const catObj = CATEGORIES.find(c => c.name === biz.category);
              return (
                <div key={biz.id} style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 14, padding: "14px 16px", display: "flex", alignItems: "center", gap: 12 }}>
                  <div style={{ width: 40, height: 40, borderRadius: 12, background: "rgba(16,185,129,0.15)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20, flexShrink: 0 }}>{biz.emoji || catObj?.emoji || "🏪"}</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 14, fontWeight: 700, color: "#fff" }}>{biz.name}</div>
                    <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", marginTop: 1 }}>{biz.category}{biz.city ? ` · 📍 ${biz.city}` : ""}</div>
                    {biz.reward_description && <div style={{ fontSize: 11, color: "#10B981", marginTop: 4 }}>🎁 {biz.reward_description}</div>}
                  </div>
                  <span style={{ fontSize: 10, color: "#10B981", fontWeight: 700 }}>Partner ✓</span>
                </div>
              );
            })}
          </div>
        )
      )}
    </div>
  );
}

function WishlistTab() {
  const [suggestions, setSuggestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ business_name: "", category: "", city: "", visit_frequency: "" });
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => { loadSuggestions(); }, []);

  const loadSuggestions = async () => {
    setLoading(true);
    try { const data = await base44.entities.BusinessSuggestion.list("-votes", 100); setSuggestions(data); } catch (e) {}
    setLoading(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await base44.entities.BusinessSuggestion.create({ ...form, votes: 1, status: "offen" });
      setSubmitted(true);
      setShowForm(false);
      setForm({ business_name: "", category: "", city: "", visit_frequency: "" });
      await loadSuggestions();
    } catch (e) {}
    setSubmitting(false);
  };

  const handleVote = async (suggestion) => {
    try {
      await base44.entities.BusinessSuggestion.update(suggestion.id, { votes: (suggestion.votes || 1) + 1 });
      setSuggestions(prev => prev.map(s => s.id === suggestion.id ? { ...s, votes: (s.votes || 1) + 1 } : s).sort((a, b) => (b.votes || 1) - (a.votes || 1)));
    } catch (e) {}
  };

  return (
    <div>
      {submitted && (
        <div style={{ background: "rgba(16,185,129,0.1)", border: "1px solid rgba(16,185,129,0.25)", borderRadius: 14, padding: "12px 16px", marginBottom: 16, fontSize: 13, color: "#10B981", fontWeight: 600 }}>
          🎉 Danke! Dein Vorschlag wurde eingereicht.
        </div>
      )}

      <button onClick={() => { setShowForm(v => !v); setSubmitted(false); }} style={{ width: "100%", padding: "12px", background: showForm ? "rgba(255,255,255,0.05)" : "#10B981", color: "#fff", fontWeight: 700, fontSize: 13, borderRadius: 12, border: "none", cursor: "pointer", fontFamily: "inherit", marginBottom: 16 }}>
        {showForm ? "✕ Abbrechen" : "💡 Unternehmen vorschlagen"}
      </button>

      {showForm && (
        <form onSubmit={handleSubmit} style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 16, padding: 16, marginBottom: 16 }}>
          <input value={form.business_name} onChange={e => setForm(f => ({ ...f, business_name: e.target.value }))} placeholder="Name des Unternehmens *" required style={{ width: "100%", padding: "11px 14px", background: "rgba(255,255,255,0.06)", border: "1.5px solid rgba(255,255,255,0.1)", borderRadius: 12, fontSize: 13, color: "#fff", fontFamily: "inherit", outline: "none", marginBottom: 10, boxSizing: "border-box" }} />
          <input value={form.city} onChange={e => setForm(f => ({ ...f, city: e.target.value }))} placeholder="Stadt" style={{ width: "100%", padding: "11px 14px", background: "rgba(255,255,255,0.06)", border: "1.5px solid rgba(255,255,255,0.1)", borderRadius: 12, fontSize: 13, color: "#fff", fontFamily: "inherit", outline: "none", marginBottom: 10, boxSizing: "border-box" }} />
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 14 }}>
            {CATEGORIES.map(cat => (
              <button key={cat.name} type="button" onClick={() => setForm(f => ({ ...f, category: cat.name }))} style={{ padding: "6px 12px", borderRadius: 10, fontSize: 11, fontWeight: 700, border: "none", cursor: "pointer", fontFamily: "inherit", background: form.category === cat.name ? "#10B981" : "rgba(255,255,255,0.07)", color: form.category === cat.name ? "#fff" : "rgba(255,255,255,0.5)" }}>
                {cat.emoji} {cat.name}
              </button>
            ))}
          </div>
          <button type="submit" disabled={submitting} style={{ width: "100%", padding: "12px", background: "#10B981", color: "#fff", fontWeight: 700, fontSize: 13, borderRadius: 12, border: "none", cursor: "pointer", fontFamily: "inherit" }}>
            {submitting ? "Wird eingereicht…" : "Vorschlag einreichen →"}
          </button>
        </form>
      )}

      {loading ? (
        <div style={{ textAlign: "center", padding: 32, color: "rgba(255,255,255,0.3)", fontSize: 13 }}>Lädt…</div>
      ) : suggestions.length === 0 ? (
        <div style={{ textAlign: "center", padding: 32, color: "rgba(255,255,255,0.3)" }}>
          <div style={{ fontSize: 28, marginBottom: 8 }}>💡</div>
          <div style={{ fontSize: 13 }}>Noch keine Vorschläge — sei der Erste!</div>
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {suggestions.map((s, i) => {
            const st = STATUS_CONFIG[s.status] || STATUS_CONFIG.offen;
            const catObj = CATEGORIES.find(c => c.name === s.category);
            return (
              <div key={s.id} style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 14, padding: "14px 16px", display: "flex", alignItems: "center", gap: 12 }}>
                <div style={{ width: 36, height: 36, borderRadius: 10, background: "rgba(255,255,255,0.06)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, flexShrink: 0 }}>{catObj?.emoji || "🏪"}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 700, color: "#fff" }}>{s.business_name}</div>
                  <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", marginTop: 2 }}>{s.category || "Keine Kategorie"}{s.city ? ` · ${s.city}` : ""}</div>
                  <span style={{ display: "inline-block", marginTop: 6, padding: "3px 8px", borderRadius: 8, fontSize: 10, fontWeight: 700, background: st.bg, color: st.color, border: `1px solid ${st.border}` }}>{st.label}</span>
                </div>
                <button onClick={() => handleVote(s)} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 2, padding: "8px 12px", borderRadius: 10, background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", cursor: "pointer", color: "#10B981", fontFamily: "inherit" }}>
                  <span style={{ fontSize: 14 }}>👍</span>
                  <span style={{ fontSize: 12, fontWeight: 700 }}>{s.votes || 1}</span>
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

export default function SuggestBusinessTab({ businesses, loadingBiz }) {
  const [activeTab, setActiveTab] = useState("browse");

  return (
    <div>
      <div style={{ display: "flex", background: "rgba(255,255,255,0.05)", borderRadius: 12, padding: 4, marginBottom: 20 }}>
        {[{ id: "browse", label: "🏪 Partner" }, { id: "wishlist", label: "💡 Wünsche" }].map(t => (
          <button key={t.id} onClick={() => setActiveTab(t.id)} style={{ flex: 1, padding: "9px", borderRadius: 9, border: "none", cursor: "pointer", fontFamily: "inherit", fontSize: 12, fontWeight: 700, transition: "all 0.2s", background: activeTab === t.id ? "#10B981" : "transparent", color: activeTab === t.id ? "#fff" : "rgba(255,255,255,0.4)" }}>
            {t.label}
          </button>
        ))}
      </div>
      {activeTab === "browse" ? <BusinessBrowseTab businesses={businesses} loadingBiz={loadingBiz} /> : <WishlistTab />}
    </div>
  );
}