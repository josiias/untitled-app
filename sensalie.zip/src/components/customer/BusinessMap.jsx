import { useState, useEffect } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
});

function createCustomIcon(emoji, color) {
  return L.divIcon({
    html: `<div style="width:36px;height:36px;background:${color || "#10B981"};border-radius:50% 50% 50% 0;transform:rotate(-45deg);display:flex;align-items:center;justify-content:center;border:2px solid rgba(255,255,255,0.3)"><span style="transform:rotate(45deg);font-size:16px">${emoji || "🏪"}</span></div>`,
    className: "",
    iconSize: [36, 36],
    iconAnchor: [18, 36],
    popupAnchor: [0, -38],
  });
}

function FlyTo({ center }) {
  const map = useMap();
  useEffect(() => {
    if (center) map.flyTo(center, 13, { duration: 1.2 });
  }, [center, map]);
  return null;
}

const geocodeCache = {};
async function geocodeCity(city) {
  if (geocodeCache[city]) return geocodeCache[city];
  try {
    const res = await fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(city)}&format=json&limit=1&accept-language=de`);
    const data = await res.json();
    if (data.length > 0) {
      const coords = [parseFloat(data[0].lat), parseFloat(data[0].lon)];
      geocodeCache[city] = coords;
      return coords;
    }
  } catch (e) {}
  return null;
}

const CATEGORIES = [
  { name: "Barbershop", emoji: "✂️", color: "#10B981" },
  { name: "Café", emoji: "☕", color: "#F59E0B" },
  { name: "Restaurant", emoji: "🍽️", color: "#F97316" },
  { name: "Beauty", emoji: "💄", color: "#EC4899" },
  { name: "Nagelstudio", emoji: "💅", color: "#EC4899" },
  { name: "Friseur", emoji: "💇", color: "#38BDF8" },
  { name: "Massage", emoji: "💆", color: "#8B5CF6" },
  { name: "Wellness", emoji: "🧖", color: "#A78BFA" },
  { name: "Fitness", emoji: "🏋️", color: "#3B82F6" },
  { name: "Bäckerei", emoji: "🥐", color: "#D97706" },
  { name: "Andere", emoji: "🏪", color: "#6B7280" },
];

export default function BusinessMap({ businesses, userCoords, userCity }) {
  const [markers, setMarkers] = useState([]);
  const [selectedBiz, setSelectedBiz] = useState(null);
  const [geocoding, setGeocoding] = useState(true);
  const [mapCenter, setMapCenter] = useState(userCoords || [51.1657, 10.4515]);

  useEffect(() => {
    if (userCoords) setMapCenter(userCoords);
  }, [userCoords]);

  useEffect(() => {
    if (!businesses.length) { setGeocoding(false); return; }
    setGeocoding(true);
    const geocodeAll = async () => {
      const result = [];
      const uniqueCities = [...new Set(businesses.map(b => b.city).filter(Boolean))];
      const cityCoords = {};
      await Promise.all(uniqueCities.map(async city => {
        const coords = await geocodeCity(city);
        if (coords) cityCoords[city] = coords;
      }));
      for (const biz of businesses) {
        if (!biz.city) continue;
        const base = cityCoords[biz.city];
        if (!base) continue;
        const offset = () => (Math.random() - 0.5) * 0.008;
        result.push({ biz, coords: [base[0] + offset(), base[1] + offset()] });
      }
      setMarkers(result);
      setGeocoding(false);
    };
    geocodeAll();
  }, [businesses]);

  return (
    <div style={{ borderRadius: 16, overflow: "hidden", position: "relative" }}>
      <div style={{ padding: "12px 16px", background: "rgba(255,255,255,0.04)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span>🗺️</span>
          <span style={{ fontSize: 14, fontWeight: 700, color: "#fff" }}>
            {userCity ? `Partner in ${userCity}` : "Karte aller Partner"}
          </span>
        </div>
        <span style={{ fontSize: 11, color: "rgba(255,255,255,0.4)" }}>
          {geocoding ? "Lädt…" : `${markers.length} Partner`}
        </span>
      </div>

      {geocoding && (
        <div style={{ height: 300, display: "flex", alignItems: "center", justifyContent: "center", background: "rgba(255,255,255,0.03)" }}>
          <div style={{ textAlign: "center", color: "rgba(255,255,255,0.4)", fontSize: 13 }}>🗺️ Karte wird geladen…</div>
        </div>
      )}

      {!geocoding && (
        <MapContainer center={mapCenter} zoom={userCoords ? 13 : 6} style={{ height: 300, width: "100%" }}>
          <TileLayer url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png" attribution='© OpenStreetMap © CARTO' />
          <FlyTo center={mapCenter} />
          {userCoords && (
            <Marker position={userCoords} icon={L.divIcon({ html: `<div style="width:14px;height:14px;background:#10B981;border-radius:50%;border:2px solid #fff;box-shadow:0 0 0 4px rgba(16,185,129,0.3)"></div>`, className: "", iconSize: [14, 14], iconAnchor: [7, 7] })}>
              <Popup>📍 Dein Standort</Popup>
            </Marker>
          )}
          {markers.map(({ biz, coords }) => {
            const catObj = CATEGORIES.find(c => c.name === biz.category);
            const icon = createCustomIcon(biz.emoji || catObj?.emoji || "🏪", biz.color || catObj?.color || "#10B981");
            return (
              <Marker key={biz.id} position={coords} icon={icon} eventHandlers={{ click: () => setSelectedBiz(biz) }}>
                <Popup>
                  <div style={{ fontFamily: "inherit", minWidth: 160 }}>
                    <div style={{ fontWeight: 700 }}>{biz.emoji || catObj?.emoji} {biz.name}</div>
                    <div style={{ fontSize: 11, color: "#666" }}>{biz.category}{biz.city ? ` · ${biz.city}` : ""}</div>
                    {biz.reward_description && <div style={{ fontSize: 12, color: "#10B981", marginTop: 4 }}>🎁 {biz.reward_description}</div>}
                  </div>
                </Popup>
              </Marker>
            );
          })}
        </MapContainer>
      )}
    </div>
  );
}