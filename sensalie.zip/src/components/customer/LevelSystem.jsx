import { useState } from "react";

export const LEVELS = [
  { id: "starter", label: "Starter", emoji: "🌱", color: "#6B7280", min: 0 },
  { id: "sammler", label: "Sammler", emoji: "⭐", color: "#10B981", min: 10 },
  { id: "stammi", label: "Stammi", emoji: "🔥", color: "#F59E0B", min: 25 },
  { id: "profi", label: "Sensalie Profi", emoji: "💎", color: "#8B5CF6", min: 50 },
  { id: "koenig", label: "Sensalie King", emoji: "👑", color: "#EC4899", min: 100 },
];

export const BADGES = [
  { id: "erster_stempel", label: "Erster Schritt", emoji: "👣", desc: "Ersten Stempel gesammelt", type: "stempel", req: { stamps: 1 } },
  { id: "stempel5", label: "Fleißiger Sammler", emoji: "📬", desc: "5 Stempel gesammelt", type: "stempel", req: { stamps: 5 } },
  { id: "stempel25", label: "Stempel-Profi", emoji: "🏅", desc: "25 Stempel gesammelt", type: "stempel", req: { stamps: 25 } },
  { id: "stempel50", label: "Stempel-König", emoji: "👑", desc: "50 Stempel gesammelt", type: "stempel", req: { stamps: 50 } },
  { id: "stempel100", label: "Stempel-Legende", emoji: "🏆", desc: "100 Stempel gesammelt", type: "stempel", req: { stamps: 100 } },
  { id: "erste_empfehlung", label: "Connector", emoji: "🤝", desc: "Erste Empfehlung abgegeben", type: "referral", req: { referrals: 1 } },
  { id: "empfehlung3", label: "Netzwerker", emoji: "🌐", desc: "3 Empfehlungen gemacht", type: "referral", req: { referrals: 3 } },
  { id: "empfehlung10", label: "Empfehlungs-Profi", emoji: "💸", desc: "10 Empfehlungen gemacht", type: "referral", req: { referrals: 10 } },
  { id: "treuer_kunde", label: "Treuer Kunde", emoji: "❤️", desc: "5 verschiedene Shops besucht", type: "combo", req: { stamps: 5, referrals: 1 } },
  { id: "superstar", label: "Superstar", emoji: "🌟", desc: "25 Stempel + 3 Empfehlungen", type: "combo", req: { stamps: 25, referrals: 3 } },
];

export function calcUserStats(totalStamps, totalReferrals) {
  const xp = totalStamps * 1 + totalReferrals * 5;
  let currentLevel = LEVELS[0];
  let nextLevel = LEVELS[1];
  for (let i = LEVELS.length - 1; i >= 0; i--) {
    if (xp >= LEVELS[i].min) { currentLevel = LEVELS[i]; nextLevel = LEVELS[i + 1] || null; break; }
  }
  const xpIntoLevel = nextLevel ? xp - currentLevel.min : 0;
  const xpNeeded = nextLevel ? nextLevel.min - currentLevel.min : 0;
  const pct = nextLevel ? Math.min(100, Math.round((xpIntoLevel / xpNeeded) * 100)) : 100;
  const unlockedBadges = BADGES.filter(b =>
    (b.req.stamps === undefined || totalStamps >= b.req.stamps) &&
    (b.req.referrals === undefined || totalReferrals >= b.req.referrals)
  );
  return { xp, currentLevel, nextLevel, pct, xpIntoLevel, xpNeeded, unlockedBadges };
}

export default function LevelSystem({ totalStamps, totalReferrals }) {
  const [selectedBadge, setSelectedBadge] = useState(null);
  const { xp, currentLevel, nextLevel, pct, xpIntoLevel, xpNeeded, unlockedBadges } = calcUserStats(totalStamps, totalReferrals);
  const TYPE_COLORS = { stempel: "#10B981", referral: "#F59E0B", combo: "#8B5CF6" };

  return (
    <>
      <div style={{ background: `linear-gradient(135deg, ${currentLevel.color}18, rgba(255,255,255,0.02))`, border: `1px solid ${currentLevel.color}30`, borderRadius: 20, padding: 20, marginBottom: 16, position: "relative", overflow: "hidden" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 16 }}>
          <div style={{ width: 52, height: 52, borderRadius: 16, background: `${currentLevel.color}20`, border: `2px solid ${currentLevel.color}40`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24 }}>{currentLevel.emoji}</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", marginBottom: 2 }}>Dein Level</div>
            <div style={{ fontSize: 16, fontWeight: 800, color: "#fff" }}>{currentLevel.label}</div>
            <div style={{ fontSize: 11, color: currentLevel.color }}>{xp} XP gesamt</div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)" }}>Badges</div>
            <div style={{ fontSize: 16, fontWeight: 700, color: "#fff" }}>{unlockedBadges.length}/{BADGES.length}</div>
          </div>
        </div>

        {nextLevel ? (
          <div>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: "rgba(255,255,255,0.4)", marginBottom: 6 }}>
              <span>Nächstes: {nextLevel.emoji} {nextLevel.label}</span>
              <span>{xpIntoLevel}/{xpNeeded} XP</span>
            </div>
            <div style={{ height: 6, background: "rgba(255,255,255,0.08)", borderRadius: 100 }}>
              <div style={{ height: "100%", width: `${pct}%`, background: `linear-gradient(90deg, ${currentLevel.color}, ${nextLevel.color})`, borderRadius: 100, transition: "width 0.8s ease" }} />
            </div>
            <div style={{ fontSize: 10, color: "rgba(255,255,255,0.3)", marginTop: 4 }}>Noch {xpNeeded - xpIntoLevel} XP · 1 XP/Stempel, 5 XP/Empfehlung</div>
          </div>
        ) : (
          <div style={{ fontSize: 13, color: "#EC4899", fontWeight: 700 }}>👑 Maximales Level erreicht!</div>
        )}
      </div>

      <div style={{ marginBottom: 16 }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: "rgba(255,255,255,0.7)", marginBottom: 12 }}>Badges · {unlockedBadges.length}/{BADGES.length}</div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 8 }}>
          {BADGES.map(badge => {
            const unlocked = unlockedBadges.some(b => b.id === badge.id);
            const typeColor = TYPE_COLORS[badge.type] || "#10B981";
            return (
              <button key={badge.id} onClick={() => setSelectedBadge({ badge, unlocked })} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4, background: unlocked ? `${typeColor}15` : "rgba(255,255,255,0.04)", border: unlocked ? `1.5px solid ${typeColor}40` : "1px solid rgba(255,255,255,0.07)", borderRadius: 12, padding: "10px 4px", cursor: "pointer", opacity: unlocked ? 1 : 0.4, transition: "all 0.2s" }}>
                <span style={{ fontSize: 20, filter: unlocked ? "none" : "grayscale(1)" }}>{badge.emoji}</span>
                <span style={{ fontSize: 9, color: "rgba(255,255,255,0.5)", textAlign: "center", lineHeight: 1.2 }}>{badge.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {selectedBadge && (
        <div onClick={() => setSelectedBadge(null)} style={{ position: "fixed", inset: 0, zIndex: 100, background: "rgba(0,0,0,0.75)", backdropFilter: "blur(10px)", display: "flex", alignItems: "flex-end", justifyContent: "center" }}>
          <div onClick={e => e.stopPropagation()} style={{ width: "100%", maxWidth: 600, background: "#111e28", borderRadius: "28px 28px 0 0", padding: "32px 24px 48px", textAlign: "center" }}>
            <div style={{ fontSize: 56, marginBottom: 12 }}>{selectedBadge.badge.emoji}</div>
            <div style={{ fontSize: 18, fontWeight: 800, color: "#fff", marginBottom: 8 }}>{selectedBadge.badge.label}</div>
            <div style={{ fontSize: 13, color: "rgba(255,255,255,0.5)", marginBottom: 20 }}>{selectedBadge.badge.desc}</div>
            <div style={{ display: "inline-block", padding: "8px 20px", borderRadius: 100, background: selectedBadge.unlocked ? "rgba(16,185,129,0.15)" : "rgba(255,255,255,0.06)", color: selectedBadge.unlocked ? "#10B981" : "rgba(255,255,255,0.3)", fontSize: 13, fontWeight: 700 }}>
              {selectedBadge.unlocked ? "✓ Freigeschaltet" : "Noch nicht freigeschaltet"}
            </div>
          </div>
        </div>
      )}
    </>
  );
}