import { useState } from "react";
import { base44 } from "@/api/base44Client";

const QUICK_QUESTIONS = [
  "Wie funktioniert das Stempeln?",
  "Wann bekomme ich meine Provision?",
  "Wie viele Stempel brauche ich?",
  "Was ist Sensalie Plus?",
  "Wie empfehle ich einen Freund?",
];

const TICKET_CATEGORIES = [
  { value: "stempel", label: "Stempel / QR-Code", emoji: "⬛" },
  { value: "provision", label: "Provision / Empfehlung", emoji: "💸" },
  { value: "partner", label: "Partnerbetrieb", emoji: "🏪" },
  { value: "app", label: "App-Problem", emoji: "📱" },
  { value: "sonstiges", label: "Sonstiges", emoji: "💬" },
];

const FAQ = [
  { q: "Wie funktioniert das Stempeln?", a: "Einfach den QR-Code im Geschäft scannen — dein Stempel wird automatisch gespeichert. Kein Download nötig!" },
  { q: "Wann bekomme ich meine Provision?", a: "Sobald dein empfohlener Freund die nötige Anzahl Besuche erreicht, wird die Provision in deinem Konto gutgeschrieben." },
  { q: "Wie viele Stempel brauche ich?", a: "Das variiert je nach Geschäft — sieh dir die Anzahl direkt auf deiner Stempelkarte an." },
  { q: "Was ist Sensalie Plus?", a: "Sensalie Plus ist unser Premium-Tier mit detaillierten Analysen, bevorzugtem Support und mehr. Kommt bald!" },
  { q: "Wie empfehle ich einen Freund?", a: "Teile deinen persönlichen Empfehlungslink aus dem 'Empfehlen'-Tab. Jeder Freund der sich registriert bringt dir Provision." },
];

function TicketForm({ onClose, onSubmitted }) {
  const [form, setForm] = useState({ subject: "", message: "", category: "sonstiges" });
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await base44.entities.SupportTicket.create({ ...form, status: "offen" });
      onSubmitted();
    } catch (err) { console.error(err); }
    setSubmitting(false);
  };

  return (
    <div style={{ background: "#111e28", borderRadius: 20, padding: 20 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
        <div style={{ fontSize: 15, fontWeight: 700, color: "#fff" }}>🎫 Support-Ticket</div>
        <button onClick={onClose} style={{ background: "none", border: "none", color: "rgba(255,255,255,0.4)", fontSize: 18, cursor: "pointer" }}>✕</button>
      </div>
      <form onSubmit={handleSubmit}>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 14 }}>
          {TICKET_CATEGORIES.map(cat => (
            <button key={cat.value} type="button" onClick={() => setForm(f => ({ ...f, category: cat.value }))} style={{ padding: "6px 12px", borderRadius: 10, fontSize: 11, fontWeight: 700, border: "none", cursor: "pointer", fontFamily: "inherit", background: form.category === cat.value ? "#10B981" : "rgba(255,255,255,0.07)", color: form.category === cat.value ? "#fff" : "rgba(255,255,255,0.5)" }}>
              {cat.emoji} {cat.label}
            </button>
          ))}
        </div>
        <input value={form.subject} onChange={e => setForm(f => ({ ...f, subject: e.target.value }))} placeholder="Betreff *" required style={{ width: "100%", padding: "11px 14px", background: "rgba(255,255,255,0.06)", border: "1.5px solid rgba(255,255,255,0.1)", borderRadius: 12, fontSize: 13, color: "#fff", fontFamily: "inherit", outline: "none", marginBottom: 10, boxSizing: "border-box" }} />
        <textarea value={form.message} onChange={e => setForm(f => ({ ...f, message: e.target.value }))} placeholder="Beschreibe dein Problem *" required rows={4} style={{ width: "100%", padding: "11px 14px", background: "rgba(255,255,255,0.06)", border: "1.5px solid rgba(255,255,255,0.1)", borderRadius: 12, fontSize: 13, color: "#fff", fontFamily: "inherit", outline: "none", resize: "none", marginBottom: 14, boxSizing: "border-box" }} />
        <button type="submit" disabled={submitting} style={{ width: "100%", padding: "12px", background: submitting ? "rgba(16,185,129,0.5)" : "#10B981", color: "#fff", fontWeight: 700, fontSize: 13, borderRadius: 12, border: "none", cursor: submitting ? "not-allowed" : "pointer", fontFamily: "inherit" }}>
          {submitting ? "Wird gesendet…" : "Ticket absenden"}
        </button>
      </form>
    </div>
  );
}

export default function SupportChatTab() {
  const [showTicket, setShowTicket] = useState(false);
  const [ticketSent, setTicketSent] = useState(false);
  const [expandedFaq, setExpandedFaq] = useState(null);

  if (showTicket && !ticketSent) return <TicketForm onClose={() => setShowTicket(false)} onSubmitted={() => { setTicketSent(true); setShowTicket(false); }} />;

  return (
    <div>
      {ticketSent && (
        <div style={{ background: "rgba(16,185,129,0.1)", border: "1px solid rgba(16,185,129,0.25)", borderRadius: 14, padding: "14px 16px", marginBottom: 16, display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ fontSize: 20 }}>✅</span>
          <div>
            <div style={{ fontSize: 13, fontWeight: 700, color: "#10B981" }}>Ticket erfolgreich gesendet!</div>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", marginTop: 2 }}>Wir antworten dir so schnell wie möglich.</div>
          </div>
        </div>
      )}

      <div style={{ background: "linear-gradient(135deg, rgba(16,185,129,0.12), rgba(16,185,129,0.04))", border: "1px solid rgba(16,185,129,0.2)", borderRadius: 16, padding: 16, marginBottom: 20, display: "flex", gap: 12, alignItems: "center" }}>
        <div style={{ width: 44, height: 44, borderRadius: 14, background: "#10B981", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, flexShrink: 0 }}>🤖</div>
        <div>
          <div style={{ fontSize: 14, fontWeight: 700, color: "#fff" }}>Julia — KI-Assistentin</div>
          <div style={{ fontSize: 12, color: "rgba(255,255,255,0.5)", marginTop: 2 }}>Antwortet sofort auf häufige Fragen</div>
        </div>
      </div>

      <div style={{ marginBottom: 20 }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: "rgba(255,255,255,0.5)", marginBottom: 12 }}>Häufige Fragen</div>
        {FAQ.map((item, i) => (
          <div key={i} style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 12, marginBottom: 8, overflow: "hidden" }}>
            <button onClick={() => setExpandedFaq(expandedFaq === i ? null : i)} style={{ width: "100%", padding: "14px 16px", background: "none", border: "none", cursor: "pointer", fontFamily: "inherit", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8 }}>
              <span style={{ fontSize: 13, fontWeight: 600, color: "#fff", textAlign: "left" }}>{item.q}</span>
              <span style={{ color: "#10B981", fontSize: 16, flexShrink: 0, transition: "transform 0.2s", transform: expandedFaq === i ? "rotate(180deg)" : "none" }}>▼</span>
            </button>
            {expandedFaq === i && (
              <div style={{ padding: "0 16px 14px", fontSize: 13, color: "rgba(255,255,255,0.6)", lineHeight: 1.6 }}>{item.a}</div>
            )}
          </div>
        ))}
      </div>

      <div style={{ background: "rgba(255,255,255,0.03)", borderRadius: 16, padding: 16 }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: "rgba(255,255,255,0.6)", marginBottom: 12 }}>Direkte Hilfe</div>
        <p style={{ fontSize: 13, color: "rgba(255,255,255,0.5)", marginBottom: 14, lineHeight: 1.5 }}>Deine Frage nicht dabei? Erstelle ein Support-Ticket und unser Team meldet sich bei dir.</p>
        <button onClick={() => setShowTicket(true)} style={{ width: "100%", padding: "12px", background: "#10B981", color: "#fff", fontWeight: 700, fontSize: 13, borderRadius: 12, border: "none", cursor: "pointer", fontFamily: "inherit" }}>
          🎫 Support-Ticket erstellen
        </button>
      </div>
    </div>
  );
}