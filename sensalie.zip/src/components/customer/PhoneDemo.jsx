import { useState, useEffect } from "react";

const STEPS = [
  {
    id: "scan",
    label: "QR-Code scannen",
    color: "#10B981",
    screen: <ScanScreen />,
  },
  {
    id: "stamp",
    label: "Stempel sammeln",
    color: "#F59E0B",
    screen: <StampScreen />,
  },
  {
    id: "reward",
    label: "Prämie kassieren",
    color: "#EC4899",
    screen: <RewardScreen />,
  },
  {
    id: "referral",
    label: "Geld verdienen",
    color: "#8B5CF6",
    screen: <ReferralScreen />,
  },
];

// ── Screen 1: QR Scan ──
function ScanScreen() {
  const [scanned, setScanned] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setScanned(true), 1400);
    return () => { clearTimeout(t); setScanned(false); };
  }, []);

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "100%", gap: 16, padding: "0 20px" }}>
      <div style={{ fontSize: 13, fontWeight: 700, color: "rgba(255,255,255,0.5)", letterSpacing: 1 }}>KINGS BARBERSHOP</div>
      <div style={{ position: "relative" }}>
        {/* QR code mock */}
        <div style={{ width: 120, height: 120, background: "#fff", borderRadius: 12, padding: 8, display: "grid", gridTemplateColumns: "repeat(6,1fr)", gap: 2 }}>
          {Array.from({ length: 36 }, (_, i) => (
            <div key={i} style={{ background: [0,1,2,6,7,8,12,13,14,3,9,15,18,19,20,24,25,26,21,27,4,10,16,22,28,34,30,31,32,33,35,5].includes(i) ? "#000" : "#fff", borderRadius: 1 }} />
          ))}
        </div>
        {/* Scan line */}
        <div style={{ position: "absolute", left: 4, right: 4, height: 2, background: "rgba(16,185,129,0.9)", borderRadius: 100, top: scanned ? "90%" : "10%", transition: "top 1.2s ease-in-out", boxShadow: "0 0 8px rgba(16,185,129,0.8)" }} />
        {/* Corner frames */}
        {["top:0,left:0", "top:0,right:0", "bottom:0,left:0", "bottom:0,right:0"].map((pos, i) => {
          const [v, h] = pos.split(",");
          const [vk, vv] = v.split(":");
          const [hk, hv] = h.split(":");
          return (
            <div key={i} style={{ position: "absolute", width: 18, height: 18, [vk]: -2, [hk]: -2, borderTop: (vk === "top") ? "3px solid #10B981" : "none", borderBottom: (vk === "bottom") ? "3px solid #10B981" : "none", borderLeft: (hk === "left") ? "3px solid #10B981" : "none", borderRight: (hk === "right") ? "3px solid #10B981" : "none" }} />
          );
        })}
      </div>
      <div style={{ fontSize: 12, color: scanned ? "#10B981" : "rgba(255,255,255,0.35)", fontWeight: 700, transition: "color 0.4s", textAlign: "center" }}>
        {scanned ? "✓ Erfolgreich gescannt!" : "QR-Code wird gescannt..."}
      </div>
    </div>
  );
}

// ── Screen 2: Stamp collect ──
function StampScreen() {
  const [count, setCount] = useState(4);
  useEffect(() => {
    setCount(4);
    const t = setTimeout(() => setCount(5), 900);
    return () => clearTimeout(t);
  }, []);
  const total = 8;
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", padding: "16px 16px 10px" }}>
      <div style={{ fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,0.4)", letterSpacing: 1, marginBottom: 4 }}>KINGS BARBERSHOP</div>
      <div style={{ fontSize: 16, fontWeight: 900, color: "#fff", marginBottom: 12 }}>Deine Stempelkarte</div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 6, marginBottom: 12 }}>
        {Array.from({ length: total }, (_, i) => (
          <div key={i} style={{
            aspectRatio: "1/1", borderRadius: 10,
            background: i < count ? "rgba(245,158,11,0.2)" : "rgba(255,255,255,0.06)",
            border: `1.5px solid ${i < count ? "#F59E0B" : "rgba(255,255,255,0.1)"}`,
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 16,
            transform: i === count - 1 && count === 5 ? "scale(1.15)" : "scale(1)",
            transition: "all 0.4s cubic-bezier(0.34,1.56,0.64,1)",
            boxShadow: i === count - 1 && count === 5 ? "0 0 16px rgba(245,158,11,0.5)" : "none",
          }}>
            {i < count ? "✂️" : ""}
          </div>
        ))}
      </div>
      <div style={{ fontSize: 11, color: "rgba(255,255,255,0.35)", textAlign: "center" }}>
        {count}/{total} Stempel · Noch {total - count} bis zur Prämie
      </div>
      <div style={{ height: 4, background: "rgba(255,255,255,0.08)", borderRadius: 100, marginTop: 10, overflow: "hidden" }}>
        <div style={{ height: "100%", width: `${(count / total) * 100}%`, background: "#F59E0B", borderRadius: 100, transition: "width 0.8s cubic-bezier(0.22,1,0.36,1)" }} />
      </div>
    </div>
  );
}

// ── Screen 3: Reward ──
function RewardScreen() {
  const [show, setShow] = useState(false);
  const [confetti, setConfetti] = useState([]);
  useEffect(() => {
    setShow(false); setConfetti([]);
    const t = setTimeout(() => {
      setShow(true);
      setConfetti(Array.from({ length: 18 }, (_, i) => ({
        id: i, x: Math.random() * 100, delay: Math.random() * 0.5,
        color: ["#EC4899","#10B981","#F59E0B","#8B5CF6","#fff"][i % 5],
        size: 4 + Math.random() * 5,
      })));
    }, 700);
    return () => clearTimeout(t);
  }, []);

  return (
    <div style={{ position: "relative", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "100%", gap: 10, padding: "0 16px", overflow: "hidden" }}>
      {confetti.map(c => (
        <div key={c.id} style={{
          position: "absolute", left: `${c.x}%`, top: -10,
          width: c.size, height: c.size, borderRadius: 2,
          background: c.color, animation: show ? `confettiFall 1.2s ease-in ${c.delay}s forwards` : "none",
        }} />
      ))}
      <div style={{ fontSize: show ? 44 : 32, transition: "font-size 0.4s cubic-bezier(0.34,1.56,0.64,1)", filter: show ? "drop-shadow(0 0 20px rgba(236,72,153,0.6))" : "none" }}>🎁</div>
      <div style={{ fontSize: 15, fontWeight: 900, color: "#fff", textAlign: "center", opacity: show ? 1 : 0, transform: show ? "translateY(0)" : "translateY(10px)", transition: "all 0.5s ease 0.2s" }}>
        Prämie freigeschaltet!
      </div>
      <div style={{ fontSize: 12, color: "rgba(255,255,255,0.45)", textAlign: "center", opacity: show ? 1 : 0, transition: "opacity 0.5s ease 0.4s", lineHeight: 1.5 }}>
        Maniküre gratis<br />bei Bella Nails 💅
      </div>
      <div style={{ padding: "10px 20px", background: "#EC4899", borderRadius: 100, fontSize: 12, fontWeight: 800, color: "#fff", opacity: show ? 1 : 0, transition: "opacity 0.5s ease 0.6s", boxShadow: "0 6px 20px rgba(236,72,153,0.4)" }}>
        Jetzt einlösen
      </div>
      <style>{`@keyframes confettiFall { to { transform: translateY(280px) rotate(360deg); opacity: 0; } }`}</style>
    </div>
  );
}

// ── Screen 4: Referral payout ──
function ReferralScreen() {
  const [stage, setStage] = useState(0);
  useEffect(() => {
    setStage(0);
    const t1 = setTimeout(() => setStage(1), 600);
    const t2 = setTimeout(() => setStage(2), 1600);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, []);

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", padding: "14px 14px 10px" }}>
      <div style={{ fontSize: 13, fontWeight: 900, color: "#fff", marginBottom: 12 }}>Empfehlen & Verdienen</div>

      {/* Referral code */}
      <div style={{ background: "rgba(139,92,246,0.12)", border: "1.5px solid rgba(139,92,246,0.3)", borderRadius: 12, padding: "10px 14px", marginBottom: 10 }}>
        <div style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", marginBottom: 4 }}>DEIN CODE</div>
        <div style={{ fontSize: 18, fontWeight: 900, color: "#8B5CF6", letterSpacing: 2 }}>MAX2026</div>
      </div>

      {/* Notification pop */}
      <div style={{
        background: stage >= 1 ? "rgba(16,185,129,0.12)" : "rgba(255,255,255,0.04)",
        border: `1.5px solid ${stage >= 1 ? "rgba(16,185,129,0.4)" : "rgba(255,255,255,0.08)"}`,
        borderRadius: 12, padding: "10px 14px", marginBottom: 8,
        opacity: stage >= 1 ? 1 : 0.3, transition: "all 0.5s ease",
        transform: stage === 1 ? "scale(1.03)" : "scale(1)",
      }}>
        <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", marginBottom: 3 }}>Neue Empfehlung 🎉</div>
        <div style={{ fontSize: 12, fontWeight: 700, color: "#fff" }}>Sara hat dich verwendet!</div>
      </div>

      {/* Payout */}
      <div style={{
        background: stage >= 2 ? "linear-gradient(135deg, rgba(139,92,246,0.2), rgba(139,92,246,0.05))" : "rgba(255,255,255,0.03)",
        border: `1.5px solid ${stage >= 2 ? "rgba(139,92,246,0.4)" : "rgba(255,255,255,0.06)"}`,
        borderRadius: 12, padding: "12px 14px",
        opacity: stage >= 2 ? 1 : 0.2, transition: "all 0.6s ease 0.2s",
        transform: stage >= 2 ? "scale(1.02)" : "scale(1)",
      }}>
        <div style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", marginBottom: 4 }}>PROVISION ERHALTEN 💸</div>
        <div style={{ fontSize: 22, fontWeight: 900, color: "#8B5CF6" }}>+ 20,00 €</div>
        <div style={{ fontSize: 10, color: "rgba(255,255,255,0.3)", marginTop: 2 }}>automatisch gutgeschrieben</div>
      </div>
    </div>
  );
}

export default function PhoneDemo() {
  const [activeStep, setActiveStep] = useState(0);
  const [key, setKey] = useState(0);

  useEffect(() => {
    const t = setInterval(() => {
      setActiveStep(s => (s + 1) % STEPS.length);
      setKey(k => k + 1);
    }, 3600);
    return () => clearInterval(t);
  }, []);

  const handleStep = (i) => { setActiveStep(i); setKey(k => k + 1); };
  const step = STEPS[activeStep];

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 28 }}>
      {/* Step labels */}
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "center" }}>
        {STEPS.map((s, i) => (
          <button key={i} onClick={() => handleStep(i)} style={{
            padding: "7px 14px", borderRadius: 100, border: "none", cursor: "pointer", fontFamily: "inherit",
            background: i === activeStep ? s.color : "rgba(255,255,255,0.07)",
            color: i === activeStep ? "#fff" : "rgba(255,255,255,0.4)",
            fontSize: 12, fontWeight: 700,
            transition: "all 0.3s ease",
            boxShadow: i === activeStep ? `0 4px 16px ${s.color}40` : "none",
          }}>
            {s.label}
          </button>
        ))}
      </div>

      {/* Phone frame */}
      <div style={{ position: "relative", width: 220, height: 420 }}>
        {/* Glow behind phone */}
        <div style={{ position: "absolute", inset: -30, background: `radial-gradient(ellipse, ${step.color}25 0%, transparent 70%)`, transition: "background 0.6s ease", borderRadius: "50%", zIndex: 0 }} />

        {/* Phone shell */}
        <div style={{
          position: "relative", zIndex: 1,
          width: 220, height: 420,
          background: "linear-gradient(160deg, #1a2232, #0d1520)",
          borderRadius: 40,
          border: "2px solid rgba(255,255,255,0.12)",
          boxShadow: "0 32px 80px rgba(0,0,0,0.7), inset 0 1px 0 rgba(255,255,255,0.08)",
          overflow: "hidden",
        }}>
          {/* Notch */}
          <div style={{ position: "absolute", top: 0, left: "50%", transform: "translateX(-50%)", width: 80, height: 24, background: "#0d1520", borderRadius: "0 0 16px 16px", zIndex: 10 }} />

          {/* Status bar */}
          <div style={{ padding: "28px 18px 0", display: "flex", justifyContent: "space-between", fontSize: 9, color: "rgba(255,255,255,0.35)" }}>
            <span>9:41</span>
            <span>●●●</span>
          </div>

          {/* Screen content */}
          <div key={key} style={{ height: "calc(100% - 52px)", animation: "screenFadeIn 0.4s ease" }}>
            {step.screen}
          </div>

          {/* Bottom bar */}
          <div style={{ position: "absolute", bottom: 10, left: "50%", transform: "translateX(-50%)", width: 60, height: 4, background: "rgba(255,255,255,0.2)", borderRadius: 100 }} />
        </div>
      </div>

      {/* Progress dots */}
      <div style={{ display: "flex", gap: 6 }}>
        {STEPS.map((s, i) => (
          <div key={i} style={{ width: i === activeStep ? 20 : 6, height: 6, borderRadius: 100, background: i === activeStep ? step.color : "rgba(255,255,255,0.15)", transition: "all 0.3s ease" }} />
        ))}
      </div>

      <style>{`@keyframes screenFadeIn { from { opacity:0; transform: translateY(8px); } to { opacity:1; transform: translateY(0); } }`}</style>
    </div>
  );
}