import React, { useEffect, useRef, useState } from "react";

const stats = [
  { value: 88, suffix: "%", label: "Vertrauen Empfehlungen von Freunden", prefix: "", icon: "🤝", color: "#00b894" },
  { value: 95, suffix: "%", label: "Mehr Gewinn durch Stammkunden", prefix: "+", icon: "📈", color: "#00cec9" },
  { value: 0, suffix: "€", label: "Vorab-Risiko für dich", prefix: "", icon: "🛡️", color: "#55efc4" },
];

function CountUp({ target, prefix, suffix, started }) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    if (!started || target === 0) return;
    let v = 0;
    const step = target / 120;
    const t = setInterval(() => {
      v += step;
      if (v >= target) { setCount(target); clearInterval(t); }
      else setCount(Math.floor(v));
    }, 16);
    return () => clearInterval(t);
  }, [started, target]);
  return <span>{prefix}{target === 0 ? 0 : count}{suffix}</span>;
}

export default function StatsStrip() {
  const ref = useRef(null);
  const [started, setStarted] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setStarted(true);
      }
    }, { threshold: 0.3 });
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section ref={ref} style={{
      background: "linear-gradient(180deg, #1a3528 0%, #152b1e 100%)",
      padding: "40px 20px",
      position: "relative", overflow: "hidden",
    }}>
      <style>{`
        @keyframes statReveal {
          from { opacity: 0; transform: translateY(40px) scale(0.9); }
          to   { opacity: 1; transform: translateY(0) scale(1); }
        }
        @keyframes orbFloat {
          0%,100% { transform: translate(0,0) scale(1); }
          50%     { transform: translate(10px,-20px) scale(1.05); }
        }
        @keyframes numberGlow {
          0%,100% { text-shadow: 0 0 20px rgba(0,184,148,0.3); }
          50%     { text-shadow: 0 0 60px rgba(0,184,148,0.8), 0 0 100px rgba(0,184,148,0.4); }
        }
      `}</style>

      {/* Background orbs */}
      <div style={{ position: "absolute", top: "20%", left: "10%", width: 300, height: 300, borderRadius: "50%", background: "radial-gradient(circle, rgba(0,184,148,0.06) 0%, transparent 70%)", animation: "orbFloat 8s ease-in-out infinite", pointerEvents: "none" }} />
      <div style={{ position: "absolute", bottom: "20%", right: "10%", width: 250, height: 250, borderRadius: "50%", background: "radial-gradient(circle, rgba(0,206,201,0.05) 0%, transparent 70%)", animation: "orbFloat 10s ease-in-out infinite reverse", pointerEvents: "none" }} />

      <div style={{ maxWidth: 1100, margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: 70 }}>
          <p style={{ color: "#00b894", fontSize: 12, fontWeight: 700, letterSpacing: 3, textTransform: "uppercase", marginBottom: 14 }}>Warum Sensalie?</p>
          <h2 style={{ fontFamily: "'Bricolage Grotesque', sans-serif", fontSize: "clamp(20px, 3.5vw, 36px)", fontWeight: 800, color: "#fff", letterSpacing: "-0.5px" }}>
            Wachstum durch Kunden, die wirklich hinter dir stehen.
          </h2>
        </div>

        <style>{`
          .stats-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; text-align: center; }
          .stat-card { padding: 20px 12px; }
          .stat-icon { font-size: 22px; margin-bottom: 10px; }
          .stat-number { font-size: clamp(28px, 5vw, 56px) !important; letter-spacing: -1px !important; }
          .stat-label { font-size: 10px !important; margin-top: 8px !important; line-height: 1.3 !important; }
          @media(min-width: 600px) {
            .stat-card { padding: 32px 24px; }
            .stat-icon { font-size: 28px; margin-bottom: 12px; }
            .stat-number { font-size: clamp(36px, 4vw, 56px) !important; }
            .stat-label { font-size: 12px !important; margin-top: 12px !important; }
          }
        `}</style>
        <div className="stats-grid">
          {stats.map((s, i) => (
            <div key={s.label} className="stat-card" style={{
              borderRadius: 28,
              background: `linear-gradient(135deg, ${s.color}0f, ${s.color}05)`,
              border: `1px solid ${s.color}28`,
              position: "relative", overflow: "hidden",
              opacity: started ? 1 : 0,
              transform: started ? "translateY(0) scale(1)" : "translateY(40px) scale(0.9)",
              transition: `opacity 0.7s ease ${0.1 + i * 0.18}s, transform 0.7s cubic-bezier(0.22,1,0.36,1) ${0.1 + i * 0.18}s`,
              borderRadius: 28,
              background: `linear-gradient(135deg, ${s.color}0f, ${s.color}05)`,
              border: `1px solid ${s.color}28`,
              position: "relative", overflow: "hidden",
            }}>
              <div style={{ position: "absolute", inset: 0, background: `radial-gradient(ellipse at 50% 0%, ${s.color}14 0%, transparent 60%)`, pointerEvents: "none" }} />

              <div className="stat-icon" style={{ position: "relative" }}>{s.icon}</div>
              <div className="stat-number" style={{
                fontFamily: "'Bricolage Grotesque', sans-serif",
                fontWeight: 800,
                color: s.color,
                lineHeight: 1,
                position: "relative",
                animation: started ? `numberGlow 2.5s ease-in-out ${i * 0.5}s infinite` : "none",
              }}>
                <CountUp target={s.value} prefix={s.prefix} suffix={s.suffix} started={started} />
              </div>
              <div className="stat-label" style={{ color: "rgba(255,255,255,0.45)", lineHeight: 1.5, position: "relative" }}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}