import React, { useEffect, useRef, useState } from "react";

export default function Footer() {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(([e]) => {if (e.isIntersecting) setVisible(true);}, { threshold: 0.1 });
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <footer ref={ref} style={{ background: "#05100a", borderTop: "1px solid rgba(0,184,148,0.08)", padding: "60px 28px 36px", position: "relative", overflow: "hidden" }}>
      <div style={{ maxWidth: 1100, margin: "0 auto", position: "relative", zIndex: 1 }}>
        <div style={{ textAlign: "center", marginBottom: 40 }}>
          <div style={{ fontFamily: "'Bricolage Grotesque', sans-serif", fontSize: "clamp(28px, 5vw, 58px)", fontWeight: 800, color: visible ? "#fff" : "transparent", letterSpacing: "-2px", opacity: visible ? 1 : 0, transform: visible ? "translateY(0)" : "translateY(30px)", transition: "all 1s ease 0.3s" }}>
            Sensalie<span style={{ color: "#00b894" }}>.</span>
          </div>
          <p style={{ color: "rgba(255,255,255,0.3)", fontSize: 14, marginTop: 10, opacity: visible ? 1 : 0, transform: visible ? "translateY(0)" : "translateY(20px)", transition: "all 1s ease 0.5s" }}>
            Wachstum durch Kunden, die wirklich hinter dir stehen.
          </p>
        </div>
        <div style={{ height: 1, background: "linear-gradient(90deg, transparent, rgba(0,184,148,0.2), transparent)", marginBottom: 28 }} />
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 16 }}>
          <span style={{ color: "rgba(255,255,255,0.25)", fontSize: 13 }}>© 2026 Sensalie · Alle Rechte vorbehalten</span>
          <div style={{ display: "flex", gap: 24 }}>
            {["Impressum", "Datenschutz"].map((l) =>
            <a key={l} href="#" style={{ color: "rgba(255,255,255,0.3)", fontSize: 13, textDecoration: "none", transition: "color 0.2s" }}
            onMouseEnter={(e) => e.currentTarget.style.color = "#00b894"}
            onMouseLeave={(e) => e.currentTarget.style.color = "rgba(255,255,255,0.3)"}>
              {l}</a>
            )}
          </div>
        </div>
      </div>
    </footer>);

}