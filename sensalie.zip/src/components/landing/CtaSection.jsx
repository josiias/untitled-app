import React from "react";

export default function CtaSection() {
  return (
    <section style={{ position: "relative", padding: "140px 28px 160px", overflow: "hidden" }}>
      <style>{`
        @keyframes ctaGlow { 0%,100%{opacity:0.6} 50%{opacity:1} }
        @keyframes ctaBtnPulse { 0%,100%{box-shadow:0 8px 40px rgba(0,184,148,0.3),0 0 0 0 rgba(0,184,148,0.4);} 50%{box-shadow:0 8px 60px rgba(0,184,148,0.5),0 0 0 14px rgba(0,184,148,0);} }
        .cta-btn-anim { animation: ctaBtnPulse 2.5s ease-in-out infinite; }
      `}</style>

      {/* Café evening background */}
      <img
        src="https://images.unsplash.com/photo-1514190051997-0f6f39ca5cde?w=1800&q=80"
        alt=""
        style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", objectPosition: "center 60%" }} />
      

      {/* Dark overlay with warm tint */}
      <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to bottom, rgba(4,12,8,0.82) 0%, rgba(4,16,10,0.75) 50%, rgba(2,10,6,0.92) 100%)" }} />

      {/* Warm teal glow in center */}
      <div style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%,-50%)", width: 700, height: 400, background: "radial-gradient(ellipse, rgba(0,184,148,0.18) 0%, transparent 65%)", animation: "ctaGlow 4s ease-in-out infinite", pointerEvents: "none" }} />

      <div style={{ position: "relative", zIndex: 2, maxWidth: 720, margin: "0 auto", textAlign: "center" }}>
        {/* Trust badge */}
        


        

        <h2 style={{ fontFamily: "'Bricolage Grotesque', sans-serif", fontSize: "clamp(32px, 5vw, 62px)", fontWeight: 800, color: "#fff", letterSpacing: "-1.5px", lineHeight: 1.1, marginBottom: 20 }}>
          Kostenlos starten.<br />
          <span style={{ color: "#00b894" }}>Kein Risiko. Kein Vertrag.</span>
        </h2>
        <p style={{ color: "rgba(255,255,255,0.5)", fontSize: 17, marginBottom: 48, lineHeight: 1.7 }}>
          Starte noch heute — in 2 Minuten eingerichtet.<br />
          Deine Kunden werden es lieben.
        </p>

        <a href="/waitlist" className="cta-btn-anim" style={{
          display: "inline-flex", alignItems: "center", gap: 12,
          background: "#00b894", color: "#fff", fontWeight: 700, fontSize: 17,
          padding: "20px 48px", borderRadius: 100, textDecoration: "none",
          transition: "all 0.2s"
        }}
        onMouseEnter={(e) => {e.currentTarget.style.background = "#00a07e";e.currentTarget.style.transform = "scale(1.04)";}}
        onMouseLeave={(e) => {e.currentTarget.style.background = "#00b894";e.currentTarget.style.transform = "scale(1)";}}>
          
          Jetzt kostenlos registrieren <span style={{ fontSize: 22 }}>→</span>
        </a>

        {/* Trust signals */}
        <div style={{ display: "flex", justifyContent: "center", gap: 28, marginTop: 40, flexWrap: "wrap" }}>
          {["✓ Keine Kreditkarte", "✓ Jederzeit kündbar", "✓ In 2 Min. startklar"].map((t) =>
          <span key={t} style={{ color: "rgba(255,255,255,0.4)", fontSize: 13, fontWeight: 500 }}>{t}</span>
          )}
        </div>
      </div>
    </section>);

}