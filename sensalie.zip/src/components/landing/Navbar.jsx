import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [user, setUser] = useState(null);

  useEffect(() => {
    base44.auth.me().then(u => setUser(u)).catch(() => {});
  }, []);

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", fn);
    return () => window.removeEventListener("scroll", fn);
  }, []);

  const navLinks = [];

  const scrollTo = (id) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@400;600;700;800&family=DM+Sans:wght@300;400;500;600&display=swap');
        .sensalie-nav a:hover { opacity: 1 !important; }
        .nav-links-desktop { display: flex; gap: 36px; }
        .nav-actions-desktop { display: flex; align-items: center; gap: 16px; }
        .hamburger-btn { display: none !important; }
        .mobile-menu { display: none; }
        @media (max-width: 768px) {
          .nav-links-desktop { display: none !important; }
          .nav-actions-desktop { display: none !important; }
          .hamburger-btn { display: flex !important; }
          .mobile-menu { display: flex !important; }
        }
      `}</style>
      <nav className="sensalie-nav" style={{
        position: "fixed", top: 0, left: 0, right: 0, zIndex: 100,
        background: scrolled || menuOpen ? "rgba(8,14,12,0.95)" : "transparent",
        backdropFilter: scrolled || menuOpen ? "blur(20px)" : "none",
        borderBottom: scrolled || menuOpen ? "1px solid rgba(0,184,148,0.12)" : "none",
        transition: "all 0.4s ease"
      }}>
        <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 20px", display: "flex", alignItems: "center", justifyContent: "space-between", height: 64 }}>
          {/* Logo */}
          <a href="/" style={{ textDecoration: "none", display: "flex", alignItems: "center", flexShrink: 0 }}>
            <span style={{ fontFamily: "'Bricolage Grotesque', sans-serif", fontSize: 22, fontWeight: 700, color: "#fff", letterSpacing: "-0.5px" }}>
              Sensalie<span style={{ color: "#00b894" }}>.</span>
            </span>
          </a>

          {/* Desktop links */}
          <div className="nav-links-desktop">
            {navLinks.map((l) => (
              <a key={l.label} href="#" onClick={(e) => { e.preventDefault(); scrollTo(l.id); }}
                style={{ color: "rgba(255,255,255,0.6)", fontSize: 14, fontWeight: 500, textDecoration: "none", transition: "color 0.2s" }}
                onMouseEnter={(e) => e.currentTarget.style.color = "#fff"}
                onMouseLeave={(e) => e.currentTarget.style.color = "rgba(255,255,255,0.6)"}>
                {l.label}
              </a>
            ))}
          </div>

          {/* Desktop actions */}
          <div className="nav-actions-desktop">
            <a href="/business"
              style={{ color: "rgba(255,255,255,0.65)", fontSize: 14, fontWeight: 500, textDecoration: "none", transition: "color 0.2s" }}
              onMouseEnter={(e) => e.currentTarget.style.color = "#fff"}
              onMouseLeave={(e) => e.currentTarget.style.color = "rgba(255,255,255,0.65)"}>
              Login
            </a>
            <a href="/waitlist"
              style={{ background: "#00b894", color: "#fff", fontWeight: 700, fontSize: 14, padding: "10px 22px", borderRadius: 100, textDecoration: "none", transition: "background 0.2s" }}
              onMouseEnter={(e) => e.currentTarget.style.background = "#00a07e"}
              onMouseLeave={(e) => e.currentTarget.style.background = "#00b894"}>
              Kostenlos starten
            </a>
          </div>

          {/* Hamburger button */}
          <button className="hamburger-btn" onClick={() => setMenuOpen(o => !o)}
            style={{ background: "none", border: "none", cursor: "pointer", padding: 8, flexDirection: "column", gap: 5 }}>
            <span style={{ display: "block", width: 22, height: 2, background: "#fff", borderRadius: 2, transition: "all 0.3s", transform: menuOpen ? "rotate(45deg) translate(5px,5px)" : "none" }} />
            <span style={{ display: "block", width: 22, height: 2, background: "#fff", borderRadius: 2, transition: "all 0.3s", opacity: menuOpen ? 0 : 1 }} />
            <span style={{ display: "block", width: 22, height: 2, background: "#fff", borderRadius: 2, transition: "all 0.3s", transform: menuOpen ? "rotate(-45deg) translate(5px,-5px)" : "none" }} />
          </button>
        </div>

        {/* Mobile menu */}
        {menuOpen && (
          <div className="mobile-menu" style={{ flexDirection: "column", padding: "16px 20px 24px", borderTop: "1px solid rgba(0,184,148,0.12)", gap: 4 }}>
            {navLinks.map((l) => (
              <a key={l.label} href="#" onClick={(e) => { e.preventDefault(); setMenuOpen(false); scrollTo(l.id); }}
                style={{ color: "rgba(255,255,255,0.7)", fontSize: 16, fontWeight: 500, textDecoration: "none", padding: "12px 0", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
                {l.label}
              </a>
            ))}
            <a href="/business" onClick={() => setMenuOpen(false)} style={{ color: "rgba(255,255,255,0.65)", fontSize: 16, fontWeight: 500, textDecoration: "none", padding: "12px 0", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>Login</a>
            <a href="/waitlist" style={{ background: "#00b894", color: "#fff", fontSize: 15, fontWeight: 600, padding: "13px 22px", borderRadius: 100, textDecoration: "none", textAlign: "center", marginTop: 12 }}>Kostenlos starten</a>
          </div>
        )}
      </nav>
    </>
  );
}