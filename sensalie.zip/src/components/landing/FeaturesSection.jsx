import React, { useEffect, useRef, useState } from "react";

const cards = [
  {
    icon: "🎫", title: "Digitale Stempelkarte", label: "7 / 10 Stempel", accent: "#00b894",
    bg: "https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=1400&q=85",
    visual: (
      <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 16 }}>
        {Array.from({ length: 10 }).map((_, i) => (
          <div key={i} style={{ width: 30, height: 30, borderRadius: 8, background: i < 7 ? "rgba(0,184,148,0.9)" : "rgba(255,255,255,0.07)", border: `1.5px solid ${i < 7 ? "#00b894" : "rgba(255,255,255,0.1)"}`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, color: "#fff", fontWeight: 700 }}>{i < 7 ? "✓" : ""}</div>
        ))}
      </div>
    ),
  },
  {
    icon: "📢", title: "Empfehlungen tracken", label: "Wer bringt die meisten Kunden?", accent: "#00cec9",
    bg: "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=1400&q=85",
    visual: (
      <div style={{ marginTop: 16 }}>
        {[{ name: "Mehmet B.", count: 4, color: "#00b894" }, { name: "Sara K.", count: 2, color: "#00cec9" }, { name: "Luisa M.", count: 1, color: "#55efc4" }].map(r => (
          <div key={r.name} style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
            <div style={{ width: 28, height: 28, borderRadius: "50%", background: "rgba(255,255,255,0.1)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, color: "rgba(255,255,255,0.6)", flexShrink: 0, fontWeight: 700 }}>{r.name[0]}</div>
            <div style={{ flex: 1 }}><div style={{ height: 7, borderRadius: 100, background: "rgba(255,255,255,0.07)", overflow: "hidden" }}><div style={{ height: "100%", width: `${r.count * 25}%`, background: r.color, borderRadius: 100 }} /></div></div>
            <span style={{ color: r.color, fontSize: 12, fontWeight: 700, minWidth: 16 }}>{r.count}</span>
          </div>
        ))}
      </div>
    ),
  },
  {
    icon: "💰", title: "Provisionen automatisch", label: "Nur bei echtem Umsatz", accent: "#55efc4",
    bg: "https://images.unsplash.com/photo-1543269865-cbf427effbad?w=1400&q=85",
    visual: (
      <div style={{ marginTop: 16, display: "flex", flexDirection: "column", gap: 8 }}>
        {["+12,50 €", "+8,00 €", "+21,00 €"].map((v, i) => (
          <div key={i} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", background: "rgba(0,184,148,0.08)", border: "1px solid rgba(0,184,148,0.18)", borderRadius: 10, padding: "8px 14px" }}>
            <span style={{ color: "rgba(255,255,255,0.45)", fontSize: 11 }}>Automatisch ausgezahlt</span>
            <span style={{ color: "#55efc4", fontSize: 15, fontWeight: 700 }}>{v}</span>
          </div>
        ))}
      </div>
    ),
  },
  {
    icon: "📊", title: "Echtzeit-Übersicht", label: "Umsatz auf einen Blick", accent: "#00b894",
    bg: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=1400&q=85",
    visual: (
      <div style={{ marginTop: 16, display: "flex", alignItems: "flex-end", gap: 5, height: 56 }}>
        {[40, 65, 45, 80, 60, 90, 75].map((h, i) => (
          <div key={i} style={{ flex: 1, borderRadius: 5, background: `rgba(0,184,148,${0.25 + (h / 100) * 0.7})`, height: `${h}%`, boxShadow: h > 70 ? "0 0 12px rgba(0,184,148,0.4)" : "none" }} />
        ))}
      </div>
    ),
  },
];

function FeatureCard({ card, index }) {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);
  const [hovered, setHovered] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(([e]) => { if (e.isIntersecting) setVisible(true); }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  const fromStyles = [
    "translateX(-70px) scale(0.93)",
    "translateX(70px) scale(0.93)",
    "translateY(70px) rotate(-2deg) scale(0.93)",
    "translateY(70px) rotate(2deg) scale(0.93)",
  ];

  return (
    <div
      ref={ref}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        position: "relative", borderRadius: 22, overflow: "hidden",
        border: `1.5px solid ${hovered ? card.accent + "66" : card.accent + "28"}`,
        opacity: visible ? 1 : 0,
        transform: visible ? "translate(0) rotate(0) scale(1)" : fromStyles[index % 4],
        transition: `all 0.9s cubic-bezier(0.22,1,0.36,1) ${index * 0.1}s`,
        boxShadow: hovered ? `0 20px 70px ${card.accent}25, 0 0 0 1px ${card.accent}22` : "none",
        cursor: "default",
      }}
    >
      {/* Full background image — strong presence */}
      <img
        src={card.bg}
        alt=""
        style={{
          position: "absolute", inset: 0, width: "100%", height: "100%",
          objectFit: "cover",
          opacity: hovered ? 0.38 : 0.22,
          transition: "opacity 0.6s ease",
          pointerEvents: "none",
          transform: hovered ? "scale(1.04)" : "scale(1)",
          transitionProperty: "opacity, transform",
          transitionDuration: "0.7s",
        }}
      />
      {/* Accent glow top */}
      <div style={{ position: "absolute", inset: 0, background: `radial-gradient(ellipse at 50% -10%, ${card.accent}30 0%, transparent 60%)`, pointerEvents: "none" }} />
      {/* Dark overlay — lighter on hover to show more image */}
      <div style={{ position: "absolute", inset: 0, background: hovered ? "linear-gradient(160deg, rgba(10,22,14,0.78), rgba(6,14,9,0.7))" : "linear-gradient(160deg, rgba(10,22,14,0.92), rgba(6,14,9,0.88))", transition: "background 0.5s ease", pointerEvents: "none" }} />

      <div style={{ position: "relative", zIndex: 1, padding: "24px 20px" }}>
        <div style={{ width: 50, height: 50, borderRadius: 15, background: `${card.accent}20`, border: `1.5px solid ${card.accent}40`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, marginBottom: 18 }}>{card.icon}</div>
        <h3 style={{ color: "#fff", fontSize: 18, fontWeight: 700, marginBottom: 5, fontFamily: "'Bricolage Grotesque', sans-serif" }}>{card.title}</h3>
        <p style={{ color: "rgba(255,255,255,0.4)", fontSize: 12, fontWeight: 500, marginBottom: 0 }}>{card.label}</p>
        {card.visual}
      </div>
    </div>
  );
}

export default function FeaturesSection() {
  const sectionRef = useRef(null);
  const [scrollRatio, setScrollRatio] = useState(0);

  useEffect(() => {
    const onScroll = () => {
      if (!sectionRef.current) return;
      const rect = sectionRef.current.getBoundingClientRect();
      const height = sectionRef.current.offsetHeight;
      const progress = Math.max(0, Math.min(1, (-rect.top + window.innerHeight * 0.5) / height));
      setScrollRatio(progress);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Warm forest → teal shift as you scroll through
  const bgR = Math.round(8  + scrollRatio * 6);
  const bgG = Math.round(18 + scrollRatio * 48);
  const bgB = Math.round(14 + scrollRatio * 40);

  return (
    <section id="Funktionen" ref={sectionRef} style={{ background: `rgb(${bgR},${bgG},${bgB})`, padding: "110px 28px", position: "relative", overflow: "hidden", transition: "background 0.3s ease" }}>
      {/* Subtle atmosphere layer */}
      <img
        src="https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?w=1800&q=70"
        alt=""
        style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", opacity: 0.04 + scrollRatio * 0.06, pointerEvents: "none", transition: "opacity 0.4s ease" }}
      />
      <div style={{ position: "absolute", inset: 0, pointerEvents: "none", backgroundImage: "linear-gradient(rgba(0,184,148,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(0,184,148,0.03) 1px, transparent 1px)", backgroundSize: "60px 60px", opacity: 0.6 + scrollRatio * 0.4 }} />

      <div style={{ maxWidth: 940, margin: "0 auto", position: "relative", zIndex: 1 }}>
        <div style={{ textAlign: "center", marginBottom: 64 }}>
          <p style={{ color: "#00b894", fontSize: 12, fontWeight: 700, letterSpacing: 3, textTransform: "uppercase", marginBottom: 14 }}>Funktionen</p>
          <h2 style={{ fontFamily: "'Bricolage Grotesque', sans-serif", fontSize: "clamp(28px, 4vw, 50px)", fontWeight: 800, color: "#fff", letterSpacing: "-1px", marginBottom: 12 }}>Alles was du brauchst.</h2>
          <p style={{ color: "rgba(255,255,255,0.4)", fontSize: 15 }}>Kein Aufwand. Keine Werbung. Nur echtes Wachstum.</p>
        </div>
        <style>{`
          .features-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 16px;
          }
          @media(min-width: 600px) {
            .features-grid { grid-template-columns: repeat(2, 1fr); gap: 20px; }
          }
          @media(min-width: 900px) {
            .features-grid { grid-template-columns: repeat(2, 1fr); gap: 22px; }
          }
        `}</style>
        <div className="features-grid">
          {cards.map((card, i) => <FeatureCard key={i} card={card} index={i} />)}
        </div>
      </div>
    </section>
  );
}