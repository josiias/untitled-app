import React, { useState, useEffect } from "react";

const slides = [
{ label: "Für Barbershops", url: "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?w=1600&q=80" },
{ label: "Für Massagestudios", url: "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=1600&q=80" },
{ label: "Für Nagelstudios", url: "https://images.unsplash.com/photo-1604654894610-df63bc536371?w=1600&q=80" },
{ label: "Für Kosmetikstudios", url: "https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?w=1600&q=80" },
{ label: "Für Cafés & Bäckereien", url: "https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=1600&q=80" }];


const trustItems = [
{ icon: "📈", label: "Mehr Umsatz" },
{ icon: "👥", label: "Mehr Kunden" },
{ icon: "❤️", label: "Stärkere Bindung" }];


export default function HeroSection() {
  const [current, setCurrent] = useState(0);
  const [fading, setFading] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setFading(true);
      setTimeout(() => {
        setCurrent((c) => (c + 1) % slides.length);
        setFading(false);
      }, 800);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section style={{ position: "relative", minHeight: "100vh", overflow: "hidden", display: "flex", alignItems: "center", justifyContent: "center" }}>
      <style>{`
        @keyframes kenburns {
          0% { transform: scale(1) translateX(0) translateY(0); }
          50% { transform: scale(1.07) translateX(-1%) translateY(-1%); }
          100% { transform: scale(1) translateX(0) translateY(0); }
        }
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(40px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes bounceDot {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-8px); }
        }
        @keyframes ctaPulse {
          0%,100% { box-shadow: 0 0 0 0 rgba(0,184,148,0.5); }
          50% { box-shadow: 0 0 0 12px rgba(0,184,148,0); }
        }
        .hero-img { animation: kenburns 20s ease-in-out infinite; }
        .hero-content { animation: fadeInUp 1s ease both; }
        .bounce-dot { animation: bounceDot 2s ease-in-out infinite; }
      `}</style>

      {/* Background slideshow */}
      <div style={{ position: "absolute", inset: 0, overflow: "hidden" }}>
        <img
          src={slides[current].url}
          alt=""
          className="hero-img"
          style={{
            width: "100%", height: "100%", objectFit: "cover",
            opacity: fading ? 0 : 1,
            transition: "opacity 1.2s ease-in-out",
            transformOrigin: "center center"
          }} />
        
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to bottom, rgba(8,14,12,0.6) 0%, rgba(8,14,12,0.5) 50%, rgba(8,14,12,0.92) 100%)" }} />
      </div>

      {/* Content — fully centred */}
      <div className="hero-content" style={{ position: "relative", zIndex: 10, width: "100%", maxWidth: 760, margin: "0 auto", padding: "0 20px", paddingTop: 90, display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center", boxSizing: "border-box" }}>

        {/* Pill label */}
        <div style={{
          display: "inline-flex", alignItems: "center", gap: 8,
          background: "rgba(0,184,148,0.15)", border: "1px solid rgba(0,184,148,0.3)",
          borderRadius: 100, padding: "6px 16px", marginBottom: 40,
          color: "#00b894", fontSize: 13, fontWeight: 600,
          transition: "opacity 0.5s",
          opacity: fading ? 0 : 1,
          maxWidth: "100%"
        }}>
          <span style={{ width: 7, height: 7, borderRadius: "50%", background: "#00b894", display: "inline-block", flexShrink: 0 }} />
          {slides[current].label}
        </div>

        {/* Headline */}
        <h1 style={{ fontFamily: "'Bricolage Grotesque', sans-serif", fontSize: "clamp(26px, 4.5vw, 62px)", fontWeight: 800, lineHeight: 1.15, letterSpacing: "-0.5px", color: "#fff", marginBottom: 40, maxWidth: 900 }}>
          Wachstum durch Kunden,{" "}
          <br />
          die wirklich hinter dir{" "}
          <span style={{ color: "#00b894" }}>stehen.</span>
        </h1>

        {/* Buttons */}
        <div style={{ display: "flex", gap: 20, flexWrap: "wrap", justifyContent: "center", marginBottom: 40, width: "100%" }}>
          <a href="/waitlist" style={{ background: "#00b894", color: "#fff", fontWeight: 700, fontSize: 15, padding: "13px 26px", borderRadius: 100, textDecoration: "none", display: "flex", alignItems: "center", gap: 8, transition: "all 0.2s", animation: "ctaPulse 2.5s ease-in-out infinite", boxShadow: "0 0 0 0 rgba(0,184,148,0.5)" }}
          onMouseEnter={(e) => {e.currentTarget.style.background = "#00a07e";}}
          onMouseLeave={(e) => {e.currentTarget.style.background = "#00b894";}}>
            
            Kostenlos starten <span style={{ fontSize: 18 }}>→</span>
          </a>
          <a href="#" onClick={(e) => { e.preventDefault(); document.getElementById('how')?.scrollIntoView({ behavior: 'smooth' }); }} style={{ border: "1px solid rgba(255,255,255,0.25)", color: "#fff", fontWeight: 600, fontSize: 15, padding: "13px 26px", borderRadius: 100, textDecoration: "none", display: "flex", alignItems: "center", gap: 8, backdropFilter: "blur(8px)", transition: "all 0.2s" }}
          onMouseEnter={(e) => {e.currentTarget.style.borderColor = "rgba(255,255,255,0.5)";e.currentTarget.style.background = "rgba(255,255,255,0.05)";}}
          onMouseLeave={(e) => {e.currentTarget.style.borderColor = "rgba(255,255,255,0.25)";e.currentTarget.style.background = "transparent";}}>
            So funktioniert's
          </a>
        </div>


      </div>

      {/* Bottom fade */}
      <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, height: 160, background: "linear-gradient(to top, #080e0c, transparent)" }} />
    </section>);

}