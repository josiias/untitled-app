import React from "react";
import { BarChart3, Users, Star, Ticket, Settings, TrendingUp, ArrowUpRight } from "lucide-react";

const sidebarItems = [
  { icon: BarChart3, label: "Übersicht", active: true },
  { icon: Users, label: "Kunden", active: false },
  { icon: Star, label: "Empfehlungen", active: false },
  { icon: Ticket, label: "Stempelkarten", active: false },
  { icon: Settings, label: "Einstellungen", active: false },
];

const metrics = [
  { label: "Umsatz", value: "€4.280", change: "+12%", up: true },
  { label: "Kunden", value: "847", change: "+8%", up: true },
  { label: "Empfehlungen", value: "234", change: "+24%", up: true },
  { label: "Provisionen", value: "€1.120", change: "+18%", up: true },
];

export default function DashboardMockup() {
  return (
    <div className="relative w-full max-w-4xl mx-auto">
      {/* Teal glow behind device */}
      <div className="absolute inset-0 -inset-x-12 -bottom-8 bg-primary/15 blur-3xl rounded-full" />

      {/* Device frame */}
      <div className="relative rounded-2xl lg:rounded-3xl overflow-hidden border border-white/10 shadow-2xl shadow-black/40">
        {/* Top bar of device */}
        <div className="bg-black/80 backdrop-blur-xl px-4 py-2 flex items-center gap-2 border-b border-white/5">
          <div className="flex gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-red-400/80" />
            <div className="w-2.5 h-2.5 rounded-full bg-yellow-400/80" />
            <div className="w-2.5 h-2.5 rounded-full bg-green-400/80" />
          </div>
          <div className="flex-1 mx-8">
            <div className="bg-white/5 rounded-md px-3 py-1 text-center">
              <span className="text-white/30 text-[10px] font-inter">app.sensalie.com/dashboard</span>
            </div>
          </div>
        </div>

        {/* Dashboard content */}
        <div className="flex bg-[#0d1117]">
          {/* Sidebar */}
          <div className="hidden sm:flex flex-col w-44 bg-black/40 backdrop-blur-xl border-r border-white/5 py-4 px-3 gap-1">
            <div className="px-2 mb-4">
              <span className="text-white font-bold text-xs tracking-tight">Sensalie.</span>
            </div>
            {sidebarItems.map((item) => (
              <div
                key={item.label}
                className={`flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-xs font-medium transition-colors ${
                  item.active
                    ? "bg-primary/15 text-primary"
                    : "text-white/40 hover:text-white/60"
                }`}
              >
                <item.icon className="w-3.5 h-3.5" />
                <span>{item.label}</span>
              </div>
            ))}
          </div>

          {/* Main area */}
          <div className="flex-1 p-4 lg:p-6 min-h-[220px] lg:min-h-[300px]">
            {/* Greeting */}
            <div className="mb-4 lg:mb-6">
              <h3 className="text-white text-sm lg:text-base font-semibold">
                Willkommen zurück, Marco 👋
              </h3>
              <p className="text-white/40 text-[10px] lg:text-xs mt-0.5">
                Barbier Studio · Pro Plan
              </p>
            </div>

            {/* Metric cards */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 lg:gap-3">
              {metrics.map((m) => (
                <div
                  key={m.label}
                  className="bg-white/[0.04] backdrop-blur-sm border border-white/[0.06] rounded-xl p-3 lg:p-4"
                >
                  <p className="text-white/40 text-[9px] lg:text-[10px] uppercase tracking-wider font-medium">
                    {m.label}
                  </p>
                  <p className="text-white text-base lg:text-xl font-bold mt-1">{m.value}</p>
                  <div className="flex items-center gap-1 mt-1.5">
                    <ArrowUpRight className="w-2.5 h-2.5 text-primary" />
                    <span className="text-primary text-[9px] lg:text-[10px] font-medium">{m.change}</span>
                  </div>
                </div>
              ))}
            </div>

            {/* Mini chart placeholder */}
            <div className="mt-3 lg:mt-4 bg-white/[0.03] border border-white/[0.06] rounded-xl p-3 lg:p-4">
              <div className="flex items-center justify-between mb-3">
                <span className="text-white/60 text-[10px] lg:text-xs font-medium">Empfehlungen · Letzte 30 Tage</span>
                <TrendingUp className="w-3 h-3 text-primary" />
              </div>
              <div className="flex items-end gap-1 h-10 lg:h-14">
                {[35, 50, 40, 65, 55, 80, 70, 90, 75, 95, 85, 100].map((h, i) => (
                  <div
                    key={i}
                    className="flex-1 rounded-sm bg-primary/30"
                    style={{ height: `${h}%` }}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Glass shadow beneath */}
      <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 w-3/4 h-12 bg-primary/10 blur-2xl rounded-full" />
    </div>
  );
}