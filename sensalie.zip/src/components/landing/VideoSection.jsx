import React, { useState } from "react";

export default function VideoSection() {
  const [hovered, setHovered] = useState(false);

  return (
    <section style={{
      background: "linear-gradient(135deg, #080e0c 0%, #0d1f15 40%, #0a1a18 70%, #080e0c 100%)",
      padding: "80px 28px",
      position: "relative",
      overflow: "hidden",
    }}>
      {/* Decorative color blobs */}
      <div style={{ position: "absolute", top: "10%", left: "5%", width: 300, height: 300, borderRadius: "50%", background: "radial-gradient(circle, rgba(0,184,148,0.12) 0%, transparent 70%)", pointerEvents: "none" }} />
      <div style={{ position: "absolute", bottom: "10%", right: "5%", width: 250, height: 250, borderRadius: "50%", background: "radial-gradient(circle, rgba(0,206,201,0.10) 0%, transparent 70%)", pointerEvents: "none" }} />
      <div style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%,-50%)", width: 600, height: 400, borderRadius: "50%", background: "radial-gradient(ellipse, rgba(85,239,196,0.06) 0%, transparent 70%)", pointerEvents: "none" }} />

      <div style={{ maxWidth: 620, margin: "0 auto", textAlign: "center", position: "relative", zIndex: 1 }}>
        <p style={{ color: "#00b894", fontSize: 12, fontWeight: 700, letterSpacing: 3, textTransform: "uppercase", marginBottom: 14 }}>So funktioniert Sensalie</p>
        <h2 style={{ fontFamily: "'Bricolage Grotesque', sans-serif", fontSize: "clamp(24px, 3.5vw, 40px)", fontWeight: 800, color: "#fff", letterSpacing: "-1px", marginBottom: 36 }}>
          Sieh es in Aktion.
        </h2>

        {/* Video player */}
        <div
          onMouseEnter={() => setHovered(true)}
          onMouseLeave={() => setHovered(false)}
          style={{
            position: "relative",
            borderRadius: 18,
            overflow: "hidden",
            border: `2px solid ${hovered ? "rgba(0,184,148,0.7)" : "rgba(0,184,148,0.3)"}`,
            boxShadow: hovered
              ? "0 0 80px rgba(0,184,148,0.3), 0 20px 60px rgba(0,0,0,0.5)"
              : "0 0 40px rgba(0,184,148,0.12), 0 20px 40px rgba(0,0,0,0.4)",
            cursor: "pointer",
            transition: "all 0.3s ease",
            aspectRatio: "16/9",
          }}
        >
          {/* Background image */}
          <img
            src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=1200&q=80"
            alt="Dashboard Preview"
            style={{ width: "100%", height: "100%", objectFit: "cover", position: "absolute", inset: 0, opacity: 0.4, transition: "opacity 0.3s ease" }}
          />

          {/* Overlay tint */}
          <div style={{ position: "absolute", inset: 0, background: "linear-gradient(135deg, rgba(8,20,14,0.7) 0%, rgba(0,184,148,0.1) 100%)" }} />

          {/* Play button */}
          <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 14 }}>
            <div style={{
              width: 64, height: 64, borderRadius: "50%",
              background: hovered ? "#00b894" : "rgba(0,184,148,0.15)",
              border: "2px solid #00b894",
              display: "flex", alignItems: "center", justifyContent: "center",
              transition: "all 0.3s ease",
              boxShadow: hovered ? "0 0 50px rgba(0,184,148,0.6)" : "0 0 20px rgba(0,184,148,0.2)",
            }}>
              <div style={{ width: 0, height: 0, borderTop: "10px solid transparent", borderBottom: "10px solid transparent", borderLeft: `18px solid ${hovered ? "#fff" : "#00b894"}`, marginLeft: 4 }} />
            </div>
            <p style={{ color: "rgba(255,255,255,0.6)", fontSize: 13 }}>2 Minuten — alles erklärt.</p>
          </div>
        </div>
      </div>
    </section>
  );
}