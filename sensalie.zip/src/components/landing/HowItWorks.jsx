import React, { useEffect, useRef, useState } from "react";

const steps = [
  {
    num: "01", icon: "⚙️", title: "Du richtest es ein",
    text: "Du legst deine Stempelkarte in wenigen Minuten an — Anzahl der Stempel, Belohnung, Provision. Einmal eingestellt, läuft es von alleine.",
    color: "#00b894",
    bg: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=1600&q=85",
  },
  {
    num: "02", icon: "📱", title: "Dein Kunde scannt",
    text: "Beim nächsten Besuch scannt dein Kunde einfach deinen QR-Code — kein Download, kein Aufwand. Die Stempelkarte ist sofort aktiv.",
    color: "#00cec9",
    bg: "https://images.unsplash.com/photo-1512909006721-3d6018887383?w=1600&q=85",
  },
  {
    num: "03", icon: "📢", title: "Er empfiehlt dich weiter",
    text: "Mit einem Klick schickt dein Kunde seinen persönlichen Link an Freunde und Familie — direkt über WhatsApp. Kein Aufwand für dich.",
    color: "#55efc4",
    bg: "https://images.unsplash.com/photo-1611605698335-8b1569810432?w=1600&q=85",
  },
  {
    num: "04", icon: "🚶", title: "Neuer Kunde betritt deinen Laden",
    text: "Der empfohlene Freund kommt zu dir, scannt den Code und startet seine eigene Karte. Du gewinnst einen neuen Stammkunden — automatisch.",
    color: "#00b894",
    bg: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=1600&q=85",
  },
  {
    num: "05", icon: "💰", title: "Du zahlst erst bei Erfolg",
    text: "Erst wenn der neue Kunde wirklich da war, löst die Provision aus. Kein Risiko, keine Vorabkosten — du zahlst nur für echte Ergebnisse.",
    color: "#00cec9",
    bg: "https://images.unsplash.com/photo-1553729459-efe14ef6055d?w=1600&q=85",
  },
  {
    num: "06", icon: "♾️", title: "Das System arbeitet für dich",
    text: "Jeder neue Kunde empfiehlt weiter. Der Kreislauf dreht sich — ohne dass du etwas tun musst. Dein Wachstum passiert im Hintergrund.",
    color: "#55efc4",
    bg: "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=1600&q=85",
  },
];

// Each step uses scroll-based full-background reveal
function StepCard({ step, index }) {
  const ref = useRef(null);
  const [ratio, setRatio] = useState(0); // 0–1 how much in view
  const isRight = index % 2 === 1;

  useEffect(() => {
    const onScroll = () => {
      if (!ref.current) return;
      const rect = ref.current.getBoundingClientRect();
      const r = Math.max(0, Math.min(1, (window.innerHeight - rect.top) / (window.innerHeight * 0.7)));
      setRatio(r);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const visible = ratio > 0.1;
  const imgOpacity = Math.min(0.72, ratio * 0.9); // image gets very visible as card enters

  return (
    <div
      ref={ref}
      style={{
        display: "flex",
        flexDirection: isRight ? "row-reverse" : "row",
        alignItems: "stretch",
        gap: 0,
        borderRadius: 24,
        overflow: "hidden",
        border: `1.5px solid ${step.color}${visible ? "44" : "11"}`,
        boxShadow: visible ? `0 0 60px ${step.color}18, 0 20px 60px rgba(0,0,0,0.4)` : "none",
        opacity: visible ? 1 : 0,
        transform: visible ? "translateX(0) scale(1)" : `translateX(${isRight ? 60 : -60}px) scale(0.95)`,
        transition: "all 0.9s cubic-bezier(0.22,1,0.36,1)",
        minHeight: 200,
        position: "relative",
      }}
    >
      {/* Full background image behind entire card */}
      <img
        src={step.bg}
        alt=""
        style={{
          position: "absolute", inset: 0, width: "100%", height: "100%",
          objectFit: "cover", objectPosition: "center",
          opacity: imgOpacity,
          transition: "opacity 0.5s ease",
          pointerEvents: "none",
        }}
      />
      {/* Gradient overlay that darkens edges */}
      <div style={{ position: "absolute", inset: 0, background: `linear-gradient(${isRight ? "270deg" : "90deg"}, rgba(6,14,9,0.92) 0%, rgba(6,14,9,0.55) 50%, rgba(6,14,9,0.75) 100%)`, pointerEvents: "none" }} />
      {/* Color tint */}
      <div style={{ position: "absolute", inset: 0, background: `radial-gradient(ellipse at ${isRight ? "80%" : "20%"} 50%, ${step.color}15 0%, transparent 65%)`, pointerEvents: "none" }} />

      {/* Step number badge */}
      <div style={{
        position: "relative", zIndex: 2,
        width: 100, flexShrink: 0,
        display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
        padding: "28px 0",
        borderRight: isRight ? "none" : `1px solid ${step.color}20`,
        borderLeft: isRight ? `1px solid ${step.color}20` : "none",
      }}>
        <span style={{ fontSize: 36, marginBottom: 8 }}>{step.icon}</span>
        <span style={{ fontFamily: "'Bricolage Grotesque', sans-serif", fontSize: 13, fontWeight: 800, color: step.color, letterSpacing: 1 }}>{step.num}</span>
      </div>

      {/* Content */}
      <div style={{
        position: "relative", zIndex: 2,
        flex: 1, padding: "32px 32px",
        display: "flex", flexDirection: "column", justifyContent: "center",
        textAlign: isRight ? "right" : "left",
      }}>
        <h3 style={{ fontFamily: "'Bricolage Grotesque', sans-serif", fontSize: "clamp(18px, 2.2vw, 26px)", fontWeight: 800, color: "#fff", marginBottom: 10, letterSpacing: "-0.5px" }}>{step.title}</h3>
        <p style={{ color: "rgba(255,255,255,0.5)", fontSize: 15, lineHeight: 1.7, margin: 0 }}>{step.text}</p>
      </div>
    </div>
  );
}

export default function HowItWorks() {
  const sectionRef = useRef(null);
  const [scrollRatio, setScrollRatio] = useState(0);

  useEffect(() => {
    const onScroll = () => {
      if (!sectionRef.current) return;
      const rect = sectionRef.current.getBoundingClientRect();
      const total = sectionRef.current.offsetHeight;
      const progress = Math.max(0, Math.min(1, (-rect.top + window.innerHeight * 0.4) / total));
      setScrollRatio(progress);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const bgL = `hsl(${150 + scrollRatio * 14}, ${28 + scrollRatio * 32}%, ${4 + scrollRatio * 9}%)`;
  const bgR = `hsl(${162 + scrollRatio * 14}, ${38 + scrollRatio * 22}%, ${6 + scrollRatio * 10}%)`;

  return (
    <section id="how" ref={sectionRef} style={{ background: `linear-gradient(160deg, ${bgL} 0%, ${bgR} 100%)`, padding: "120px 28px 150px", position: "relative", overflow: "hidden", transition: "background 0.3s ease" }}>
      <style>{`@keyframes floatOrb { 0%,100%{transform:translate(0,0) scale(1);} 50%{transform:translate(18px,-28px) scale(1.07);} }`}</style>

      {/* Atmosphere background image */}
      <img
        src="https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?w=1800&q=70"
        alt=""
        style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", opacity: 0.03 + scrollRatio * 0.05, pointerEvents: "none" }}
      />

      <div style={{ position: "absolute", top: "10%", right: "-60px", width: 440, height: 440, borderRadius: "50%", background: `radial-gradient(circle, rgba(0,184,148,${0.04 + scrollRatio * 0.13}) 0%, transparent 70%)`, animation: "floatOrb 12s ease-in-out infinite", pointerEvents: "none" }} />
      <div style={{ position: "absolute", bottom: "10%", left: "-60px", width: 320, height: 320, borderRadius: "50%", background: `radial-gradient(circle, rgba(0,206,201,${0.04 + scrollRatio * 0.1}) 0%, transparent 70%)`, animation: "floatOrb 9s ease-in-out infinite reverse", pointerEvents: "none" }} />

      <div style={{ textAlign: "center", marginBottom: 80 }}>
        <p style={{ color: "#00b894", fontSize: 12, fontWeight: 700, letterSpacing: 3, textTransform: "uppercase", marginBottom: 14 }}>So geht's</p>
        <h2 style={{ fontFamily: "'Bricolage Grotesque', sans-serif", fontSize: "clamp(28px, 4vw, 50px)", fontWeight: 800, color: "#fff", letterSpacing: "-1px" }}>In 6 Schritten zum Wachstum.</h2>
        <p style={{ color: "rgba(255,255,255,0.35)", fontSize: 14, marginTop: 12 }}>Scroll dich durch — und sieh sofort, was passiert.</p>
      </div>

      <div style={{ maxWidth: 760, margin: "0 auto", display: "flex", flexDirection: "column", gap: 28, position: "relative" }}>
        {/* Connecting line */}
        <div style={{ position: "absolute", left: "50%", top: 0, bottom: 0, width: 1, background: "linear-gradient(to bottom, transparent, rgba(0,184,148,0.15) 20%, rgba(0,184,148,0.15) 80%, transparent)", transform: "translateX(-50%)", pointerEvents: "none" }} />
        {steps.map((step, i) => <StepCard key={i} step={step} index={i} />)}
      </div>
    </section>
  );
}