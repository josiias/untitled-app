// BenefitsReveal is now handled inside DashboardSection as a scroll-driven overlay.
// This component is intentionally minimal — it just provides a smooth transition bridge.
import React from "react";

export default function BenefitsReveal() {
  return null; // Logic moved into DashboardSection for scroll-driven sequence
}