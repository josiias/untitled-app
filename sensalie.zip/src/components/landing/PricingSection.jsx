import React, { useEffect, useRef, useState } from "react";

const plans = [
  {
    name: "Free", price: "0€", period: "", badge: null,
    features: [
      { text: "1 Stempelkarte", included: true },
      { text: "QR-Code Generator", included: true },
      { text: "Basis-Statistiken", included: true },
      { text: "1 Provision (14 Tage testbar)", included: true },
      { text: "Empfehlungs-Tracking", included: false },
      { text: "Mehrere Provisionen", included: false },
      { text: "Credits für Sichtbarkeit", included: false },
    ],
    highlight: false, pro: false,
  },
  {
    name: "Plus", price: "9,90€", period: "/Monat", badge: "Beliebt",
    features: [
      { text: "2 Stempelkarten", included: true },
      { text: "QR-Code Generator", included: true },
      { text: "Empfehlungs-Tracking", included: true },
      { text: "1 aktive Provision", included: true },
      { text: "Echtzeit-Dashboard", included: true },
      { text: "WhatsApp Integration", included: true },
      { text: "Basis-Statistiken", included: true },
      { text: "Mehrere Provisionen gleichzeitig", included: false },
      { text: "Sonderprovisionen für Aktionszeiträume", included: false },
      { text: "Credits für Sichtbarkeit", included: false },
    ],
    highlight: true, pro: false,
  },
  {
    name: "Pro", price: "14,99€", period: "/Monat", badge: "Premium",
    features: [
      { text: "Unbegrenzte Stempelkarten", included: true },
      { text: "QR-Code Generator", included: true },
      { text: "Empfehlungs-Tracking", included: true },
      { text: "Mehrere Provisionen gleichzeitig", included: true },
      { text: "Sonderprovisionen für Aktionszeiträume", included: true },
      { text: "1 kostenloser Credit / Monat", included: true },
      { text: "Echtzeit-Dashboard", included: true },
      { text: "WhatsApp Integration", included: true },
      { text: "Prioritäts-Support", included: true },
    ],
    highlight: false, pro: true,
  },
];

const STANDARD_BG = "https://images.unsplash.com/photo-1556761175-b413da4baf72?w=1400&q=80";

export default function PricingSection() {
  const ref = useRef(null);
  const [freeVisible, setFreeVisible] = useState(false);
  const [proVisible, setProVisible] = useState(false);
  const [standardVisible, setStandardVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) {
        // Free appears immediately
        setFreeVisible(true);
        // Pro appears shortly after
        setTimeout(() => setProVisible(true), 400);
        // Standard drops in last with a wow effect
        setTimeout(() => setStandardVisible(true), 900);
      }
    }, { threshold: 0.1 });
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="Preise" ref={ref} style={{ position: "relative", padding: "100px 28px 120px", overflow: "hidden" }}>
      <style>{`
        @keyframes badgePulse { 0%,100%{box-shadow:0 0 0 0 rgba(0,184,148,0.5);} 50%{box-shadow:0 0 0 10px rgba(0,184,148,0);} }
        @keyframes goldGlow { 0%,100%{box-shadow:0 0 20px rgba(212,175,55,0.2),0 0 60px rgba(212,175,55,0.08);} 50%{box-shadow:0 0 40px rgba(212,175,55,0.35),0 0 80px rgba(212,175,55,0.15);} }
        @keyframes slideInLeft { from{opacity:0;transform:translateX(-80px) scale(0.93);} to{opacity:1;transform:translateX(0) scale(1);} }
        @keyframes slideInRight { from{opacity:0;transform:translateX(80px) scale(0.93);} to{opacity:1;transform:translateX(0) scale(1);} }
        @keyframes standardWow {
          0%   { opacity:0; transform:translateY(-120px) scale(0.8) rotate(-2deg); }
          55%  { transform:translateY(18px) scale(1.07) rotate(1deg); }
          72%  { transform:translateY(-10px) scale(0.97) rotate(-0.5deg); }
          86%  { transform:translateY(6px) scale(1.02) rotate(0.2deg); }
          100% { opacity:1; transform:translateY(0) scale(1) rotate(0deg); }
        }
        @keyframes standardGlow { 0%,100%{box-shadow:0 0 40px rgba(0,184,148,0.25),0 0 100px rgba(0,184,148,0.1);} 50%{box-shadow:0 0 80px rgba(0,184,148,0.45),0 0 160px rgba(0,184,148,0.2);} }
        .badge-pulse{animation:badgePulse 2s ease-in-out infinite;}
        .gold-glow{animation:goldGlow 3s ease-in-out infinite;}
        .standard-glow{animation:standardGlow 2.5s ease-in-out infinite;}
      `}</style>

      <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg, #0f1f16 0%, #152b1e 100%)", zIndex: 0 }} />
      <div style={{ position: "absolute", inset: 0, zIndex: 1, overflow: "hidden" }}>
        <img src={STANDARD_BG} alt="" style={{ width: "100%", height: "100%", objectFit: "cover", opacity: freeVisible ? 0.13 : 0, transition: "opacity 1.5s ease", filter: "saturate(0.5) brightness(0.9)" }} />
        <div style={{ position: "absolute", inset: 0, background: "radial-gradient(ellipse at 50% 50%, rgba(15,31,22,0.4) 0%, rgba(15,31,22,0.9) 70%)" }} />
      </div>

      <div style={{ maxWidth: 960, margin: "0 auto", position: "relative", zIndex: 2 }}>
        <div style={{ textAlign: "center", marginBottom: 60 }}>
          <p style={{ color: "#00b894", fontSize: 12, fontWeight: 700, letterSpacing: 3, textTransform: "uppercase", marginBottom: 14 }}>Preise</p>
          <h2 style={{ fontFamily: "'Bricolage Grotesque', sans-serif", fontSize: "clamp(28px, 4vw, 48px)", fontWeight: 800, color: "#fff", letterSpacing: "-1px", marginBottom: 12 }}>Transparent. Fair. Risikofrei.</h2>
          <p style={{ color: "rgba(255,255,255,0.4)", fontSize: 15 }}>Kein Vertrag. Jederzeit kündbar.</p>
          <div style={{ display: "inline-flex", alignItems: "center", gap: 8, marginTop: 20, background: "rgba(212,175,55,0.1)", border: "1px solid rgba(212,175,55,0.35)", borderRadius: 100, padding: "8px 20px" }}>
            <span style={{ fontSize: 14 }}>🐦</span>
            <span style={{ color: "#d4af37", fontSize: 13, fontWeight: 600 }}>Early-Bird-Aktion — jetzt bis zu 50% günstiger!</span>
          </div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 16, alignItems: "start" }}>
          {plans.map((plan) => {
            const isStandard = plan.highlight;
            const isFree = plan.price === "0€";
            const isPro = plan.pro;

            let animation = "none";
            if (isFree && freeVisible)         animation = "slideInLeft 0.7s cubic-bezier(0.22,1,0.36,1) both";
            if (isPro && proVisible)            animation = "slideInRight 0.7s cubic-bezier(0.22,1,0.36,1) both";
            if (isStandard && standardVisible)  animation = "standardWow 1.1s cubic-bezier(0.22,1,0.36,1) both";

            const opacity = isFree ? (freeVisible ? 1 : 0) : isPro ? (proVisible ? 1 : 0) : (standardVisible ? 1 : 0);

            return (
              <div key={plan.name}
                className={isPro ? "gold-glow" : isStandard ? "standard-glow" : ""}
                style={{
                  background: isStandard ? "linear-gradient(135deg, rgba(0,184,148,0.18), rgba(0,206,201,0.08))" : isPro ? "linear-gradient(135deg, rgba(212,175,55,0.08), rgba(180,140,20,0.04))" : "#152b1e",
                  border: isStandard ? "2px solid rgba(0,184,148,0.7)" : isPro ? "2px solid rgba(212,175,55,0.6)" : "1px solid rgba(0,184,148,0.1)",
                  borderRadius: 16, padding: isStandard ? "32px 24px" : "28px 24px",
                  position: "relative", opacity, animation,
                  zIndex: isStandard ? 2 : 1, marginTop: isStandard ? -16 : 0,
                }}
              >
                {plan.badge && (
                  <div className={isStandard ? "badge-pulse" : ""} style={{ position: "absolute", top: -14, left: "50%", transform: "translateX(-50%)", background: isPro ? "linear-gradient(90deg, #b8860b, #d4af37, #b8860b)" : "#00b894", color: isPro ? "#1a1000" : "#fff", fontSize: 12, fontWeight: 700, padding: "4px 18px", borderRadius: 100 }}>{plan.badge}</div>
                )}
                <h3 style={{ fontFamily: "'Bricolage Grotesque', sans-serif", fontSize: isStandard ? 20 : 18, fontWeight: 700, color: isPro ? "#d4af37" : "#fff", marginBottom: 12 }}>{plan.name}</h3>
                <div style={{ marginBottom: 12 }}>
                   <div style={{ display: "flex", alignItems: "baseline", gap: 4 }}>
                     <span style={{ fontFamily: "'Bricolage Grotesque', sans-serif", fontSize: isStandard ? 40 : 36, fontWeight: 800, color: isStandard ? "#00b894" : isPro ? "#d4af37" : "#fff" }}>{plan.price}</span>
                     <span style={{ color: "rgba(255,255,255,0.4)", fontSize: 13 }}>{plan.period}</span>
                   </div>
                 </div>
                <ul style={{ listStyle: "none", padding: 0, marginBottom: 24, display: "flex", flexDirection: "column", gap: 8, marginTop: 12 }}>
                   {plan.features.map(f => (
                     <li key={f.text} style={{ display: "flex", alignItems: "center", gap: 8, color: f.included ? "rgba(255,255,255,0.7)" : "rgba(255,255,255,0.3)", fontSize: 13, opacity: f.included ? 1 : 0.6 }}>
                       <span style={{ color: f.included ? (isPro ? "#d4af37" : "#00b894") : "#ef4444", fontWeight: 700 }}>{f.included ? "✓" : "✗"}</span> {f.text}
                     </li>
                   ))}
                 </ul>
                <a href="#" style={{ display: "block", textAlign: "center", padding: isStandard ? "12px 0" : "11px 0", borderRadius: 100, fontWeight: 700, fontSize: 13, textDecoration: "none", transition: "all 0.2s", background: isStandard ? "#00b894" : isPro ? "linear-gradient(90deg, #b8860b, #d4af37)" : "transparent", color: isStandard ? "#fff" : isPro ? "#1a1000" : "#00b894", border: isStandard || isPro ? "none" : "1px solid rgba(0,184,148,0.4)" }}
                   onMouseEnter={e => { e.currentTarget.style.opacity = "0.85"; e.currentTarget.style.transform = "scale(1.02)"; }}
                   onMouseLeave={e => { e.currentTarget.style.opacity = "1"; e.currentTarget.style.transform = "scale(1)"; }}
                 >{plan.price === "0€" ? "Kostenlos starten" : "Jetzt starten"}</a>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}