import React, { useEffect, useState, useRef, useCallback } from "react";

const TOOLTIP_STEPS = [
  { key: "umsatz",       label: "Umsatz",        emoji: "📈", text: "Dein Umsatz wächst automatisch — durch Stammkunden & Empfehlungen.", value: 4280, prefix: "€", change: "+23%", bg: "https://images.unsplash.com/photo-1553729459-efe14ef6055d?w=1600&q=80" },
  { key: "kunden",       label: "Kunden",         emoji: "👥", text: "Neue Kunden kommen über das Netzwerk deiner bestehenden Stammkunden.",      value: 847,  prefix: "",  change: "+18%", bg: "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=1600&q=80" },
  { key: "empfehlungen", label: "Empfehlungen",   emoji: "📢", text: "Jeder Kunde wird automatisch zum Markenbotschafter — per WhatsApp.", value: 234,  prefix: "",  change: "+31%", bg: "https://images.unsplash.com/photo-1611605698335-8b1569810432?w=1600&q=80" },
  { key: "provision",    label: "Provision",      emoji: "💰", text: "Provisionen werden automatisch abgerechnet. Null Aufwand für dich.", value: 1120, prefix: "€", change: "+21%", bg: "https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?w=1600&q=80" },
];

const feed = [
  { emoji: "📲", text: "QR-Code gescannt — Stempelkarte aktiv" },
  { emoji: "📢", text: "Empfehlung von Mehmet B. eingegangen" },
  { emoji: "💰", text: "Provision ausgelöst — 12,50 €" },
  { emoji: "👤", text: "Neuer Kunde — Sara K. registriert" },
  { emoji: "🎉", text: "10. Stempel — Belohnung aktiviert!" },
];

const bars = [60, 80, 50, 90, 70, 100, 85];
const sidebarItems = [
  { label: "Übersicht",     icon: "📊" },
  { label: "Kunden",        icon: "👥" },
  { label: "Empfehlungen",  icon: "📢" },
  { label: "Stempelkarten", icon: "🎫" },
  { label: "Einstellungen", icon: "⚙️" },
];

const SCROLL_PER_STEP = 400;
const TOTAL_SCROLL = SCROLL_PER_STEP * (TOOLTIP_STEPS.length - 1);

function CountUp({ target, prefix }) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    setCount(0);
    let v = 0;
    const step = target / 60;
    const t = setInterval(() => {
      v += step;
      if (v >= target) { setCount(target); clearInterval(t); }
      else setCount(Math.floor(v));
    }, 20);
    return () => clearInterval(t);
  }, [target]);
  return <>{prefix}{count.toLocaleString("de-DE")}</>;
}

export default function DashboardSection() {
  const [laptopIn, setLaptopIn] = useState(false);
  const [laptopOpen, setLaptopOpen] = useState(false);
  const [showDashboard, setShowDashboard] = useState(false);
  const [activeTooltip, setActiveTooltip] = useState(0);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [feedIdx, setFeedIdx] = useState(0);
  const [feedFading, setFeedFading] = useState(false);
  const [locked, setLocked] = useState(false);
  const [tappedTooltip, setTappedTooltip] = useState(null);

  const sectionRef = useRef(null);
  const placeholderRef = useRef(null);
  const lockedRef = useRef(false);
  const scrollAccRef = useRef(0);
  const frozenScrollY = useRef(0);

  // ---------- lock / unlock helpers ----------
  const lock = useCallback(() => {
    if (lockedRef.current) return;
    frozenScrollY.current = window.scrollY;
    lockedRef.current = true;
    setLocked(true);
    document.body.style.overflow = "hidden";
  }, []);

  const unlock = useCallback(() => {
    if (!lockedRef.current) return;
    lockedRef.current = false;
    setLocked(false);
    document.body.style.overflow = "";
  }, []);

  // ---------- visibility observer → intro ----------
  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setLaptopIn(true);
        setTimeout(() => setLaptopOpen(true), 300);
        setTimeout(() => setShowDashboard(true), 900);
        observer.disconnect();
      }
    }, { threshold: 0.05 });
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  // ---------- lock on first scroll attempt ----------
  useEffect(() => {
    if (!showDashboard) return;
    const handleFirstScroll = (e) => {
      if (e.deltaY !== 0 || e.touches) {
        scrollAccRef.current = 0;
        setScrollProgress(0);
        setActiveTooltip(0);
        lock();
        window.removeEventListener("wheel", handleFirstScroll);
        window.removeEventListener("touchmove", handleFirstScroll);
      }
    };
    window.addEventListener("wheel", handleFirstScroll, { passive: false });
    window.addEventListener("touchmove", handleFirstScroll, { passive: false });
    return () => {
      window.removeEventListener("wheel", handleFirstScroll);
      window.removeEventListener("touchmove", handleFirstScroll);
    };
  }, [showDashboard, lock]);

  // ---------- scroll / wheel handler ----------
  const handleWheel = useCallback((e) => {
    if (!lockedRef.current) return;
    e.preventDefault();
    e.stopPropagation();

    const next = scrollAccRef.current + e.deltaY;
    const clamped = Math.max(0, Math.min(TOTAL_SCROLL, next));
    scrollAccRef.current = clamped;

    const progress = clamped / TOTAL_SCROLL;
    setScrollProgress(progress);
    setActiveTooltip(Math.round(progress * (TOOLTIP_STEPS.length - 1)));

    // unlock forward
    if (next > TOTAL_SCROLL) { unlock(); return; }
    // unlock backward
    if (next < 0) { unlock(); return; }
  }, [unlock]);

  // touch
  const touchStartY = useRef(null);
  const handleTouchStart = useCallback((e) => { touchStartY.current = e.touches[0].clientY; }, []);
  const handleTouchMove = useCallback((e) => {
    if (!lockedRef.current || touchStartY.current === null) return;
    e.preventDefault();
    const delta = (touchStartY.current - e.touches[0].clientY) * 2.5;
    touchStartY.current = e.touches[0].clientY;
    const next = scrollAccRef.current + delta;
    const clamped = Math.max(0, Math.min(TOTAL_SCROLL, next));
    scrollAccRef.current = clamped;
    const progress = clamped / TOTAL_SCROLL;
    setScrollProgress(progress);
    setActiveTooltip(Math.round(progress * (TOOLTIP_STEPS.length - 1)));
    if (next > TOTAL_SCROLL || next < 0) unlock();
  }, [unlock]);

  // attach to window so we capture events even if focus is elsewhere
  useEffect(() => {
    window.addEventListener("wheel", handleWheel, { passive: false });
    window.addEventListener("touchstart", handleTouchStart, { passive: true });
    window.addEventListener("touchmove", handleTouchMove, { passive: false });
    return () => {
      window.removeEventListener("wheel", handleWheel);
      window.removeEventListener("touchstart", handleTouchStart);
      window.removeEventListener("touchmove", handleTouchMove);
    };
  }, [handleWheel, handleTouchStart, handleTouchMove]);

  // cleanup body overflow on unmount
  useEffect(() => () => { document.body.style.overflow = ""; }, []);

  // live feed ticker
  useEffect(() => {
    const t = setInterval(() => {
      setFeedFading(true);
      setTimeout(() => { setFeedIdx(i => (i + 1) % feed.length); setFeedFading(false); }, 300);
    }, 2600);
    return () => clearInterval(t);
  }, []);

  return (
    <>
      {/* Placeholder keeps layout space while section is fixed */}
      {locked && <div ref={placeholderRef} style={{ height: "100vh" }} />}

      <section
        ref={sectionRef}
        style={{
          padding: "60px 60px 80px",
          overflow: "hidden",
          background: "transparent",
          position: locked ? "fixed" : "relative",
          top: locked ? 0 : "auto",
          left: locked ? 0 : "auto",
          right: locked ? 0 : "auto",
          zIndex: locked ? 50 : "auto",
          width: "100%",
          boxSizing: "border-box",
          minHeight: locked ? "100vh" : "auto",
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
        }}
      >
        <style>{`
          @keyframes laptopFlyIn {
            0%   { opacity:0; transform:perspective(1400px) rotateY(-25deg) rotateX(18deg) translateY(90px) scale(0.82); }
            60%  { transform:perspective(1400px) rotateY(4deg) rotateX(-2deg) translateY(-8px) scale(1.02); }
            100% { opacity:1; transform:perspective(1400px) rotateY(0deg) rotateX(0deg) translateY(0) scale(1); }
          }
          @keyframes glowPulse   { 0%,100%{opacity:0.10} 50%{opacity:0.24} }
          @keyframes dashIn      { 0%{opacity:0;transform:translateY(14px);} 100%{opacity:1;transform:translateY(0);} }
          @keyframes tooltipPop  { 0%{opacity:0;transform:translateX(-50%) scale(0.72) translateY(10px);} 70%{transform:translateX(-50%) scale(1.04) translateY(-2px);} 100%{opacity:1;transform:translateX(-50%) scale(1) translateY(0);} }
          @keyframes bubblePop   { 0%{opacity:0;transform:translateY(-50%) scale(0.7);} 70%{transform:translateY(-50%) scale(1.05);} 100%{opacity:1;transform:translateY(-50%) scale(1);} }
          @keyframes metricPulse { 0%,100%{background:rgba(0,184,148,0.05);} 50%{background:rgba(0,184,148,0.13);} }
          .metric-pulse { animation: metricPulse 3s ease-in-out infinite; }
          @media(max-width:640px){ .db-sidebar{display:none!important;} .db-topbadge{display:none!important;} }
        `}</style>

        {/* Dark background when fixed so content below doesn't show through */}
        {locked && <div style={{ position: "absolute", inset: 0, background: "#080e0c", zIndex: -1 }} />}

        {/* Ambient glow */}
        <div style={{ position: "absolute", top: "40%", left: "50%", transform: "translate(-50%,-50%)", width: 900, height: 600, background: "radial-gradient(ellipse, rgba(0,184,148,0.14) 0%, transparent 70%)", animation: "glowPulse 4s ease-in-out infinite", pointerEvents: "none" }} />

        <div style={{ maxWidth: 700, margin: "0 auto", position: "relative", zIndex: 2, width: "100%" }}>
          {/* Heading */}
          <div style={{ textAlign: "center", marginBottom: 28 }}>
            <p style={{ color: "#00b894", fontSize: 12, fontWeight: 700, letterSpacing: 3, textTransform: "uppercase", marginBottom: 10 }}>Live-Dashboard</p>
            <h2 style={{ fontFamily: "'Bricolage Grotesque', sans-serif", fontSize: "clamp(24px, 3.5vw, 42px)", fontWeight: 800, color: "#fff", letterSpacing: "-1px", margin: 0 }}>
              Alles im Blick. Echtzeit.
            </h2>
            {showDashboard && locked && (
              <p style={{ color: "rgba(255,255,255,0.3)", fontSize: 13, marginTop: 10 }}>↓ Scroll um alle Metriken zu sehen</p>
            )}
          </div>

          {/* Laptop */}
          <div style={{
            width: "100%",
            opacity: laptopIn ? 1 : 0,
            animation: laptopIn ? "laptopFlyIn 1.5s cubic-bezier(0.22,1,0.36,1) both" : "none",
          }}>
            {/* Lid */}
            <div style={{
              transformOrigin: "bottom center",
              transform: laptopOpen ? "perspective(1200px) rotateX(0deg)" : "perspective(1200px) rotateX(-82deg)",
              transition: "transform 1.4s cubic-bezier(0.16,1,0.3,1)",
              borderRadius: "20px 20px 0 0", overflow: "hidden",
              border: "1.5px solid rgba(0,184,148,0.3)", borderBottom: "none",
              boxShadow: laptopOpen ? "0 -20px 80px rgba(0,184,148,0.12), 0 40px 100px rgba(0,0,0,0.6)" : "none",
            }}>
              {/* Browser bar */}
              <div style={{ background: "#132019", padding: "10px 16px", display: "flex", alignItems: "center", gap: 10, borderBottom: "1px solid rgba(0,184,148,0.1)" }}>
                <div style={{ display: "flex", gap: 6, flexShrink: 0 }}>
                  {["#ff5f57","#febc2e","#28c840"].map(c => <div key={c} style={{ width: 10, height: 10, borderRadius: "50%", background: c }} />)}
                </div>
                <div style={{ flex: 1, background: "rgba(255,255,255,0.06)", borderRadius: 6, padding: "4px 10px", textAlign: "center" }}>
                  <span style={{ color: "rgba(255,255,255,0.4)", fontSize: 11 }}>app.sensalie.com/dashboard</span>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 5, flexShrink: 0 }}>
                  <div style={{ width: 6, height: 6, borderRadius: "50%", background: "#00b894", boxShadow: "0 0 8px #00b894" }} />
                  <span style={{ color: "#00b894", fontSize: 10, fontWeight: 600 }}>LIVE</span>
                </div>
              </div>

              {/* Screen */}
              <div style={{ background: "#132019", minHeight: 300, display: "flex" }}>
                {!showDashboard ? (
                  <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <div style={{ textAlign: "center" }}>
                      <div style={{ fontFamily: "'Bricolage Grotesque', sans-serif", fontSize: "clamp(36px, 5vw, 64px)", fontWeight: 800, color: "#fff", letterSpacing: "-3px" }}>
                        Sens<span style={{ color: "#00b894" }}>alie</span><span style={{ color: "#00b894" }}>.</span>
                      </div>
                      <p style={{ color: "rgba(255,255,255,0.3)", fontSize: 13, marginTop: 10 }}>Dein Wachstumssystem. Vollautomatisch.</p>
                    </div>
                  </div>
                ) : (
                  <div style={{ display: "flex", width: "100%", animation: "dashIn 0.55s ease both" }}>
                    {/* Sidebar */}
                    <div className="db-sidebar" style={{ width: 145, background: "#0f1f16", borderRight: "1px solid rgba(0,184,148,0.08)", padding: "18px 0", flexShrink: 0 }}>
                      {sidebarItems.map((item, i) => (
                        <div key={item.label} style={{ padding: "9px 14px", color: i === 0 ? "#00b894" : "rgba(255,255,255,0.3)", fontSize: 11, fontWeight: i === 0 ? 600 : 400, background: i === 0 ? "rgba(0,184,148,0.08)" : "transparent", borderLeft: i === 0 ? "2px solid #00b894" : "2px solid transparent", display: "flex", alignItems: "center", gap: 7 }}>
                          <span style={{ fontSize: 12 }}>{item.icon}</span>{item.label}
                        </div>
                      ))}
                    </div>

                    {/* Main content */}
                    <div style={{ flex: 1, padding: "14px 18px" }}>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
                        <div>
                          <div style={{ color: "rgba(255,255,255,0.3)", fontSize: 10 }}>Guten Morgen</div>
                          <div style={{ color: "#fff", fontSize: 13, fontWeight: 700, fontFamily: "'Bricolage Grotesque', sans-serif" }}>Dein Unternehmen 👋</div>
                        </div>
                        <div className="db-topbadge" style={{ background: "rgba(0,184,148,0.12)", border: "1px solid rgba(0,184,148,0.3)", borderRadius: 7, padding: "4px 10px", color: "#00b894", fontSize: 10, fontWeight: 600 }}>Heute: +3 Neukunden</div>
                      </div>

                      {/* Metrics with attached speech bubbles */}
                      <div style={{ display: "grid", gridTemplateColumns: "repeat(2,1fr)", gap: 8, marginBottom: 12 }}>
                        {TOOLTIP_STEPS.map((m, idx) => {
                          const isScrollActive = activeTooltip === idx && locked;
                          const isTapActive = !locked && tappedTooltip === idx;
                          const isActive = isScrollActive || isTapActive;
                          // bubble on right for left column (0,2), on left for right column (1,3)
                          const isLeftCol = idx % 2 === 0;
                          return (
                            <div key={m.key} style={{ position: "relative" }}
                              onClick={() => !locked && setTappedTooltip(tappedTooltip === idx ? null : idx)}
                            >
                              {/* Speech bubble */}
                              {isActive && (
                                <div key={`bubble-${idx}`} style={{
                                  position: "absolute",
                                  top: "50%",
                                  [isLeftCol ? "left" : "right"]: "calc(100% + 10px)",
                                  transform: "translateY(-50%)",
                                  background: "#00b894",
                                  color: "#fff",
                                  fontSize: 10,
                                  lineHeight: 1.5,
                                  fontWeight: 500,
                                  padding: "8px 11px",
                                  borderRadius: 10,
                                  width: 130,
                                  zIndex: 40,
                                  pointerEvents: "none",
                                  animation: "bubblePop 0.3s cubic-bezier(0.22,1,0.36,1) both",
                                  boxShadow: "0 4px 20px rgba(0,184,148,0.5)",
                                }}>
                                  {m.text}
                                  {/* Arrow */}
                                  <div style={{
                                    position: "absolute",
                                    top: "50%",
                                    [isLeftCol ? "right" : "left"]: "100%",
                                    transform: "translateY(-50%)",
                                    width: 0, height: 0,
                                    borderTop: "6px solid transparent",
                                    borderBottom: "6px solid transparent",
                                    [isLeftCol ? "borderLeft" : "borderRight"]: "7px solid #00b894",
                                  }} />
                                </div>
                              )}

                              <div className="metric-pulse" style={{ border: `1px solid ${isActive ? "rgba(0,184,148,0.85)" : "rgba(0,184,148,0.1)"}`, borderRadius: 10, padding: "10px 12px", position: "relative", overflow: "hidden", transition: "border-color 0.4s, box-shadow 0.4s", boxShadow: isActive ? "0 0 32px rgba(0,184,148,0.4)" : "none", animationDelay: `${idx * 0.7}s`, cursor: locked ? "default" : "pointer" }}>
                                <img src={m.bg} alt="" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", objectPosition: "center", opacity: isActive ? 0.32 : 0, transition: "opacity 0.7s ease", pointerEvents: "none" }} />
                                <div style={{ position: "absolute", inset: 0, background: "linear-gradient(135deg, rgba(6,14,9,0.7) 0%, rgba(6,14,9,0.5) 100%)", opacity: isActive ? 1 : 0, transition: "opacity 0.7s ease", pointerEvents: "none" }} />
                                <div style={{ position: "relative", zIndex: 1 }}>
                                  <div style={{ color: isActive ? "rgba(255,255,255,0.7)" : "rgba(255,255,255,0.35)", fontSize: 9, marginBottom: 2, transition: "color 0.4s" }}>{m.emoji} {m.label}</div>
                                  <div style={{ fontFamily: "'Bricolage Grotesque', sans-serif", fontSize: 18, fontWeight: 700, color: isActive ? "#00b894" : "#fff", transition: "color 0.4s" }}>
                                    <CountUp key={`${idx}-${showDashboard}`} target={m.value} prefix={m.prefix} />
                                  </div>
                                  <div style={{ color: "#00b894", fontSize: 9, fontWeight: 600, marginTop: 2 }}>{m.change}</div>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>

                      {/* Bar chart */}
                      <div style={{ background: "rgba(255,255,255,0.03)", borderRadius: 10, padding: "9px 12px", marginBottom: 7 }}>
                        <div style={{ color: "rgba(255,255,255,0.3)", fontSize: 9, marginBottom: 5 }}>Umsatz letzte 7 Tage</div>
                        <div style={{ display: "flex", alignItems: "flex-end", gap: 4, height: 32 }}>
                          {bars.map((h, i) => (
                            <div key={i} style={{ flex: 1, borderRadius: 3, background: `rgba(0,184,148,${0.25 + (h / 100) * 0.65})`, height: `${h}%`, transition: `height 1.1s ease ${0.3 + i * 0.07}s` }} />
                          ))}
                        </div>
                      </div>

                      {/* Live feed */}
                      <div style={{ background: "rgba(255,255,255,0.03)", borderRadius: 10, padding: "7px 12px" }}>
                        <div style={{ display: "flex", alignItems: "center", gap: 5, marginBottom: 4 }}>
                          <div style={{ width: 5, height: 5, borderRadius: "50%", background: "#00b894", boxShadow: "0 0 6px #00b894" }} />
                          <div style={{ color: "rgba(255,255,255,0.3)", fontSize: 9 }}>Live-Aktivität</div>
                        </div>
                        <div style={{ color: "#fff", fontSize: 11, opacity: feedFading ? 0 : 1, transform: feedFading ? "translateY(-5px)" : "translateY(0)", transition: "all 0.3s ease", display: "flex", alignItems: "center", gap: 6 }}>
                          <span>{feed[feedIdx].emoji}</span><span>{feed[feedIdx].text}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Base */}
            <div style={{ height: 11, background: "linear-gradient(180deg, #152b1e, #0f1f16)", borderRadius: "0 0 8px 8px", border: "1.5px solid rgba(0,184,148,0.2)", borderTop: "none" }} />
            <div style={{ height: 5, background: "#0f1f16", borderRadius: "0 0 16px 16px", margin: "0 40px" }} />
          </div>

          {/* Progress + dots */}
          {showDashboard && (
            <div style={{ marginTop: 24 }}>
              <div style={{ width: "100%", height: 2, background: "rgba(255,255,255,0.08)", borderRadius: 100, marginBottom: 14, overflow: "hidden" }}>
                <div style={{ height: "100%", width: `${scrollProgress * 100}%`, background: "#00b894", borderRadius: 100, transition: "width 0.1s ease" }} />
              </div>
              <div style={{ display: "flex", justifyContent: "center", gap: 8 }}>
                {TOOLTIP_STEPS.map((_, i) => (
                  <div key={i} style={{ width: activeTooltip === i ? 24 : 8, height: 8, borderRadius: 100, background: i === activeTooltip ? "#00b894" : "rgba(255,255,255,0.18)", transition: "all 0.4s ease" }} />
                ))}
              </div>
              <p style={{ textAlign: "center", color: "#00b894", fontSize: 12, fontWeight: 600, marginTop: 10, letterSpacing: 1 }}>
                {TOOLTIP_STEPS[activeTooltip].emoji} {TOOLTIP_STEPS[activeTooltip].label}
                {!locked && <span style={{ color: "rgba(255,255,255,0.3)", fontWeight: 400 }}> — Weiter scrollen ↓</span>}
              </p>
            </div>
          )}
        </div>
      </section>
    </>
  );
}